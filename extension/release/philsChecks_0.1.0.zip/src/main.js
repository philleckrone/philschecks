// Phils Custom (cms) Checks 0.1.0 for Paratext 10. Built by tools/build.py from src/ - do not edit.
'use strict';
// Phils Checks core, part 1: Python regexes and string functions as Paratext's IronPython runs them.
// A port of Project_Checker\ProjectChecker\Services\PyRegex.cs, PyText.cs and Fixes.cs.
//
// IronPython's `re` is .NET Regex underneath, so \w \s \d \b have their .NET (Unicode) meaning
// whether or not re.UNICODE is given. JavaScript's do not, so translate() spells them out:
//   \s = [\f\n\r\t\v\x85\p{Z}]   \d = \p{Nd}   \w = [\p{L}\p{Mn}\p{Nd}\p{Pc}]
// and turns . ^ $ \b \A \Z (?P<..>) into their .NET meaning. Offsets are UTF-16 code units in both.
// No papi here: the build puts these files in front of main.js, and the tests load them with
// vm.runInThisContext (see src/order.json).
var PC = {};

PC.re = (function () {
  'use strict';

  var IGNORECASE = 1;
  var MULTILINE = 2;
  var DOTALL = 4;
  var UNICODE = 8;
  var VERBOSE = 16;

  var S_IN = '\\f\\n\\r\\t\\v\\x85\\p{Z}';
  var W_IN = '\\p{L}\\p{Mn}\\p{Nd}\\p{Pc}';
  var W = '[' + W_IN + ']';
  var SYNTAX = '^$\\.*+?()[]{}|/';
  var QUANT_RE = /^\{\d+(,\d*)?\}/;

  function fail(p, why) {
    throw new Error('Python regex not supported (' + why + '): ' + p);
  }

  function isAlnum(c) {
    return /[A-Za-z0-9]/.test(c);
  }

  /** Copies the argument of \x, \u, \p after the escape letter; returns the new index. */
  function copyEscapeArg(p, i, e, out) {
    if (e === 'x') {
      out.push(p.substr(i, 2));
      return i + 2;
    }
    if (e === 'u') {
      out.push(p.substr(i, 4));
      return i + 4;
    }
    if (e === 'p' || e === 'P') {
      var close = p.indexOf('}', i);
      if (p[i] !== '{' || close < 0) fail(p, '\\' + e + ' without {}');
      out.push(p.substring(i, close + 1));
      return close + 1;
    }
    return i;
  }

  /** The pattern of a Python (IronPython) regex as a JavaScript 'u' regex source. */
  function translate(p, flags) {
    flags = flags || 0;
    var out = [];
    var i = 0;
    // Inline flags at the start, e.g. (?u) or (?im).
    var lead = /^\(\?([iLmsux]+)\)/.exec(p);
    if (lead) {
      if (lead[1].indexOf('i') >= 0) flags |= IGNORECASE;
      if (lead[1].indexOf('m') >= 0) flags |= MULTILINE;
      if (lead[1].indexOf('s') >= 0) flags |= DOTALL;
      if (lead[1].indexOf('x') >= 0) flags |= VERBOSE;
      i = lead[0].length;
    }
    var verbose = (flags & VERBOSE) !== 0;
    var inClass = false;
    var classStart = false;
    while (i < p.length) {
      var c = p[i];
      if (c === '\\') {
        if (i + 1 >= p.length) fail(p, 'trailing backslash');
        var e = p[i + 1];
        i += 2;
        if (inClass) {
          classStart = false;
          if (e === 's') out.push(S_IN);
          else if (e === 'w') out.push(W_IN);
          else if (e === 'd') out.push('\\p{Nd}');
          else if (e === 'D') out.push('\\P{Nd}');
          else if (e === 'S' || e === 'W') fail(p, '\\' + e + ' inside []');
          else if (e === 'b') out.push('\\x08');
          else if (e === 'a') out.push('\\x07');
          else if ('tnrfv'.indexOf(e) >= 0) out.push('\\' + e);
          else if ('xupP'.indexOf(e) >= 0) {
            out.push('\\' + e);
            i = copyEscapeArg(p, i, e, out);
          } else if (isAlnum(e)) fail(p, '\\' + e + ' inside []');
          else if (SYNTAX.indexOf(e) >= 0 || e === '-') out.push('\\' + e);
          else out.push(e);
          continue;
        }
        if (e === 's') out.push('[' + S_IN + ']');
        else if (e === 'S') out.push('[^' + S_IN + ']');
        else if (e === 'w') out.push(W);
        else if (e === 'W') out.push('[^' + W_IN + ']');
        else if (e === 'd') out.push('\\p{Nd}');
        else if (e === 'D') out.push('\\P{Nd}');
        else if (e === 'b') out.push('(?:(?<=' + W + ')(?!' + W + ')|(?<!' + W + ')(?=' + W + '))');
        else if (e === 'B') out.push('(?:(?<=' + W + ')(?=' + W + ')|(?<!' + W + ')(?!' + W + '))');
        else if (e === 'A') out.push('(?<![\\s\\S])');
        else if (e === 'Z' || e === 'z') out.push('(?![\\s\\S])');
        else if (e === 'a') out.push('\\x07');
        else if (e === 'e') out.push('\\x1B');
        else if ('tnrfv'.indexOf(e) >= 0) out.push('\\' + e);
        else if ('xupP'.indexOf(e) >= 0) {
          out.push('\\' + e);
          i = copyEscapeArg(p, i, e, out);
        } else if (/[1-9]/.test(e)) out.push('\\' + e);
        else if (isAlnum(e)) fail(p, '\\' + e);
        else if (SYNTAX.indexOf(e) >= 0) out.push('\\' + e);
        else out.push(e);
        continue;
      }
      if (inClass) {
        if (c === ']' && !classStart) inClass = false;
        out.push(c === ']' && classStart ? '\\]' : c);
        classStart = false;
        i++;
        continue;
      }
      if (verbose && /\s/.test(c)) {
        i++;
        continue;
      }
      if (verbose && c === '#') {
        while (i < p.length && p[i] !== '\n') i++;
        continue;
      }
      if (c === '[') {
        inClass = true;
        out.push('[');
        i++;
        if (p[i] === '^') {
          out.push('^');
          i++;
        }
        classStart = true; // a ']' right after '[' or '[^' is a literal
        continue;
      }
      if (c === '(' && p[i + 1] === '?') {
        if (p[i + 2] === 'P' && p[i + 3] === '<') {
          out.push('(?<');
          i += 4;
          continue;
        }
        if (p[i + 2] === 'P' && p[i + 3] === '=') {
          var close = p.indexOf(')', i);
          out.push('\\k<' + p.substring(i + 4, close) + '>');
          i = close + 1;
          continue;
        }
        if (p[i + 2] === '#') {
          i = p.indexOf(')', i) + 1;
          continue;
        }
        if (/[iLmsux]/.test(p[i + 2] || '')) fail(p, 'inline flags inside the pattern');
        out.push('(?');
        i += 2;
        continue;
      }
      if (c === '.') {
        out.push((flags & DOTALL) !== 0 ? '[\\s\\S]' : '[^\\n]');
        i++;
        continue;
      }
      if (c === '^') {
        out.push((flags & MULTILINE) !== 0 ? '(?:^|(?<=\\n))' : '^');
        i++;
        continue;
      }
      if (c === '$') {
        out.push((flags & MULTILINE) !== 0 ? '(?=\\n|$)' : '(?=\\n?$)');
        i++;
        continue;
      }
      if (c === '{') {
        var q = QUANT_RE.exec(p.substring(i));
        if (q) {
          out.push(q[0]);
          i += q[0].length;
        } else {
          out.push('\\{');
          i++;
        }
        continue;
      }
      if (c === '}') {
        out.push('\\}');
        i++;
        continue;
      }
      out.push(c);
      i++;
    }
    if (inClass) fail(p, 'unclosed [');
    return out.join('');
  }

  /** PyRegex.Compile: a global JavaScript regex with .NET/IronPython meaning. */
  function compile(p, flags) {
    var re = new RegExp(translate(p, flags), 'gu' + ((flags || 0) & IGNORECASE ? 'i' : ''));
    re.pySource = p;
    return re;
  }

  function sticky(re) {
    if (!re.pySticky) re.pySticky = new RegExp(re.source, re.flags.replace('g', '') + 'y');
    return re.pySticky;
  }

  /**
   * Python pattern.finditer(text, pos, endpos) / .NET Regex.Matches: every match, an empty match
   * moving on by one UTF-16 unit (as .NET does). endpos makes the string end there.
   */
  function findAll(re, text, pos, endpos) {
    var list = [];
    if (endpos === undefined || endpos > text.length) endpos = text.length;
    pos = pos || 0;
    if (pos > endpos) return list;
    var s = endpos === text.length ? text : text.substring(0, endpos);
    re.lastIndex = pos;
    var m;
    while ((m = re.exec(s)) !== null) {
      list.push(m);
      if (m[0].length === 0) re.lastIndex = m.index + 1;
      if (re.lastIndex > s.length) break;
    }
    re.lastIndex = 0;
    return list;
  }

  /** Python pattern.search(text, pos, endpos): the first match or null. */
  function search(re, text, pos, endpos) {
    if (endpos === undefined || endpos > text.length) endpos = text.length;
    pos = pos || 0;
    if (pos > endpos) return null;
    var s = endpos === text.length ? text : text.substring(0, endpos);
    re.lastIndex = pos;
    var m = re.exec(s);
    re.lastIndex = 0;
    return m;
  }

  /** Python pattern.match(text, pos): anchored at pos; lookbehinds still see the text before it. */
  function matchAt(re, text, pos) {
    if (pos > text.length) return null;
    var y = sticky(re);
    y.lastIndex = pos;
    var m = y.exec(text);
    y.lastIndex = 0;
    return m;
  }

  /** re.sub with a function (or a literal string, used as is). */
  function sub(re, text, repl) {
    var parts = [];
    var pos = 0;
    findAll(re, text).forEach(function (m) {
      parts.push(text.substring(pos, m.index));
      parts.push(typeof repl === 'function' ? repl(m) : repl);
      pos = m.index + m[0].length;
    });
    parts.push(text.substring(pos));
    return parts.join('');
  }

  /** Python re.escape: a backslash before every non-alphanumeric ASCII character except _. */
  function escape(s) {
    var out = '';
    for (var i = 0; i < s.length; i++) {
      var c = s[i];
      if (!isAlnum(c) && c !== '_' && c.charCodeAt(0) < 128) out += '\\';
      out += c;
    }
    return out;
  }

  return {
    IGNORECASE: IGNORECASE,
    MULTILINE: MULTILINE,
    DOTALL: DOTALL,
    UNICODE: UNICODE,
    VERBOSE: VERBOSE,
    translate: translate,
    compile: compile,
    findAll: findAll,
    search: search,
    matchAt: matchAt,
    sub: sub,
    escape: escape,
  };
})();

/** Python string functions as IronPython has them (PyText.cs). */
PC.text = (function () {
  'use strict';

  // .NET char.IsWhiteSpace (IronPython's isspace, strip and split use it).
  var SPACE_RE = /[\t-\r\x85\p{Z}]/u;
  var MARK_RE = /\p{M}/gu;

  function isSpace(c) {
    return SPACE_RE.test(c);
  }

  function strip(s) {
    if (s === null || s === undefined) return s;
    var a = 0;
    var b = s.length;
    while (a < b && isSpace(s[a])) a++;
    while (b > a && isSpace(s[b - 1])) b--;
    return s.substring(a, b);
  }

  function rstrip(s) {
    var b = s.length;
    while (b > 0 && isSpace(s[b - 1])) b--;
    return s.substring(0, b);
  }

  function lstrip(s) {
    var a = 0;
    while (a < s.length && isSpace(s[a])) a++;
    return s.substring(a);
  }

  /** unicode.strip(chars) */
  function stripChars(s, chars) {
    var a = 0;
    var b = s.length;
    while (a < b && chars.indexOf(s[a]) >= 0) a++;
    while (b > a && chars.indexOf(s[b - 1]) >= 0) b--;
    return s.substring(a, b);
  }

  /** unicode.split() with no separator; maxsplit as in Python when given. */
  function split(s, maxsplit) {
    var parts = [];
    if (s === null || s === undefined) return parts;
    var i = 0;
    while (i < s.length) {
      while (i < s.length && isSpace(s[i])) i++;
      if (i >= s.length) break;
      if (maxsplit !== undefined && parts.length === maxsplit) {
        parts.push(rstrip(s.substring(i)));
        return parts;
      }
      var j = i;
      while (j < s.length && !isSpace(s[j])) j++;
      parts.push(s.substring(i, j));
      i = j;
    }
    return parts;
  }

  /** unicode.splitlines(): IronPython breaks only on CR, LF, CRLF, U+2028 and U+2029. */
  function splitLines(s) {
    var lines = [];
    var start = 0;
    var i = 0;
    while (i < s.length) {
      var c = s[i];
      if (c === '\n' || c === '\r' || c === '\u2028' || c === '\u2029') {
        lines.push(s.substring(start, i));
        if (c === '\r' && s[i + 1] === '\n') i++;
        start = i + 1;
      }
      i++;
    }
    if (start < s.length) lines.push(s.substring(start));
    return lines;
  }

  function lower(s) {
    return s.toLowerCase();
  }

  /** The accent-insensitive sort key (_sort_fold): NFD, without marks, lower case. */
  function sortFold(s) {
    if (s === null || s === undefined) return '';
    return s.normalize('NFD').replace(MARK_RE, '').toLowerCase();
  }

  /** string.CompareOrdinal: UTF-16 code units, as JavaScript's < compares. */
  function compare(a, b) {
    return a < b ? -1 : a > b ? 1 : 0;
  }

  /** Python's == "Yes", case-insensitive (the approved fix, Fixes.IsYes). */
  function isYes(v) {
    return v !== null && v !== undefined && lower(strip(String(v))) === 'yes';
  }

  /** Python u' ' * n */
  function repeat(c, n) {
    return n <= 0 ? '' : new Array(n + 1).join(c);
  }

  return {
    isSpace: isSpace,
    strip: strip,
    rstrip: rstrip,
    lstrip: lstrip,
    stripChars: stripChars,
    split: split,
    splitLines: splitLines,
    lower: lower,
    sortFold: sortFold,
    compare: compare,
    isYes: isYes,
    repeat: repeat,
  };
})();

// Phils Checks core, part 2: books and USFM plumbing.
// A port of Project_Checker\ProjectChecker\Services\BookCatalog.cs, ChapterSplitter.cs and Usfm.cs.
PC.usfm = (function () {
  'use strict';

  /** Paratext's canonical book list: the 1-based index is the book number. */
  var BOOKS = (
    'GEN EXO LEV NUM DEU JOS JDG RUT 1SA 2SA 1KI 2KI 1CH 2CH EZR NEH EST JOB PSA PRO ECC SNG ISA JER LAM ' +
    'EZK DAN HOS JOL AMO OBA JON MIC NAM HAB ZEP HAG ZEC MAL MAT MRK LUK JHN ACT ROM 1CO 2CO GAL EPH PHP ' +
    'COL 1TH 2TH 1TI 2TI TIT PHM HEB JAS 1PE 2PE 1JN 2JN 3JN JUD REV TOB JDT ESG WIS SIR BAR LJE S3Y SUS ' +
    'BEL 1MA 2MA 3MA 4MA 1ES 2ES MAN PS2 ODA PSS JSA JDB TBS SST DNT BLT XXA XXB XXC XXD XXE XXF XXG FRT ' +
    'BAK OTH 3ES EZA 5EZ 6EZ INT CNC GLO TDX NDX DAG PS3 2BA LBA JUB ENO 1MQ 2MQ 3MQ REP 4BA LAO'
  ).split(' ');

  function bookCode(num) {
    return num >= 1 && num <= BOOKS.length ? BOOKS[num - 1] : null;
  }

  function bookNumber(code) {
    return BOOKS.indexOf(String(code || '').toUpperCase()) + 1;
  }

  // ChapterSplitter: a chapter starts at a line whose first marker is \c N (ASCII digits).
  var CHAPTER_RE = /(?:^|(?<=\n))[ \t]*\\c[ \t]+([0-9]+)/g;

  /**
   * checking.checkAllChapters' cut of one book (ChapterSplitter.Split, IntroInChapter1): the text
   * before the first \c goes with chapter 1. Each chapter: {bookNum, bookCode, chapter, text, start,
   * lastChapter}; start = the chapter text's offset in the book.
   */
  function splitChapters(bookNum, code, usfm) {
    var result = [];
    var starts = [];
    var nums = [];
    CHAPTER_RE.lastIndex = 0;
    var m;
    while ((m = CHAPTER_RE.exec(usfm)) !== null) {
      var n = parseInt(m[1], 10);
      if (n > 2147483647) continue; // int.TryParse fails
      starts.push(m.index);
      nums.push(n);
    }
    CHAPTER_RE.lastIndex = 0;
    if (starts.length === 0) {
      result.push(make(bookNum, code, 1, usfm, 0));
    } else {
      for (var i = 0; i < starts.length; i++) {
        var end = i + 1 < starts.length ? starts[i + 1] : usfm.length;
        if (i === 0) result.push(make(bookNum, code, nums[i], usfm.substring(0, end), 0));
        else result.push(make(bookNum, code, nums[i], usfm.substring(starts[i], end), starts[i]));
      }
    }
    if (result.length > 0) result[result.length - 1].lastChapter = true;
    return result;
  }

  function make(bookNum, code, chapter, text, start) {
    return { bookNum: bookNum, bookCode: code, chapter: chapter, text: text, start: start, lastChapter: false };
  }

  var VERSE_RE = /\\v[ \t\r\n]+([^ \t\r\n\\]+)/g;
  var verseCache = { text: null, starts: [], labels: [] };

  /** Usfm.VerseAt: the label after the last \v starting at or before offset, or "0". */
  function verseAt(text, offset) {
    if (verseCache.text !== text) {
      var starts = [];
      var labels = [];
      VERSE_RE.lastIndex = 0;
      var m;
      while ((m = VERSE_RE.exec(text)) !== null) {
        starts.push(m.index);
        labels.push(m[1]);
      }
      VERSE_RE.lastIndex = 0;
      verseCache = { text: text, starts: starts, labels: labels };
    }
    var verse = '0';
    for (var i = 0; i < verseCache.starts.length; i++) {
      if (verseCache.starts[i] > offset) break;
      verse = verseCache.labels[i];
    }
    return verse;
  }

  /** Usfm.Blank: every match replaced by spaces of the same length (offsets unchanged). */
  function blank(re, text) {
    return PC.re.sub(re, text, function (m) {
      return PC.text.repeat(' ', m[0].length);
    });
  }

  /** Usfm.CollapseWhitespace: CR dropped, LF = space, runs of space/tab = one space. */
  function collapseWhitespace(s) {
    var t = s.replace(/\r/g, '').replace(/\n/g, ' ');
    var out = '';
    var prev = false;
    for (var i = 0; i < t.length; i++) {
      var c = t[i];
      var sp = c === ' ' || c === '\t';
      if (sp) {
        if (!prev) out += ' ';
      } else out += c;
      prev = sp;
    }
    return out;
  }

  /** The leading number of a verse label ("5-7" -> 5, "12a" -> 12), 0 when none. */
  function verseNumber(label) {
    var m = /^\d+/.exec(String(label || ''));
    return m ? parseInt(m[0], 10) : 0;
  }

  return {
    BOOKS: BOOKS,
    bookCode: bookCode,
    bookNumber: bookNumber,
    splitChapters: splitChapters,
    verseAt: verseAt,
    blank: blank,
    collapseWhitespace: collapseWhitespace,
    verseNumber: verseNumber,
  };
})();

// Phils Checks core, part 3: the stylesheet.
// A port of Project_Checker\ProjectChecker\Services\StylesheetService.cs (the _parse_sty /
// _merge_sty / _flag_on / _color_css / _marker_css shared by the report checks).
// A stylesheet is a Map: marker -> Map(lowercased field name -> value).
// In Paratext 10 it comes from platformScripture.StyleInfo (fromStyleInfo); the built-in usfm.sty
// and the tests use parse + merge.
PC.sty = (function () {
  'use strict';

  var T = PC.text;

  /** ParseStyText: a \Marker line opens an entry; other \Field lines set a field on it. */
  function parse(text) {
    var entries = new Map();
    var current = null;
    T.splitLines(text || '').forEach(function (raw) {
      var stripped = T.strip(raw);
      if (stripped.length === 0 || stripped[0] === '#' || stripped[0] !== '\\') return;
      var parts = T.split(stripped.substring(1), 1);
      if (parts.length === 0) return;
      var field = parts[0];
      var value = parts.length > 1 ? T.strip(parts[1]) : '';
      if (field === 'Marker') {
        current = entries.get(value);
        if (!current) {
          current = new Map();
          entries.set(value, current);
        }
      } else if (current) current.set(T.lower(field), value);
    });
    return entries;
  }

  /** usfm.sty with custom.sty laid over it, field by field. */
  function merge(base, custom) {
    var markers = new Map();
    base.forEach(function (fields, key) {
      markers.set(key, new Map(fields));
    });
    custom.forEach(function (fields, key) {
      var target = markers.get(key);
      if (!target) {
        target = new Map();
        markers.set(key, target);
      }
      fields.forEach(function (v, f) {
        target.set(f, v);
      });
    });
    return markers;
  }

  /**
   * The same table from Paratext 10's StyleInfo (merged usfm.sty + custom.sty, already resolved:
   * \Regular, \Color/\ColorName...). Its color is "#RRGGBB", kept as field "colorcss".
   */
  function fromStyleInfo(info) {
    var markers = new Map();
    var all = (info && info.markers) || {};
    Object.keys(all).forEach(function (key) {
      var s = all[key] || {};
      var f = new Map();
      if (s.styleType) f.set('styletype', String(s.styleType));
      if (s.endMarker) f.set('endmarker', String(s.endMarker));
      if (s.bold) f.set('bold', '');
      if (s.italic) f.set('italic', '');
      if (s.superscript) f.set('superscript', '');
      if (s.smallCaps) f.set('smallcaps', '');
      if (s.underline) f.set('underline', '');
      if (s.color && /^#[0-9a-fA-F]{6}$/.test(s.color)) f.set('colorcss', s.color);
      markers.set(s.marker || key, f);
    });
    return markers;
  }

  /** _flag_on: the field is present and not no/off/false/0. */
  function flagOn(fields, name) {
    if (!fields || !fields.has(name)) return false;
    var v = T.lower(T.strip(fields.get(name) || ''));
    return v !== 'no' && v !== 'off' && v !== 'false' && v !== '0';
  }

  /** _color_css: \Color is a Windows COLORREF decimal (R = low byte, B = high byte). */
  function colorCss(value) {
    if (value === null || value === undefined) return null;
    var v = T.strip(value);
    if (!/^[+-]?\d+$/.test(v)) return null;
    var n = parseInt(v, 10);
    if (!isFinite(n)) return null;
    // long arithmetic: & on a 64-bit value; JavaScript's & works on 32 bits, enough for 3 bytes.
    var r = n & 0xff;
    var g = (n >> 8) & 0xff;
    var b = (n >> 16) & 0xff;
    return 'rgb(' + r + ',' + g + ',' + b + ')';
  }

  /** _marker_css */
  function markerCss(fields) {
    if (!fields || fields.size === 0) return '';
    var parts = [];
    if (flagOn(fields, 'bold')) parts.push('font-weight:bold');
    if (flagOn(fields, 'italic')) parts.push('font-style:italic');
    if (flagOn(fields, 'superscript')) parts.push('vertical-align:super;font-size:smaller');
    if (flagOn(fields, 'smallcaps')) parts.push('font-variant:small-caps');
    if (flagOn(fields, 'underline')) parts.push('text-decoration:underline');
    if (fields.has('colorcss')) parts.push('color:' + fields.get('colorcss'));
    else if (fields.get('color')) {
      var css = colorCss(fields.get('color'));
      if (css) parts.push('color:' + css);
    }
    return parts.join(';');
  }

  /** Markers whose \StyleType is "character" (case-insensitive). */
  function characterStyles(sty) {
    var set = new Set();
    sty.forEach(function (fields, key) {
      var t = fields.get('styletype');
      if (t !== undefined && T.lower(T.strip(t)) === 'character') set.add(key);
    });
    return set;
  }

  return {
    parse: parse,
    merge: merge,
    fromStyleInfo: fromStyleInfo,
    flagOn: flagOn,
    colorCss: colorCss,
    markerCss: markerCss,
    characterStyles: characterStyles,
  };
})();

// Phils Checks core, part 4: footnote sub-markers.
// A port of Project_Checker\ProjectChecker\Services\FootnoteTokenizer.cs (report_nested_styles.py's
// _tokenize_footnote and SUBMARKER_RE, shared with find_footnotes.py).
PC.footnotes = (function () {
  'use strict';

  var R = PC.re;
  var FOOTNOTE_RE = R.compile('\\\\f\\s(.*?)\\\\f\\*', R.UNICODE | R.DOTALL);
  var SUBMARKER_RE = R.compile('\\\\\\+?[a-zA-Z][a-zA-Z0-9]*\\*?', R.UNICODE);

  /** _FOOTNOTE_LEVEL_MARKERS: the footnote's own structure, never a nested character style. */
  var LEVEL_MARKERS = new Set(['fr', 'fq', 'fqa', 'fk', 'fl', 'fp', 'ft', 'fv', 'fdc', 'fm']);

  /** _style_key: without the USFM 3 nesting '+' and the closing '*'. */
  function styleKey(marker) {
    var k = marker[0] === '+' ? marker.substring(1) : marker;
    return k[k.length - 1] === '*' ? k.substring(0, k.length - 1) : k;
  }

  /**
   * _tokenize_footnote: the inner content as segments {kind: 'text'|'close', marker, text}; the
   * leading text (the caller) has marker null. Every closing token gets its own "close" segment.
   */
  function tokenizeWithCloses(content) {
    var segments = [];
    var outer = null;
    var inner = null;
    var innerDisplay = null;
    var pos = 0;
    R.findAll(SUBMARKER_RE, content).forEach(function (m) {
      flush(segments, content, pos, m.index, inner !== null ? innerDisplay : outer);
      var raw = m[0].substring(1);
      var isClose = raw[raw.length - 1] === '*';
      var bare = raw[0] === '+' ? raw.substring(1) : raw;
      if (isClose) {
        bare = bare.substring(0, bare.length - 1);
        segments.push({ kind: 'close', marker: raw, text: '' });
        if (inner !== null && inner === bare) {
          inner = null;
          innerDisplay = null;
        } else if (outer !== null && outer === bare) outer = null;
      } else if (LEVEL_MARKERS.has(bare)) {
        inner = null;
        innerDisplay = null;
        outer = bare;
      } else {
        inner = bare;
        innerDisplay = raw;
      }
      pos = m.index + m[0].length;
    });
    flush(segments, content, pos, content.length, inner !== null ? innerDisplay : outer);
    return segments;
  }

  function flush(segs, content, start, end, marker) {
    if (end <= start) return;
    segs.push({ kind: 'text', marker: marker, text: content.substring(start, end) });
  }

  return {
    FOOTNOTE_RE: FOOTNOTE_RE,
    SUBMARKER_RE: SUBMARKER_RE,
    LEVEL_MARKERS: LEVEL_MARKERS,
    styleKey: styleKey,
    tokenizeWithCloses: tokenizeWithCloses,
  };
})();

// Phils Checks core, part 5: running a check.
// A port of Project_Checker\ProjectChecker\Checks\CheckBase.cs: the checkAllChapters loop and the
// outputError-style findings.
//
// A check is defined with PC.define({...}):
//   id, cssPrefix, original     as in Project Checker (id is also the key of its strings)
//   kind                        'report' (read-only) for now
//   options: [{name, type: 'bool'|'int'|'text', def}]
//   beginRun(run), beginBook(run, book), checkChapter(run, ch), endBook(run, book), endRun(run)
//   reportCss                   CSS of its report section (classes start with cssPrefix + '-')
//   renderReport(w, result, L)  its report section body; without it, the default grouped table
//   diffData(result)            the original-format report data the tests compare
// The run object gives state (run.state), options (run.opt), the stylesheet (run.sty) and emit.
PC.checks = new Map();

PC.define = function (def) {
  PC.checks.set(def.id, def);
  return def;
};

PC.runCheck = (function () {
  'use strict';

  function Run(def, ctx) {
    this.def = def;
    this.ctx = ctx;
    this.sty = ctx.sty || new Map();
    this.state = {};
    this.result = { checkId: def.id, findings: [], optionsUsed: {}, notes: [], reportData: null, booksRead: [] };
  }

  /** The option's value as a string (the default when not set), as CheckBase.Opt. */
  Run.prototype.opt = function (name) {
    var o = this.ctx.options || {};
    for (var i = 0; i < this.def.options.length; i++) {
      var d = this.def.options[i];
      if (d.name === name) return o[name] !== undefined && o[name] !== null ? String(o[name]) : d.def;
    }
    return o[name] !== undefined && o[name] !== null ? String(o[name]) : '';
  };

  /** checking.outputError(begin, end, msg): a finding in the results list. */
  Run.prototype.emit = function (ch, begin, end, message, category) {
    var b = Math.max(0, Math.min(begin, ch.text.length));
    var e = Math.max(b, Math.min(end, ch.text.length));
    var text = ch.text.substring(b, e);
    var f = {
      checkId: this.def.id,
      category: category,
      bookNum: ch.bookNum,
      bookCode: ch.bookCode,
      chapter: ch.chapter,
      verse: PC.usfm.verseAt(ch.text, begin),
      begin: begin,
      end: end,
      text: text,
      message: message,
      context: PC.usfm.collapseWhitespace(text),
      inList: true,
      extra: {},
      localize: null,
      chapterText: ch.text,
    };
    this.result.findings.push(f);
    return f;
  };

  /** A row that exists only in the original's HTML report (no outputError call). */
  Run.prototype.emitReportOnly = function (bookNum, message, category) {
    var f = {
      checkId: this.def.id,
      category: category,
      bookNum: bookNum,
      bookCode: PC.usfm.bookCode(bookNum),
      chapter: 0,
      verse: '0',
      begin: -1,
      end: -1,
      text: null,
      message: message,
      context: null,
      inList: false,
      extra: {},
      localize: null,
      chapterText: null,
    };
    this.result.findings.push(f);
    return f;
  };

  /**
   * Runs one check. ctx = {books: [{num, code, text}], options: {name: value}, sty: Map}.
   * Books are taken in the order given (book number order).
   */
  function runCheck(def, ctx) {
    var run = new Run(def, ctx);
    def.options.forEach(function (d) {
      run.result.optionsUsed[d.name] = run.opt(d.name);
    });
    if (def.beginRun) def.beginRun(run);
    (ctx.books || []).forEach(function (book) {
      if (book.text === undefined || book.text === null) return;
      run.result.booksRead.push(book.code);
      var chapters = PC.usfm.splitChapters(book.num, book.code, book.text);
      if (def.beginBook) def.beginBook(run, book);
      chapters.forEach(function (ch) {
        def.checkChapter(run, ch);
      });
      if (def.endBook) def.endBook(run, book);
    });
    if (def.endRun) def.endRun(run);
    return run.result;
  }

  return runCheck;
})();

/** Findings as plain rows (no functions, no chapter text) in language lang, for the window. */
PC.findingRows = function (result, lang) {
  var L = PC.report.lang(lang);
  return result.findings.map(function (f, i) {
    var cat = L.str('Cat_' + f.checkId + '_' + f.category);
    return {
      id: i,
      category: f.category,
      categoryText: cat.indexOf('Cat_') === 0 ? f.category : cat,
      book: f.bookCode,
      chapter: f.chapter,
      verse: f.verse,
      inList: f.inList,
      reference: f.inList ? f.bookCode + ' ' + f.chapter + ':' + f.verse : f.bookCode,
      text: f.context,
      message: f.localize ? f.localize(L) : f.message,
    };
  });
};

// Phils Checks core, part 6: the report.
// A port of Project_Checker\ProjectChecker\Services\ReportRenderer.cs (ReportWriter and one check's
// section). The section is an HTML fragment shown inside the extension's window, so its CSS is
// scoped to .pc-report. References are links (a.pc-go with data-ref "BOOK C:V") that the window
// turns into "go to this verse".
PC.report = (function () {
  'use strict';

  var BASE_CSS =
    '{font-family:"Segoe UI",Arial,sans-serif;color:#222;background:#fff}' +
    ' h2{font-size:1.25em;margin:4px 0 8px;border-bottom:2px solid #446;padding-bottom:3px}' +
    ' h3{font-size:1.05em;margin:14px 0 6px}' +
    ' details.pc-opts{margin:6px 0 10px;font-size:.9em}' +
    ' details.pc-opts table{margin-top:4px}' +
    ' .pc-mod{font-weight:bold;color:#7a3c00}' +
    ' .pc-note{background:#fff7d6;border:1px solid #e5cf7a;padding:4px 8px;margin:6px 0}' +
    ' .pc-fail{background:#fde2e2;border:1px solid #d99;padding:4px 8px;margin:6px 0}' +
    ' details.pc-group{margin:6px 0}' +
    ' details.pc-group>summary{cursor:pointer;font-weight:bold;padding:2px 0}' +
    ' table{border-collapse:collapse;margin:4px 0}' +
    ' th,td{border:1px solid #bbb;padding:3px 8px;vertical-align:top;text-align:left}' +
    ' th{background:#eef}' +
    ' a.pc-go{color:#0b5cad;text-decoration:none;cursor:pointer}' +
    ' a.pc-go:hover{text-decoration:underline}';

  /** Prefixes every selector of a CSS text with ".pc-report ". */
  function scope(css) {
    return css
      .split('}')
      .filter(function (rule) {
        return rule.trim().length > 0;
      })
      .map(function (rule) {
        var brace = rule.indexOf('{');
        var selectors = rule.substring(0, brace).split(',');
        return (
          selectors
            .map(function (s) {
              return '.pc-report ' + s.trim();
            })
            .join(',') +
          rule.substring(brace) +
          '}'
        );
      })
      .join('\n');
  }

  /** The CSS for a check's report section. */
  function css(def) {
    return '.pc-report' + BASE_CSS.split('}')[0] + '}\n' + scope(BASE_CSS.substring(BASE_CSS.indexOf('}') + 1)) + '\n' + scope(def.reportCss || defaultCss(def.cssPrefix));
  }

  function defaultCss(p) {
    return '.' + p + '-hl{color:#c00;font-weight:bold}.' + p + '-ref{white-space:nowrap}';
  }

  /** PyText.HtmlEscape: & < > only. */
  function esc(s) {
    if (s === null || s === undefined) return '';
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  /** Escaped for an attribute value. */
  function attr(s) {
    return esc(s).replace(/"/g, '&quot;');
  }

  /** string.Format with {0} {1}... */
  function format(template, args) {
    return String(template).replace(/\{(\d+)\}/g, function (m, n) {
      var v = args[parseInt(n, 10)];
      return v === undefined ? m : String(v);
    });
  }

  /** The strings of one language: str(key) falls back to English, then to the key itself. */
  function lang(code) {
    var table = PC.strings[code] || PC.strings.en;
    function str(key) {
      if (Object.prototype.hasOwnProperty.call(table, key)) return table[key];
      if (Object.prototype.hasOwnProperty.call(PC.strings.en, key)) return PC.strings.en[key];
      return key;
    }
    return {
      code: PC.strings[code] ? code : 'en',
      str: str,
      fmt: function (key) {
        return format(str(key), Array.prototype.slice.call(arguments, 1));
      },
    };
  }

  /** A link that goes to a verse ("MAT 5:3"; a bare book code goes to its start). */
  function refLink(ref, html) {
    return '<a class="pc-go" data-ref="' + attr(ref) + '">' + (html === undefined ? esc(ref) : html) + '</a>';
  }

  function Writer() {
    this.parts = [];
  }
  Writer.prototype.line = function (html) {
    this.parts.push(html + '\n');
    return this;
  };
  Writer.prototype.toString = function () {
    return this.parts.join('');
  };

  /** CheckBase.RenderReport: one collapsible group per category, Reference | Text | Message. */
  function defaultReport(def, w, result, L) {
    if (result.findings.length === 0) {
      w.line('<p>' + esc(L.str('Rpt_NoFindings')) + '</p>');
      return;
    }
    var order = [];
    var groups = new Map();
    result.findings.forEach(function (f) {
      var cat = f.category || '';
      if (!groups.has(cat)) {
        groups.set(cat, []);
        order.push(cat);
      }
      groups.get(cat).push(f);
    });
    order.forEach(function (cat) {
      var title = L.str('Cat_' + def.id + '_' + cat);
      if (title.indexOf('Cat_') === 0) title = cat;
      var list = groups.get(cat);
      w.line('<details class="pc-group" open><summary>' + esc(title) + ' (' + list.length + ')</summary>');
      w.line(
        '<table><tr><th>' + esc(L.str('Rpt_Reference')) + '</th><th>' + esc(L.str('Rpt_Text')) + '</th><th>' +
          esc(L.str('Rpt_Message')) + '</th></tr>',
      );
      list.forEach(function (f) {
        var ref = f.inList ? f.bookCode + ' ' + f.chapter + ':' + f.verse : f.bookCode;
        w.line(
          '<tr><td class="' + def.cssPrefix + '-ref">' + refLink(ref) + '</td><td>' + esc(f.context || '') + '</td><td>' +
            esc(f.localize ? f.localize(L) : f.message || '') + '</td></tr>',
        );
      });
      w.line('</table></details>');
    });
  }

  /** ReportRenderer.AppendOptions */
  function options(def, result, L) {
    if (def.options.length === 0) return '';
    var html =
      '<details class="pc-opts"><summary>' + esc(L.str('Rpt_OptionsUsed')) + '</summary><table><tr><th>' +
      esc(L.str('Rpt_Option')) + '</th><th>' + esc(L.str('Rpt_Value')) + '</th></tr>';
    def.options.forEach(function (d) {
      var v = result.optionsUsed[d.name];
      if (v === undefined) v = d.def;
      var label = L.str('Opt_' + def.id + '_' + d.name + '_Label');
      if (label.indexOf('Opt_') === 0) label = d.name;
      html +=
        '<tr><td>' + esc(label) + ' <code>' + esc(d.name) + '</code></td><td' + (v !== d.def ? ' class="pc-mod"' : '') + '>' +
        esc(v.length === 0 ? '(' + L.str('Rpt_Empty') + ')' : v) + '</td></tr>';
    });
    return html + '</table></details>\n';
  }

  /** One check's section: heading, options used, notes, then the check's own report. */
  function section(def, result, langCode) {
    var L = lang(langCode);
    var parts = [];
    parts.push('<section class="' + def.cssPrefix + '-section">\n');
    parts.push('<h2>' + esc(L.str('Check_' + def.id + '_Name')) + '</h2>\n');
    parts.push(options(def, result, L));
    result.notes.forEach(function (n) {
      parts.push('<p class="pc-note">' + esc(n) + '</p>\n');
    });
    var w = new Writer();
    if (def.renderReport) def.renderReport(w, result, L);
    else defaultReport(def, w, result, L);
    parts.push(w.toString());
    parts.push('</section>\n');
    return parts.join('');
  }

  return {
    css: css,
    esc: esc,
    attr: attr,
    format: format,
    lang: lang,
    refLink: refLink,
    Writer: Writer,
    section: section,
  };
})();

// Generated by tools/make_strings.py from Project Checker's Strings.*.xaml - do not edit.
PC.strings = {
 "en": {
  "Cat_nested_missingplus": "Character style missing +",
  "Cat_shortv1_short": "Short verse 1",
  "Cat_titles_missing": "Missing \\mt",
  "Cat_titles_title": "Title",
  "Check_nested_Desc": "Flags character styles inside footnotes that lack the USFM 3 '+' prefix, for example \\xt instead of \\+xt. Footnote markers such as \\fr, \\fq and \\ft are never flagged. Opening and closing markers are checked separately, so a mismatched pair is caught.",
  "Check_nested_Name": "Report of Nested Styles",
  "Check_shortv1_Desc": "Flags short verse 1 text between a paragraph marker (\\p or \\m) and the next \\p marker. Options let you set the minimum character count and add other paragraph markers to check.",
  "Check_shortv1_Name": "Short Verse 1",
  "Check_titles_Desc": "Lists the main title (\\mt\u2013\\mt3) of each book, formatted as in the stylesheet, and reports books with no \\mt. Options sort the list by title or by running header (\\h) and add an \\h column.",
  "Check_titles_Name": "Report of Titles",
  "Msg_nested_MissingPlus": "Missing +: ",
  "Msg_shortv1_Chars": "{0} chars (set = {1})",
  "Opt_shortv1_CheckOtherMarkers_Label": "Check Other Markers",
  "Opt_shortv1_CheckOtherMarkers_Tip": "Choose Yes to also check additional paragraph markers (listed below) before and after verse 1, in addition to the defaults (\\p and \\m before, \\p after).",
  "Opt_shortv1_MinChars_Label": "Minimum Characters",
  "Opt_shortv1_MinChars_Tip": "Minimum number of characters expected in verse 1 before the next paragraph marker. Shorter verse 1s will be flagged.",
  "Opt_shortv1_OtherMarkers_Label": "Other Markers",
  "Opt_shortv1_OtherMarkers_Tip": "Space-separated list of additional paragraph markers to check (without backslash), e.g.: q q1 q2 q3 q4. Only used when Check Other Markers is Yes.",
  "Opt_titles_DisplayHeader_Label": "Display Header",
  "Opt_titles_DisplayHeader_Tip": "Yes (default) adds a column to the report showing the \\h (running header) text for each book, or \"missing\" if absent. No shows only the \\mt title. Automatically turned on if Sort by Header below is Yes.",
  "Opt_titles_SortByHeader_Label": "Sort by Header",
  "Opt_titles_SortByHeader_Tip": "No (default). Yes sorts the report alphabetically by \\h text instead, overriding Sort by Title above, and automatically displays the Header column even if Display Header above is No (accented/diacritic characters are ignored when determining sort order, but are still displayed normally; books missing \\h text sort to the end).",
  "Opt_titles_SortByTitle_Label": "Sort by Title",
  "Opt_titles_SortByTitle_Tip": "No (default) lists books in canonical scan order. Yes sorts the report alphabetically by \\mt title text instead (accented/diacritic characters are ignored when determining sort order, but are still displayed normally; books with a missing title sort to the end). Overridden by Sort by Header below if that is set to Yes.",
  "Rpt_Book": "Book",
  "Rpt_Empty": "empty",
  "Rpt_Failed": "This check failed: {0}",
  "Rpt_Message": "Message",
  "Rpt_NoFindings": "No findings.",
  "Rpt_Option": "Option",
  "Rpt_OptionsUsed": "Options used",
  "Rpt_Reference": "Reference",
  "Rpt_Text": "Text",
  "Rpt_Value": "Value",
  "Rpt_nested_FootnoteText": "Footnote text",
  "Rpt_nested_H1": "1. Summary",
  "Rpt_nested_H2": "2. Footnotes with issues",
  "Rpt_nested_Marker": "Marker",
  "Rpt_nested_NoFootnotes": "No footnotes with issues were found.",
  "Rpt_nested_NoIssues": "No issues found.",
  "Rpt_nested_Occurrences": "Occurrences",
  "Rpt_nested_Summary": "{0} footnote(s) scanned, {1} flagged with a character style missing its required '+'.",
  "Rpt_shortv1_Chars": "Characters",
  "Rpt_titles_Missing": "missing",
  "Rpt_titles_NoBooks": "No books were scanned.",
  "Rpt_titles_SortH": "\\h text (alphabetically)",
  "Rpt_titles_SortMt": "\\mt title (alphabetically)",
  "Rpt_titles_SortRef": "canonical scan order",
  "Rpt_titles_SortedBy": "Sorted by {0}.",
  "Rpt_titles_Summary": "{0} book(s) scanned, {1} title(s) found, {2} missing."
 },
 "es": {
  "Cat_nested_missingplus": "Estilo de car\u00e1cter sin +",
  "Cat_shortv1_short": "Vers\u00edculo 1 corto",
  "Cat_titles_missing": "\\mt ausente",
  "Cat_titles_title": "T\u00edtulo",
  "Check_nested_Desc": "Marca los estilos de car\u00e1cter en notas al pie sin el prefijo '+' de USFM 3, por ejemplo \\xt en lugar de \\+xt. Nunca marca los marcadores propios de la nota (\\fr, \\fq, \\ft). Aperturas y cierres se revisan por separado, as\u00ed que se detecta un par desigual.",
  "Check_nested_Name": "Informe de estilos anidados",
  "Check_shortv1_Desc": "Marca el texto breve del vers\u00edculo 1 entre un marcador de p\u00e1rrafo (\\p o \\m) y el siguiente marcador \\p. Las opciones permiten definir la cantidad m\u00ednima de caracteres y agregar otros marcadores de p\u00e1rrafo a verificar.",
  "Check_shortv1_Name": "Vers\u00edculo 1 corto",
  "Check_titles_Desc": "Lista el t\u00edtulo principal (\\mt\u2013\\mt3) de cada libro, con el formato de la hoja de estilos, e informa de los libros sin \\mt. Las opciones ordenan la lista por t\u00edtulo o por encabezado (\\h) y a\u00f1aden una columna con \\h.",
  "Check_titles_Name": "Informe de los t\u00edtulos",
  "Msg_nested_MissingPlus": "Falta +: ",
  "Msg_shortv1_Chars": "{0} caracteres (m\u00ednimo = {1})",
  "Opt_shortv1_CheckOtherMarkers_Label": "Verificar otros marcadores",
  "Opt_shortv1_CheckOtherMarkers_Tip": "Elija S\u00ed para tambi\u00e9n verificar marcadores de p\u00e1rrafo adicionales (listados abajo) antes y despu\u00e9s del vers\u00edculo 1, adem\u00e1s de los predeterminados (\\p y \\m antes, \\p despu\u00e9s).",
  "Opt_shortv1_MinChars_Label": "Caracteres m\u00ednimos",
  "Opt_shortv1_MinChars_Tip": "N\u00famero m\u00ednimo de caracteres esperados en el vers\u00edculo 1 antes del siguiente marcador de p\u00e1rrafo. Se marcar\u00e1n los vers\u00edculos 1 m\u00e1s cortos que esto.",
  "Opt_shortv1_OtherMarkers_Label": "Otros marcadores",
  "Opt_shortv1_OtherMarkers_Tip": "Lista separada por espacios de marcadores de p\u00e1rrafo adicionales a verificar (sin barra invertida), p. ej.: q q1 q2 q3 q4. Solo se usa cuando Verificar otros marcadores es S\u00ed.",
  "Opt_titles_DisplayHeader_Label": "Mostrar encabezado",
  "Opt_titles_DisplayHeader_Tip": "S\u00ed (predeterminado) agrega una columna al informe que muestra el texto \\h (encabezado de p\u00e1gina) de cada libro, o \"ausente\" si no est\u00e1 presente. No muestra solo el t\u00edtulo \\mt. Se activa autom\u00e1ticamente si Ordenar por encabezado est\u00e1 en S\u00ed.",
  "Opt_titles_SortByHeader_Label": "Ordenar por encabezado",
  "Opt_titles_SortByHeader_Tip": "No (predeterminado). S\u00ed ordena el informe alfab\u00e9ticamente por el texto \\h en su lugar, anulando Ordenar por t\u00edtulo, y muestra autom\u00e1ticamente la columna de encabezado aunque Mostrar encabezado est\u00e9 en No (los caracteres acentuados/diacr\u00edticos se ignoran al determinar el orden, pero se siguen mostrando normalmente; los libros sin texto \\h se ordenan al final).",
  "Opt_titles_SortByTitle_Label": "Ordenar por t\u00edtulo",
  "Opt_titles_SortByTitle_Tip": "No (predeterminado) lista los libros en el orden can\u00f3nico de escaneo. S\u00ed ordena el informe alfab\u00e9ticamente por el texto del t\u00edtulo \\mt en su lugar (los caracteres acentuados/diacr\u00edticos se ignoran al determinar el orden, pero se siguen mostrando normalmente; los libros con t\u00edtulo ausente se ordenan al final). Anulado por Ordenar por encabezado si este est\u00e1 en S\u00ed.",
  "Rpt_Book": "Libro",
  "Rpt_Empty": "vac\u00edo",
  "Rpt_Failed": "Esta verificaci\u00f3n fall\u00f3: {0}",
  "Rpt_Message": "Mensaje",
  "Rpt_NoFindings": "No se encontr\u00f3 nada.",
  "Rpt_Option": "Opci\u00f3n",
  "Rpt_OptionsUsed": "Opciones usadas",
  "Rpt_Reference": "Referencia",
  "Rpt_Text": "Texto",
  "Rpt_Value": "Valor",
  "Rpt_nested_FootnoteText": "Texto de la nota",
  "Rpt_nested_H1": "1. Resumen",
  "Rpt_nested_H2": "2. Notas al pie con problemas",
  "Rpt_nested_Marker": "Marcador",
  "Rpt_nested_NoFootnotes": "No se encontraron notas al pie con problemas.",
  "Rpt_nested_NoIssues": "No se encontraron problemas.",
  "Rpt_nested_Occurrences": "Ocurrencias",
  "Rpt_nested_Summary": "Se escanearon {0} nota(s) al pie; se marcaron {1} con un estilo de car\u00e1cter al que le falta el '+' requerido.",
  "Rpt_shortv1_Chars": "Caracteres",
  "Rpt_titles_Missing": "ausente",
  "Rpt_titles_NoBooks": "No se escane\u00f3 ning\u00fan libro.",
  "Rpt_titles_SortH": "el texto \\h (alfab\u00e9ticamente)",
  "Rpt_titles_SortMt": "el t\u00edtulo \\mt (alfab\u00e9ticamente)",
  "Rpt_titles_SortRef": "el orden can\u00f3nico de escaneo",
  "Rpt_titles_SortedBy": "Ordenado por {0}.",
  "Rpt_titles_Summary": "{0} libro(s) escaneado(s), {1} t\u00edtulo(s) encontrado(s), {2} ausente(s)."
 },
 "fr": {
  "Cat_nested_missingplus": "Style de caract\u00e8re sans +",
  "Cat_shortv1_short": "Verset 1 court",
  "Cat_titles_missing": "\\mt absent",
  "Cat_titles_title": "Titre",
  "Check_nested_Desc": "Signale les styles de caract\u00e8re des notes de bas de page sans le pr\u00e9fixe '+' de USFM 3, par exemple \\xt au lieu de \\+xt. Les marqueurs propres aux notes (\\fr, \\fq, \\ft) ne sont jamais signal\u00e9s. Ouvrants et fermants sont v\u00e9rifi\u00e9s s\u00e9par\u00e9ment, ce qui d\u00e9tecte une paire mal assortie.",
  "Check_nested_Name": "Rapport des styles imbriqu\u00e9s",
  "Check_shortv1_Desc": "Signale un texte court du verset 1 entre un marqueur de paragraphe (\\p ou \\m) et le marqueur \\p suivant. Les options permettent de d\u00e9finir le nombre minimal de caract\u00e8res et d'ajouter d'autres marqueurs de paragraphe \u00e0 v\u00e9rifier.",
  "Check_shortv1_Name": "Verset 1 court",
  "Check_titles_Desc": "Liste le titre principal (\\mt\u2013\\mt3) de chaque livre, mis en forme selon la feuille de style, et signale les livres sans \\mt. Les options trient la liste par titre ou par en-t\u00eate courant (\\h) et ajoutent une colonne \\h.",
  "Check_titles_Name": "Rapport des titres",
  "Msg_nested_MissingPlus": "+ manquant : ",
  "Msg_shortv1_Chars": "{0} caract\u00e8res (minimum = {1})",
  "Opt_shortv1_CheckOtherMarkers_Label": "V\u00e9rifier d'autres marqueurs",
  "Opt_shortv1_CheckOtherMarkers_Tip": "Choisissez \u00ab Oui \u00bb pour v\u00e9rifier aussi d'autres marqueurs de paragraphe (list\u00e9s ci-dessous) avant et apr\u00e8s le verset 1, en plus de ceux par d\u00e9faut (\\p et \\m avant, \\p apr\u00e8s).",
  "Opt_shortv1_MinChars_Label": "Nombre minimal de caract\u00e8res",
  "Opt_shortv1_MinChars_Tip": "Nombre minimal de caract\u00e8res attendus dans le verset 1 avant le marqueur de paragraphe suivant. Les versets 1 plus courts seront signal\u00e9s.",
  "Opt_shortv1_OtherMarkers_Label": "Autres marqueurs",
  "Opt_shortv1_OtherMarkers_Tip": "Liste, s\u00e9par\u00e9e par des espaces, de marqueurs de paragraphe suppl\u00e9mentaires \u00e0 v\u00e9rifier (sans barre oblique inverse), p. ex. : q q1 q2 q3 q4. Utilis\u00e9 uniquement lorsque \u00ab V\u00e9rifier d'autres marqueurs \u00bb est r\u00e9gl\u00e9 sur \u00ab Oui \u00bb.",
  "Opt_titles_DisplayHeader_Label": "Afficher l'en-t\u00eate",
  "Opt_titles_DisplayHeader_Tip": "\u00ab Oui \u00bb (par d\u00e9faut) ajoute au rapport une colonne affichant le texte de \\h (titre courant) de chaque livre, ou \u00ab manquant \u00bb s'il est absent. \u00ab Non \u00bb affiche uniquement le titre \\mt. Activ\u00e9 automatiquement si \u00ab Trier par en-t\u00eate \u00bb ci-dessous est r\u00e9gl\u00e9 sur \u00ab Oui \u00bb.",
  "Opt_titles_SortByHeader_Label": "Trier par en-t\u00eate",
  "Opt_titles_SortByHeader_Tip": "\u00ab Non \u00bb (par d\u00e9faut). \u00ab Oui \u00bb trie plut\u00f4t le rapport par ordre alphab\u00e9tique du texte de \\h, en rempla\u00e7ant \u00ab Trier par titre \u00bb ci-dessus, et affiche automatiquement la colonne \u00ab En-t\u00eate \u00bb m\u00eame si \u00ab Afficher l'en-t\u00eate \u00bb ci-dessus est r\u00e9gl\u00e9 sur \u00ab Non \u00bb (les caract\u00e8res accentu\u00e9s/diacritiques sont ignor\u00e9s pour d\u00e9terminer l'ordre de tri, mais restent affich\u00e9s normalement ; les livres sans texte \\h sont plac\u00e9s \u00e0 la fin).",
  "Opt_titles_SortByTitle_Label": "Trier par titre",
  "Opt_titles_SortByTitle_Tip": "\u00ab Non \u00bb (par d\u00e9faut) r\u00e9pertorie les livres dans l'ordre canonique d'analyse. \u00ab Oui \u00bb trie plut\u00f4t le rapport par ordre alphab\u00e9tique du texte du titre \\mt (les caract\u00e8res accentu\u00e9s/diacritiques sont ignor\u00e9s pour d\u00e9terminer l'ordre de tri, mais restent affich\u00e9s normalement ; les livres sans titre sont plac\u00e9s \u00e0 la fin). Remplac\u00e9 par \u00ab Trier par en-t\u00eate \u00bb ci-dessous si cette option est r\u00e9gl\u00e9e sur \u00ab Oui \u00bb.",
  "Rpt_Book": "Livre",
  "Rpt_Empty": "vide",
  "Rpt_Failed": "Cette v\u00e9rification a \u00e9chou\u00e9 : {0}",
  "Rpt_Message": "Message",
  "Rpt_NoFindings": "Aucun r\u00e9sultat.",
  "Rpt_Option": "Option",
  "Rpt_OptionsUsed": "Options utilis\u00e9es",
  "Rpt_Reference": "R\u00e9f\u00e9rence",
  "Rpt_Text": "Texte",
  "Rpt_Value": "Valeur",
  "Rpt_nested_FootnoteText": "Texte de la note",
  "Rpt_nested_H1": "1. R\u00e9sum\u00e9",
  "Rpt_nested_H2": "2. Notes de bas de page avec probl\u00e8mes",
  "Rpt_nested_Marker": "Marqueur",
  "Rpt_nested_NoFootnotes": "Aucune note avec probl\u00e8me n'a \u00e9t\u00e9 trouv\u00e9e.",
  "Rpt_nested_NoIssues": "Aucun probl\u00e8me trouv\u00e9.",
  "Rpt_nested_Occurrences": "Occurrences",
  "Rpt_nested_Summary": "{0} note(s) analys\u00e9e(s), {1} signal\u00e9e(s) avec un style de caract\u00e8re sans le '+' requis.",
  "Rpt_shortv1_Chars": "Caract\u00e8res",
  "Rpt_titles_Missing": "absent",
  "Rpt_titles_NoBooks": "Aucun livre n'a \u00e9t\u00e9 analys\u00e9.",
  "Rpt_titles_SortH": "texte \\h (ordre alphab\u00e9tique)",
  "Rpt_titles_SortMt": "titre \\mt (ordre alphab\u00e9tique)",
  "Rpt_titles_SortRef": "ordre canonique d'analyse",
  "Rpt_titles_SortedBy": "Tri\u00e9 par {0}.",
  "Rpt_titles_Summary": "{0} livre(s) analys\u00e9(s), {1} titre(s) trouv\u00e9(s), {2} absent(s)."
 }
};

// Short Verse 1: a port of Project_Checker\ProjectChecker\Checks\ShortVerse1Check.cs
// (CMS/Short_V_1/short_v_1.py). Flags a short verse-1 text between a paragraph marker (\p or \m,
// plus OtherMarkers when CheckOtherMarkers is Yes) and the next \p (plus OtherMarkers).
(function () {
  'use strict';
  var R = PC.re;
  var T = PC.text;

  // short_v_1.py INLINE_RE: footnotes / cross-references on one line only.
  var INLINE_RE = R.compile('\\\\f\\s[^\\r\\n]*?\\\\f\\*|\\\\x\\s[^\\r\\n]*?\\\\x\\*', R.UNICODE);
  var VERSE1_RE = R.compile('\\\\v\\s+1(?!\\d)(?:-\\d+)?[ \\t\\r\\n]+', R.UNICODE);
  // All paragraph-type markers: used to find the marker just before \v 1.
  var ALL_PARA_RE = R.compile('\\\\(p(?:[crhi]\\d?)?|q[a-z]?\\d?|mi?|nb|b|li\\d?)(?=[\\s\\\\]|$)', R.UNICODE | R.MULTILINE);
  var CHAR_MARKER_RE = R.compile('\\\\[a-zA-Z]+\\d*\\*?\\s*', R.UNICODE);

  PC.define({
    id: 'shortv1',
    cssPrefix: 'sv',
    original: 'Short_V_1/short_v_1.py',
    kind: 'report',
    options: [
      { name: 'MinChars', type: 'int', def: '40' },
      { name: 'CheckOtherMarkers', type: 'bool', def: 'No' },
      { name: 'OtherMarkers', type: 'text', def: 'q q1 q2 q3 q4' },
    ],

    beginRun: function (run) {
      var before = new Set(['p', 'm']);
      var after = ['p'];
      if (T.isYes(run.opt('CheckOtherMarkers'))) {
        T.split(run.opt('OtherMarkers')).forEach(function (m) {
          var t = T.strip(m);
          if (t.length === 0) return;
          before.add(t);
          if (after.indexOf(t) < 0) after.push(t);
        });
      }
      // Longest first, so \q1 is tried before \q. (The C# sort is not stable; equal lengths
      // cannot change what matches here, because the lookahead needs a space or backslash.)
      after.sort(function (a, b) {
        return b.length - a.length;
      });
      var minChars = T.strip(run.opt('MinChars'));
      if (!/^[+-]?\d+$/.test(minChars)) throw new Error('MinChars is not a whole number: ' + run.opt('MinChars'));
      run.state = {
        before: before,
        afterRe: R.compile('\\\\(' + after.map(R.escape).join('|') + ')(?=[\\s\\\\]|$)', R.UNICODE | R.MULTILINE),
        minChars: parseInt(minChars, 10),
      };
    },

    checkChapter: function (run, ch) {
      var s = run.state;
      var clean = PC.usfm.blank(INLINE_RE, ch.text);
      var v1 = R.search(VERSE1_RE, clean, 0);
      if (!v1) return;

      // The paragraph marker just before \v 1 must be in the "before" set.
      var prev = R.findAll(ALL_PARA_RE, clean, 0, v1.index);
      if (prev.length === 0 || !s.before.has(prev[prev.length - 1][1])) return;

      // The next paragraph marker after verse 1's content must be in the "after" set.
      var contentStart = v1.index + v1[0].length;
      var next = R.search(s.afterRe, clean, contentStart);
      if (!next) return;

      var contentEnd = next.index;
      var verse1Text = clean.substring(contentStart, contentEnd);
      var count = T.strip(R.sub(CHAR_MARKER_RE, verse1Text, '')).length;
      if (count < s.minChars) {
        var displayEnd = contentEnd;
        while (displayEnd > contentStart && '\r\n\t '.indexOf(clean[displayEnd - 1]) >= 0) displayEnd--;
        var f = run.emit(ch, v1.index, displayEnd, count + ' chars (set = ' + s.minChars + ')', 'short');
        f.extra.chars = String(count);
        var min = s.minChars;
        f.localize = function (L) {
          return L.fmt('Msg_shortv1_Chars', count, min);
        };
      }
    },
  });
})();

// Report of Titles: a port of Project_Checker\ProjectChecker\Checks\TitlesCheck.cs
// (CMS/find_titles/Find_Titles.py). Lists the \mt / \mt1-9 title of each canonical book (1-66),
// optionally with \h, styled from the stylesheet; books with no \mt are reported as missing.
(function () {
  'use strict';
  var R = PC.re;
  var T = PC.text;
  var esc = PC.report.esc;

  // Only bare \h and \mt with zero or one digit (Find_Titles.py HEADER_MARKER_RE).
  var HEADER_RE = R.compile('^\\\\(mt[0-9]?|h)[ \\t]+([^\\r\\n]*)', R.UNICODE | R.MULTILINE);
  var WS_RUN_RE = R.compile('[ \\t]+', R.UNICODE);

  function yes(v) {
    return T.lower(T.strip(v || '')) === 'yes';
  }

  function inScope(n) {
    return n >= 1 && n <= 66;
  }

  function collapseWs(s) {
    return R.sub(WS_RUN_RE, s.replace(/\r/g, '').replace(/\n/g, ' '), ' ');
  }

  // A literal // in \mt text forces a soft line break; it is not part of the wording.
  function stripMtSoftBreaks(s) {
    return T.strip(collapseWs(s.split('//').join(' ')));
  }

  function mtLabel(segs, missing) {
    if (!segs) return missing;
    return segs
      .map(function (kv) {
        return '\\' + kv[0] + ' ' + kv[1];
      })
      .join(' ');
  }

  // _flush_book: only for a book with NO \mt or \h anywhere; the row is report-only.
  function flushBook(run, bookNum) {
    var s = run.state;
    if (bookNum === null || !inScope(bookNum)) return;
    if (s.resolved) return;
    s.missingCount++;
    s.rows.push({ bookNum: bookNum, bookLabel: PC.usfm.bookCode(bookNum), mtCombined: null, mtSegments: null, hText: null });
    var f = run.emitReportOnly(bookNum, 'missing', 'missing');
    f.localize = function (L) {
      return L.str('Rpt_titles_Missing');
    };
  }

  /** Python sorted(key=(missing, _sort_fold(value), book_num)); missing last. */
  function stableSort(rows, value) {
    return rows
      .map(function (r, i) {
        return { i: i, r: r };
      })
      .sort(function (a, b) {
        var va = value(a.r);
        var vb = value(b.r);
        var ma = va === null ? 1 : 0;
        var mb = vb === null ? 1 : 0;
        if (ma !== mb) return ma - mb;
        var c = T.compare(va === null ? '' : T.sortFold(va), vb === null ? '' : T.sortFold(vb));
        if (c !== 0) return c;
        if (a.r.bookNum !== b.r.bookNum) return a.r.bookNum - b.r.bookNum;
        return a.i - b.i;
      })
      .map(function (x) {
        return x.r;
      });
  }

  function orderedRows(d) {
    if (d.sortMode === 'mt')
      return stableSort(d.rows, function (r) {
        return r.mtCombined;
      });
    if (d.sortMode === 'h')
      return stableSort(d.rows, function (r) {
        return r.hText ? r.hText : null;
      });
    return d.rows.slice();
  }

  function mtCell(d, r, missingHtml) {
    if (r.mtCombined === null) return missingHtml;
    if (!r.mtSegments || r.mtSegments.length === 0) return esc(r.mtCombined);
    var parts = [];
    r.mtSegments.forEach(function (kv) {
      if (kv[1].length === 0) return;
      var css = PC.sty.markerCss(d.sty.get(kv[0]));
      var style = css.length > 0 ? ' style="' + css + '"' : '';
      parts.push('<span' + style + '>' + esc(kv[1]) + '</span>');
    });
    return parts.length > 0 ? parts.join(' ') : esc(r.mtCombined);
  }

  function hCell(r, missingHtml) {
    return r.hText ? esc(r.hText) : missingHtml;
  }

  PC.define({
    id: 'titles',
    cssPrefix: 'ti',
    original: 'find_titles/Find_Titles.py',
    kind: 'report',
    options: [
      { name: 'SortByTitle', type: 'bool', def: 'No' },
      { name: 'DisplayHeader', type: 'bool', def: 'Yes' },
      { name: 'SortByHeader', type: 'bool', def: 'No' },
    ],
    reportCss: '.ti-missing{color:#999;font-style:italic}.ti-table td:first-child{font-weight:bold}',

    beginRun: function (run) {
      var byTitle = yes(run.opt('SortByTitle'));
      var byHeader = yes(run.opt('SortByHeader'));
      run.state = {
        displayH: yes(run.opt('DisplayHeader')) || byHeader,
        sortMode: byHeader ? 'h' : byTitle ? 'mt' : 'reference',
        prevBook: null,
        resolved: false,
        hText: null,
        seenBooks: new Set(),
        rows: [],
        titleCount: 0,
        missingCount: 0,
        sty: run.sty,
      };
    },

    checkChapter: function (run, ch) {
      var s = run.state;
      var bookNum = ch.bookNum;
      if (s.prevBook === null || bookNum !== s.prevBook) {
        flushBook(run, s.prevBook);
        s.prevBook = bookNum;
        s.resolved = false;
        s.hText = null;
      }
      if (!inScope(bookNum)) return;
      s.seenBooks.add(bookNum);
      if (s.resolved) return;

      var matches = R.findAll(HEADER_RE, ch.text);
      if (matches.length === 0) return;

      var h = null;
      var mtParts = [];
      matches.forEach(function (m) {
        var kind = m[1];
        var val = T.strip(collapseWs(m[2]));
        if (kind === 'h' && h === null) h = val;
        else if (kind.indexOf('mt') === 0) mtParts.push([kind, val]);
      });
      if (h === null && mtParts.length === 0) return;

      s.resolved = true;
      s.hText = h;
      var mtCombined = null;
      var mtSegments = null;
      var anchor = 0;
      var label;
      var i;
      if (mtParts.length > 0) {
        s.titleCount++;
        for (i = 0; i < matches.length; i++)
          if (matches[i][1].indexOf('mt') === 0) {
            anchor = matches[i].index;
            break;
          }
        // In document order: some books put \mt2 before \mt1.
        var vals = [];
        mtSegments = [];
        mtParts.forEach(function (kv) {
          if (kv[1].length === 0) return;
          vals.push(kv[1]);
          mtSegments.push([kv[0], stripMtSoftBreaks(kv[1])]);
        });
        mtCombined = stripMtSoftBreaks(vals.join(' '));
        label = mtLabel(mtSegments);
      } else {
        s.missingCount++;
        for (i = 0; i < matches.length; i++)
          if (matches[i][1] === 'h') {
            anchor = matches[i].index;
            break;
          }
        label = 'missing';
      }
      var message = label;
      if (s.displayH) message = label + '  \\h ' + (h ? h : 'missing');

      // Zero-width anchor: go-to works, Paratext's TEXT column stays empty.
      var f = run.emit(ch, anchor, anchor, message, mtCombined !== null ? 'title' : 'missing');
      var segs = mtSegments;
      var hCopy = h;
      var displayH = s.displayH;
      f.localize = function (L) {
        var miss = L.str('Rpt_titles_Missing');
        var lbl = mtLabel(segs, miss);
        return displayH ? lbl + '  \\h ' + (hCopy ? hCopy : miss) : lbl;
      };
      f.context = mtCombined !== null ? mtCombined : '';
      if (h !== null) f.extra.h = h;
      if (mtCombined !== null) f.extra.mt = mtCombined;
      s.rows.push({ bookNum: bookNum, bookLabel: PC.usfm.bookCode(bookNum), mtCombined: mtCombined, mtSegments: mtSegments, hText: s.hText });
    },

    endRun: function (run) {
      flushBook(run, run.state.prevBook);
      run.result.reportData = run.state;
    },

    renderReport: function (w, result, L) {
      var d = result.reportData;
      if (!d) return;
      var missing = '<span class="ti-missing">' + esc(L.str('Rpt_titles_Missing')) + '</span>';
      w.line('<p>' + esc(L.fmt('Rpt_titles_Summary', d.seenBooks.size, d.titleCount, d.missingCount)) + '</p>');
      if (d.rows.length === 0) {
        w.line('<p><i>' + esc(L.str('Rpt_titles_NoBooks')) + '</i></p>');
        return;
      }
      var sortKey = d.sortMode === 'mt' ? 'Rpt_titles_SortMt' : d.sortMode === 'h' ? 'Rpt_titles_SortH' : 'Rpt_titles_SortRef';
      w.line('<p>' + esc(L.fmt('Rpt_titles_SortedBy', L.str(sortKey))) + '</p>');
      w.line('<table class="ti-table"><tr><th>' + esc(L.str('Rpt_Book')) + '</th><th>\\mt</th>' + (d.displayH ? '<th>\\h</th>' : '') + '</tr>');
      orderedRows(d).forEach(function (r) {
        w.line(
          '<tr><td>' + PC.report.refLink(r.bookLabel + ' 1:0', esc(r.bookLabel)) + '</td><td>' + mtCell(d, r, missing) + '</td>' +
            (d.displayH ? '<td>' + hCell(r, missing) + '</td>' : '') + '</tr>',
        );
      });
      w.line('</table>');
    },

    diffData: function (result) {
      var d = result.reportData;
      if (!d) return null;
      var missing = '<span class="missing">missing</span>';
      var rows = orderedRows(d).map(function (r) {
        var cells = [r.bookLabel, mtCell(d, r, missing)];
        if (d.displayH) cells.push(hCell(r, missing));
        return cells;
      });
      var sortLabel = d.sortMode === 'mt' ? '\\mt title (alphabetically)' : d.sortMode === 'h' ? '\\h text (alphabetically)' : 'canonical scan order';
      return {
        summary: d.seenBooks.size + ' book(s) scanned, ' + d.titleCount + ' title(s) found, ' + d.missingCount + ' missing.',
        sort: 'Sorted by ' + sortLabel + '.',
        rows: rows,
      };
    },
  });
})();

// Report of Nested Styles: a port of Project_Checker\ProjectChecker\Checks\NestedStylesCheck.cs
// (CMS/report_nested_styles/report_nested_styles.py). Flags character styles inside \f...\f* that
// lack the USFM 3 '+' (\xt instead of \+xt). Footnote-level markers are never flagged; markers the
// stylesheet does not declare as StyleType Character are out of scope.
(function () {
  'use strict';
  var R = PC.re;
  var T = PC.text;
  var FN = PC.footnotes;
  var esc = PC.report.esc;

  var CHAPTER_RE = R.compile('\\\\c\\s+(\\d+)', R.UNICODE);
  var VERSE_RE = R.compile('\\\\v\\s+(\\d+(?:[,-]\\d+)*)\\s*', R.UNICODE);
  var WS_RUN_RE = R.compile('[ \\t]+', R.UNICODE);

  /** _is_issue: a known character style token missing its '+'. */
  function isIssue(d, raw) {
    var hasPlus = raw[0] === '+';
    var bare = hasPlus ? raw.substring(1) : raw;
    var key = bare[bare.length - 1] === '*' ? bare.substring(0, bare.length - 1) : bare;
    if (FN.LEVEL_MARKERS.has(key)) return false;
    if (!d.characterStyles.has(key)) return false;
    return !hasPlus;
  }

  function collapseWs(s) {
    return R.sub(WS_RUN_RE, s.replace(/\r/g, '').replace(/\n/g, ' '), ' ');
  }

  /** _render_segments, with CSS class names supplied by the caller. */
  function renderSegments(d, segments, tag, tagErr, indent) {
    var out = '';
    segments.forEach(function (seg) {
      var marker = seg.marker;
      if (seg.kind === 'close') {
        out += '<span class="' + (isIssue(d, marker) ? tag + ' ' + tagErr : tag) + '">' + esc(marker) + '</span>';
        return;
      }
      if (marker === 'fp') out += '<br><span class="' + indent + '"></span>';
      var text = esc(collapseWs(seg.text));
      if (T.strip(text).length === 0) return;
      if (marker === null) {
        out += '<span>' + text + '</span>';
        return;
      }
      var css = PC.sty.markerCss(d.sty.get(FN.styleKey(marker)));
      var style = css.length > 0 ? ' style="' + css + '"' : '';
      var cls = isIssue(d, marker) ? tag + ' ' + tagErr : tag;
      out += '<span class="' + cls + '">' + esc(marker) + '</span><span' + style + '>' + text + '</span>';
    });
    return out;
  }

  function sortedCounts(d) {
    var list = Array.from(d.issueCounts.entries());
    list.sort(function (a, b) {
      if (a[1] !== b[1]) return b[1] - a[1];
      return T.compare(a[0], b[0]);
    });
    return list;
  }

  PC.define({
    id: 'nested',
    cssPrefix: 'ns',
    original: 'report_nested_styles/report_nested_styles.py',
    kind: 'report',
    options: [],
    reportCss:
      '.ns-tag{display:inline-block;font-size:10px;font-family:monospace;color:#666;background:#eee;' +
      'border:1px solid #ccc;border-radius:3px;padding:0 3px;margin:0 3px 0 8px;vertical-align:middle}' +
      '.ns-tag-err{color:#c00;background:#fee;border-color:#c00;font-weight:bold}' +
      '.ns-indent{display:inline-block;width:2ch}',

    beginRun: function (run) {
      run.state = {
        sty: run.sty,
        characterStyles: PC.sty.characterStyles(run.sty),
        issueCounts: new Map(),
        occurrences: [],
        total: 0,
        flagged: 0,
      };
    },

    checkChapter: function (run, ch) {
      var d = run.state;
      var bookLabel = ch.bookNum >= 1 && ch.bookNum <= 66 ? ch.bookCode : 'Book ' + ch.bookNum;
      var cm = R.search(CHAPTER_RE, ch.text, 0);
      var chapterLabel = cm ? cm[1] : '?';
      var verses = R.findAll(VERSE_RE, ch.text).map(function (vm) {
        return [vm.index + vm[0].length, vm[1]];
      });

      R.findAll(FN.FOOTNOTE_RE, ch.text).forEach(function (m) {
        d.total++;
        var content = m[1];
        var issues = [];
        R.findAll(FN.SUBMARKER_RE, content).forEach(function (t) {
          var display = t[0].substring(1);
          if (isIssue(d, display)) issues.push(display);
        });
        if (issues.length === 0) return;

        d.flagged++;
        issues.forEach(function (code) {
          d.issueCounts.set(code, (d.issueCounts.get(code) || 0) + 1);
        });
        var list = Array.from(new Set(issues)).sort(T.compare).join(', ');
        var f = run.emit(ch, m.index, m.index + m[0].length, 'Missing +: ' + list, 'missingplus');
        f.localize = function (L) {
          return L.str('Msg_nested_MissingPlus') + list;
        };

        // _verse_at: the last \v whose end (after trailing spaces) is <= the offset, else "-".
        var v = null;
        for (var i = 0; i < verses.length; i++) {
          if (verses[i][0] <= m.index) v = verses[i][1];
          else break;
        }
        d.occurrences.push({
          ref: bookLabel + ' ' + chapterLabel + ':' + (v === null ? '-' : v),
          linkRef: ch.bookCode + ' ' + ch.chapter + ':' + PC.usfm.verseAt(ch.text, m.index),
          segments: FN.tokenizeWithCloses(content),
        });
      });
    },

    endRun: function (run) {
      run.result.reportData = run.state;
    },

    renderReport: function (w, result, L) {
      var d = result.reportData;
      if (!d) return;
      w.line('<h3>' + esc(L.str('Rpt_nested_H1')) + '</h3>');
      w.line('<p>' + esc(L.fmt('Rpt_nested_Summary', d.total, d.flagged)) + '</p>');
      if (d.issueCounts.size === 0) w.line('<p><i>' + esc(L.str('Rpt_nested_NoIssues')) + '</i></p>');
      else {
        w.line('<table><tr><th>' + esc(L.str('Rpt_nested_Marker')) + '</th><th>' + esc(L.str('Rpt_nested_Occurrences')) + '</th></tr>');
        sortedCounts(d).forEach(function (kv) {
          w.line('<tr><td>\\' + esc(kv[0]) + '</td><td>' + kv[1] + '</td></tr>');
        });
        w.line('</table>');
      }
      w.line('<h3>' + esc(L.str('Rpt_nested_H2')) + '</h3>');
      if (d.occurrences.length === 0) {
        w.line('<p><i>' + esc(L.str('Rpt_nested_NoFootnotes')) + '</i></p>');
        return;
      }
      w.line('<details class="pc-group" open><summary>' + esc(L.str('Rpt_nested_H2')) + ' (' + d.occurrences.length + ')</summary>');
      w.line('<table><tr><th>' + esc(L.str('Rpt_Reference')) + '</th><th>' + esc(L.str('Rpt_nested_FootnoteText')) + '</th></tr>');
      d.occurrences.forEach(function (o) {
        w.line(
          '<tr><td><b>' + PC.report.refLink(o.linkRef, esc(o.ref)) + '</b></td><td>' +
            renderSegments(d, o.segments, 'ns-tag', 'ns-tag-err', 'ns-indent') + '</td></tr>',
        );
      });
      w.line('</table></details>');
    },

    diffData: function (result) {
      var d = result.reportData;
      if (!d) return null;
      return {
        summary: d.total + ' footnote(s) scanned, ' + d.flagged + ' flagged with a character style missing its required &#39;+&#39;.',
        counts: sortedCounts(d).map(function (kv) {
          return ['\\' + esc(kv[0]), String(kv[1])];
        }),
        rows: d.occurrences.map(function (o) {
          return [esc(o.ref), renderSegments(d, o.segments, 'tag', 'tag-err', 'indent')];
        }),
      };
    },
  });
})();

const PCX_VERSION = "0.1.0";
const PCX_WEB_VIEW_HTML = "<!doctype html>\n<html>\n  <head>\n    <meta charset=\"utf-8\" />\n    <style>\n      :root {\n        --bg: #ffffff;\n        --fg: #1f2328;\n        --muted: #59636e;\n        --line: #d0d7de;\n        --head: #f3f5f7;\n        --sel: #dbeafe;\n        --accent: #0b6bcb;\n        --warn: #9a3412;\n      }\n      @media (prefers-color-scheme: dark) {\n        :root {\n          --bg: #1e1f22;\n          --fg: #e6e6e6;\n          --muted: #a0a6ad;\n          --line: #3a3d42;\n          --head: #2a2c30;\n          --sel: #1e3a5f;\n          --accent: #6cb6ff;\n          --warn: #fdba74;\n        }\n      }\n      html,\n      body {\n        margin: 0;\n        height: 100%;\n        background: var(--bg);\n        color: var(--fg);\n        font: 13px/1.4 'Segoe UI', system-ui, sans-serif;\n      }\n      body {\n        display: flex;\n        gap: 10px;\n        padding: 8px 12px;\n        box-sizing: border-box;\n      }\n      #left {\n        width: 260px;\n        flex: none;\n        display: flex;\n        flex-direction: column;\n        gap: 6px;\n      }\n      #right {\n        flex: 1;\n        min-width: 0;\n        display: flex;\n        flex-direction: column;\n        gap: 6px;\n      }\n      #list {\n        flex: 1;\n        overflow: auto;\n        border: 1px solid var(--line);\n        border-radius: 4px;\n      }\n      .item {\n        padding: 5px 8px;\n        cursor: pointer;\n        border-bottom: 1px solid var(--line);\n      }\n      .item.sel {\n        background: var(--sel);\n      }\n      .item .kind {\n        color: var(--muted);\n        font-size: 11px;\n      }\n      h1 {\n        font-size: 15px;\n        margin: 0;\n      }\n      #desc {\n        color: var(--muted);\n      }\n      #opts {\n        display: grid;\n        grid-template-columns: max-content 1fr;\n        gap: 4px 10px;\n        align-items: center;\n      }\n      #opts label {\n        font-weight: 600;\n      }\n      select,\n      input[type='text'],\n      input[type='number'] {\n        font: inherit;\n        background: var(--bg);\n        color: var(--fg);\n        border: 1px solid var(--line);\n        border-radius: 3px;\n        padding: 2px 4px;\n      }\n      input[type='text'] {\n        width: 100%;\n        box-sizing: border-box;\n      }\n      button {\n        font: inherit;\n        padding: 3px 12px;\n        border: 1px solid var(--line);\n        background: var(--head);\n        color: var(--fg);\n        border-radius: 4px;\n        cursor: pointer;\n      }\n      button.primary {\n        background: var(--accent);\n        border-color: var(--accent);\n        color: #fff;\n        font-weight: 600;\n      }\n      button:disabled {\n        opacity: 0.5;\n        cursor: default;\n      }\n      .row {\n        display: flex;\n        gap: 8px;\n        align-items: center;\n        flex-wrap: wrap;\n      }\n      #status {\n        color: var(--muted);\n      }\n      #status.err {\n        color: var(--warn);\n        font-weight: 600;\n      }\n      #out {\n        flex: 1;\n        overflow: auto;\n        border: 1px solid var(--line);\n        border-radius: 4px;\n        background: #fff;\n      }\n      .pc-report {\n        padding: 8px 12px;\n      }\n      .muted {\n        color: var(--muted);\n        font-size: 11px;\n      }\n    </style>\n  </head>\n  <body>\n    <div id=\"left\">\n      <div id=\"checksLabel\" style=\"font-weight: 600\"></div>\n      <div id=\"list\"></div>\n      <div class=\"muted\" id=\"version\"></div>\n    </div>\n    <div id=\"right\">\n      <h1 id=\"name\"></h1>\n      <div id=\"desc\"></div>\n      <div id=\"opts\"></div>\n      <div class=\"row\">\n        <button class=\"primary\" id=\"run\"></button>\n        <button id=\"defaults\"></button>\n        <span id=\"status\"></span>\n      </div>\n      <div id=\"out\"></div>\n    </div>\n    <script>\n      const BOOT = __PCX_BOOT__;\n      const papi = require('@papi/frontend');\n\n      const STR = {\n        en: {\n          checks: 'Checks',\n          report: 'Report',\n          run: 'Run',\n          defaults: 'Restore defaults',\n          yes: 'Yes',\n          no: 'No',\n          running: 'Running {0}...',\n          done: '{0} result(s) in {1} book(s).',\n          failed: 'The check failed: {0}',\n          notRead: 'Not read: {0}',\n          noOptions: 'This check has no options.',\n          notWhole: '{0} must be a whole number.',\n        },\n        es: {\n          checks: 'Verificaciones',\n          report: 'Informe',\n          run: 'Ejecutar',\n          defaults: 'Restaurar valores predeterminados',\n          yes: 'S\u00ed',\n          no: 'No',\n          running: 'Ejecutando {0}...',\n          done: '{0} resultado(s) en {1} libro(s).',\n          failed: 'La verificaci\u00f3n fall\u00f3: {0}',\n          notRead: 'No se ley\u00f3: {0}',\n          noOptions: 'Esta verificaci\u00f3n no tiene opciones.',\n          notWhole: '{0} debe ser un n\u00famero entero.',\n        },\n        fr: {\n          checks: 'V\u00e9rifications',\n          report: 'Rapport',\n          run: 'Lancer',\n          defaults: 'R\u00e9tablir les valeurs par d\u00e9faut',\n          yes: 'Oui',\n          no: 'Non',\n          running: 'Ex\u00e9cution de {0}...',\n          done: '{0} r\u00e9sultat(s) dans {1} livre(s).',\n          failed: 'La v\u00e9rification a \u00e9chou\u00e9 : {0}',\n          notRead: 'Non lu : {0}',\n          noOptions: 'Cette v\u00e9rification n\u2019a pas d\u2019options.',\n          notWhole: '{0} doit \u00eatre un nombre entier.',\n        },\n      };\n      const S = STR[BOOT.lang] || STR.en;\n      const KIND = {\n        en: { report: 'Report', changes: 'Changes text' },\n        es: { report: 'Informe', changes: 'Cambia el texto' },\n        fr: { report: 'Rapport', changes: 'Modifie le texte' },\n      }[BOOT.lang] || { report: 'Report', changes: 'Changes text' };\n\n      let checks = [];\n      let current = null;\n      let busy = false;\n      const $ = (id) => document.getElementById(id);\n\n      function fmt(s, ...args) {\n        return s.replace(/\\{(\\d+)\\}/g, (m, n) => (args[n] === undefined ? m : String(args[n])));\n      }\n\n      function status(text, isError) {\n        $('status').textContent = text || '';\n        $('status').className = isError ? 'err' : '';\n      }\n\n      function drawList() {\n        const list = $('list');\n        list.textContent = '';\n        checks.forEach((c) => {\n          const div = document.createElement('div');\n          div.className = 'item' + (current && current.id === c.id ? ' sel' : '');\n          const name = document.createElement('div');\n          name.textContent = c.name;\n          const kind = document.createElement('div');\n          kind.className = 'kind';\n          kind.textContent = KIND[c.kind] || c.kind;\n          div.append(name, kind);\n          div.addEventListener('click', () => select(c.id));\n          div.addEventListener('dblclick', () => run());\n          list.appendChild(div);\n        });\n      }\n\n      function drawOptions(values) {\n        const box = $('opts');\n        box.textContent = '';\n        if (current.options.length === 0) {\n          const p = document.createElement('div');\n          p.className = 'muted';\n          p.textContent = S.noOptions;\n          box.appendChild(p);\n          return;\n        }\n        current.options.forEach((o) => {\n          const label = document.createElement('label');\n          label.textContent = o.label;\n          label.title = o.tip;\n          label.htmlFor = 'opt_' + o.name;\n          let input;\n          if (o.type === 'bool') {\n            input = document.createElement('select');\n            [\n              ['Yes', S.yes],\n              ['No', S.no],\n            ].forEach(([v, t]) => {\n              const op = document.createElement('option');\n              op.value = v;\n              op.textContent = t;\n              input.appendChild(op);\n            });\n            input.value = String(values[o.name]).trim().toLowerCase() === 'yes' ? 'Yes' : 'No';\n          } else {\n            input = document.createElement('input');\n            input.type = o.type === 'int' ? 'number' : 'text';\n            input.value = values[o.name];\n          }\n          input.id = 'opt_' + o.name;\n          input.title = o.tip;\n          box.append(label, input);\n        });\n      }\n\n      function readOptions() {\n        const o = {};\n        for (const d of current.options) {\n          const v = $('opt_' + d.name).value;\n          if (d.type === 'int' && !/^\\s*[+-]?\\d+\\s*$/.test(v)) throw new Error(fmt(S.notWhole, d.label));\n          o[d.name] = v;\n        }\n        return o;\n      }\n\n      async function select(id) {\n        current = checks.find((c) => c.id === id);\n        drawList();\n        $('name').textContent = current.name;\n        $('desc').textContent = current.description;\n        $('out').textContent = '';\n        status('');\n        let values = {};\n        try {\n          values = await papi.commands.sendCommand('philsChecks.loadOptions', BOOT.projectId, id);\n        } catch (e) {\n          current.options.forEach((o) => (values[o.name] = o.def));\n        }\n        drawOptions(values);\n      }\n\n      function showReport(res) {\n        const out = $('out');\n        out.textContent = '';\n        const style = document.createElement('style');\n        style.textContent = res.css;\n        const div = document.createElement('div');\n        div.className = 'pc-report';\n        // The report is built by the extension from escaped project text.\n        div.innerHTML = res.html;\n        out.append(style, div);\n      }\n\n      async function run() {\n        if (!current || busy) return;\n        let options;\n        try {\n          options = readOptions();\n        } catch (e) {\n          status(e.message, true);\n          return;\n        }\n        busy = true;\n        $('run').disabled = true;\n        status(fmt(S.running, current.name));\n        try {\n          const res = await papi.commands.sendCommand('philsChecks.run', BOOT.projectId, current.id, options, BOOT.lang);\n          showReport(res);\n          let text = fmt(S.done, res.count, res.booksRead.length);\n          if (res.failed.length > 0) text += ' ' + fmt(S.notRead, res.failed.join('; '));\n          status(text, res.failed.length > 0);\n        } catch (e) {\n          status(fmt(S.failed, e && e.message ? e.message : e), true);\n        } finally {\n          busy = false;\n          $('run').disabled = false;\n        }\n      }\n\n      $('out').addEventListener('click', (ev) => {\n        const a = ev.target.closest ? ev.target.closest('a.pc-go') : null;\n        if (!a) return;\n        ev.preventDefault();\n        papi.commands.sendCommand('philsChecks.goTo', BOOT.projectId, a.getAttribute('data-ref')).catch((e) => status(String(e), true));\n      });\n\n      $('run').addEventListener('click', run);\n      $('defaults').addEventListener('click', () => {\n        if (!current) return;\n        const values = {};\n        current.options.forEach((o) => (values[o.name] = o.def));\n        drawOptions(values);\n      });\n\n      async function start() {\n        $('checksLabel').textContent = S.checks;\n        $('run').textContent = S.run;\n        $('defaults').textContent = S.defaults;\n        $('version').textContent = BOOT.projectName + ' \u00b7 ' + BOOT.version;\n        try {\n          checks = await papi.commands.sendCommand('philsChecks.list', BOOT.lang);\n        } catch (e) {\n          status(String(e), true);\n          return;\n        }\n        drawList();\n        if (checks.length > 0) select(checks[0].id);\n      }\n      start();\n    </script>\n  </body>\n</html>\n";
const PCX_USFM_STY = "# Version=3.0.11\n# ********************************************************************\n# * usfm.sty is the default stylesheet for Paratext projects         *\n# *   using USFM markup.                                             *\n# * Latest documentation and stylesheets are maintained at:          *\n# *   http://markups.paratext.org/usfm                               *\n# ********************************************************************\n\n# File Identification\n\n\\Marker id\n\\Name id - File - Identification\n\\Description File identification information (BOOKID, FILENAME, EDITOR, MODIFICATION DATE)\n\\StyleType Paragraph\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular book\n\\FontSize 12\n\n\\Marker usfm\n\\Name usfm - File - USFM Version ID\n\\Description File markup version information\n\\OccursUnder id\n\\Rank 1\n\\StyleType Paragraph\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\FontSize 12\n\n\\Marker ide\n\\Name ide - File - Encoding\n\\Description File encoding information\n\\OccursUnder id\n\\Rank 1\n\\StyleType Paragraph\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\FontSize 12\n\n# Headers\n\n\\Marker h\n\\Name h - File - Header\n\\Description Running header text for a book (basic)\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker h1\n\\Name DEPRECATED h1 - File - Header\n\\Description Running header text\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker h2\n\\Name DEPRECATED h2 - File - Left Header\n\\Description Running header text, left side of page\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker h3\n\\Name DEPRECATED h3 - File - Right Header\n\\Description Running header text, right side of page\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker toc1\n\\Name toc1 - File - Long Table of Contents Text\n\\Description Long table of contents text\n\\OccursUnder h h1 h2 h3 id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Bold\n\\Color 16384\n#!\\ColorName highcon green\n\n\\Marker toc2\n\\Name toc2 - File - Short Table of Contents Text\n\\Description Short table of contents text\n\\OccursUnder h h1 h2 h3 id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Color 16384\n#!\\ColorName highcon green\n\n\\Marker toc3\n\\Name toc3 - File - Book Abbreviation\n\\Description Book Abbreviation\n\\OccursUnder h h1 h2 h3 id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Italic\n\\Color 128\n#!\\ColorName lowcon red\n\n\\Marker toca1\n\\Name toca1 - File - Alternative Language Long Table of Contents Text\n\\Description Alternative language long table of contents text\n\\OccursUnder h h1 h2 h3\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 10\n\\Italic\n\\Color 8421504\n#!\\ColorName gray\n\n\\Marker toca2\n\\Name toca2 - File - Alternative Language Short Table of Contents Text\n\\Description Alternative language short table of contents text\n\\OccursUnder h h1 h2 h3\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 10\n\\Italic\n\\Color 8421504\n#!\\ColorName gray\n\n\\Marker toca3\n\\Name toca3 - File - Alternative Language Book Abbreviation\n\\Description Alternative language book Abbreviation\n\\OccursUnder h h1 h2 h3\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 10\n\\Italic\n\\Color 8421504\n#!\\ColorName gray\n\n# Remarks and Comments\n\n\\Marker rem\n\\Name rem - File - Remark\n\\Description Comments and remarks\n\\OccursUnder id ide c\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Color 16711680\n#!\\ColorName highcon blue\n\n\\Marker sts\n\\Name sts - File - Status\n\\Description Status of this file\n\\OccursUnder id ide c\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Color 16711680\n#!\\ColorName highcon blue\n\n\\Marker restore\n\\Name restore - File - Restore Information\n\\Description Project restore information\n\\OccursUnder id\n\\Rank 99\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Color 16711680\n#!\\ColorName highcon blue\n\n# Introduction\n\n\\Marker imt\n\\Name imt - Introduction - Major Title Level 1\n\\Description Introduction major title, level 1 (if single level) (basic)\n\\OccursUnder id\n\\Rank 5\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Other\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker imt1\n\\Name imt1 - Introduction - Major Title Level 1\n\\Description Introduction major title, level 1 (if multiple levels)\n\\OccursUnder id\n\\Rank 5\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Other\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker imt2\n\\Name imt2 - Introduction - Major Title Level 2\n\\Description Introduction major title, level 2\n\\OccursUnder id\n\\Rank 5\n\\TextProperties paragraph publishable vernacular level_2\n\\TextType other\n\\StyleType Paragraph\n\\FontSize 13\n\\Italic\n\\Justification Center\n\\SpaceBefore 6\n\\SpaceAfter 3\n\n\\Marker imt3\n\\Name imt3 - Introduction - Major Title Level 3\n\\Description Introduction major title, level 3\n\\OccursUnder id\n\\Rank 5\n\\TextProperties paragraph publishable vernacular level_3\n\\TextType Other\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceBefore 2\n\\SpaceAfter 2\n\n\\Marker imt4\n\\Name imt4 - Introduction - Major Title Level 4\n\\Description Introduction major title, level 4 (usually within parenthesis)\n\\OccursUnder id\n\\Rank 5\n\\TextProperties paragraph publishable vernacular level_4\n\\TextType Other\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Center\n\\SpaceBefore 2\n\\SpaceAfter 2\n \n\\Marker imte\n\\Name imte - Introduction - [Uncommon] Major Title at Introduction End Level 1\n\\Description Introduction major title at introduction end, level 1 (if single level)\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Other\n\\OccursUnder id\n\\Rank 7\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker imte1\n\\Name imte1 - Introduction - [Uncommon] Major Title at Introduction End Level 1\n\\Description Introduction major title at introduction end, level 1 (if multiple levels)\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Other\n\\OccursUnder id\n\\Rank 7\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker imte2\n\\Name imte2 - Introduction - [Uncommon] Major Title at Introduction End Level 2\n\\Description Introduction major title at introduction end, level 2\n\\TextProperties paragraph publishable vernacular level_2\n\\TextType Other\n\\OccursUnder id\n\\Rank 7\n\\StyleType Paragraph\n\\FontSize 16\n\\Italic\n\\Justification Center\n\\SpaceAfter 2 \n\n\\Marker is\n\\Name is - Introduction - Section Heading Level 1\n\\Description Introduction section heading, level 1 (if single level) (basic)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker is1 \n\\Name is1 - Introduction - Section Heading Level 1\n\\Description Introduction section heading, level 1 (if multiple levels)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker is2\n\\Name is2 - Introduction - Section Heading Level 2\n\\Description Introduction section heading, level 2 \n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker iot \n\\Name iot - Introduction - Outline Title\n\\Description Introduction outline title (basic)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker io\n\\Name io - Introduction - Outline Level 1\n\\Description Introduction outline text, level 1 (if single level)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\n\\Marker io1\n\\Name io1 - Introduction - Outline Level 1\n\\Description Introduction outline text, level 1 (if multiple levels) (basic)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\n\\Marker io2\n\\Name io2 - Introduction - Outline Level 2\n\\Description Introduction outline text, level 2 \n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .75\n\n\\Marker io3\n\\Name io3 - Introduction - Outline Level 3\n\\Description Introduction outline text, level 3 \n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1\n\n\\Marker io4\n\\Name io4 - Introduction - Outline Level 4\n\\Description Introduction outline text, level 4 \n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_4\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1.25\n\n\\Marker ior\n\\Endmarker ior*\n\\Name ior...ior* - Introduction - Outline References Range\n\\Description Introduction references range for outline entry; for marking references separately\n\\OccursUnder id io io1 io2 io3 io4 NEST\n\\TextType Other\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker ip\n\\Name ip - Introduction - Paragraph\n\\Description Introduction prose paragraph (basic)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\n\\Marker im\n\\Name im - Introduction - Paragraph - no first line indent\n\\Description Introduction prose paragraph, with no first line indent (may occur after poetry)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker ipi\n\\Name ipi - Introduction - Indented Para - first line indent\n\\Description Introduction prose paragraph, indented, with first line indent\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker imi\n\\Name imi - Introduction - Indented Para - no first line indent\n\\Description Introduction prose paragraph text, indented, with no first line indent\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker ili\n\\Name ili - Introduction - List Entry - Level 1\n\\Description A list entry, level 1 (if single level)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.375 # 1/8 inch indent, 1/2 inch wrap\n\n\\Marker ili1\n\\Name ili1 - Introduction - List Entry - Level 1\n\\Description A list entry, level 1 (if multiple levels)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.375 # 1/8 inch indent, 1/2 inch wrap\n\n\\Marker ili2\n\\Name ili2 - Introduction - List Entry - Level 2\n\\Description A list entry, level 2\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .75\n\\FirstLineIndent -.375\n\n\\Marker ipq\n\\Name ipq - Introduction - Paragraph - quote from text\n\\Description Introduction prose paragraph, quote from the body text\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\Italic\n\n\\Marker imq\n\\Name imq - Introduction - Paragraph - quote from text - no first line indent\n\\Description Introduction prose paragraph, quote from the body text, with no first line indent\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\\Italic\n\n\\Marker ipr\n\\Name ipr - Introduction - Paragraph - right aligned\n\\Description Introduction prose paragraph, right aligned\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\\Justification Right\n\\Italic\n\n\\Marker ib\n\\Name ib - Introduction - Blank Line\n\\Description Introduction blank line\n\\OccursUnder id\n\\Rank 6\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType Other\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker iq\n\\Name iq - Introduction - Poetry Level 1\n\\Description Introduction poetry text, level 1 (if single level)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular poetic level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.75  # 1/4 inch indent, 1 inch wrap\n\\Italic\n\n\\Marker iq1\n\\Name iq1 - Introduction - Poetry Level 1\n\\Description Introduction poetry text, level 1 (if multiple levels)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular poetic level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.75  # 1/4 inch indent, 1 inch wrap\n\\Italic\n\n\\Marker iq2\n\\Name iq2 - Introduction - Poetry Level 2\n\\Description Introduction poetry text, level 2 \n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular poetic level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.5  # 1/2 inch indent, 1 inch wrap\n\\Italic\n\n\\Marker iq3\n\\Name iq3 - Introduction - Poetry Level 3\n\\Description Introduction poetry text, level 3\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular poetic level_3\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.25 # 3/4 inch indent, 1 inch wrap\n\\Italic\n\n\\Marker iex\n\\Name iex - Introduction - Explanatory or Bridge Text\n\\Description Introduction explanatory or bridge text (e.g. explanation of missing book in Short Old Testament)\n\\OccursUnder id c\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\SpaceBefore 4\n\\SpaceAfter 4\n\n\\Marker iqt\n\\Endmarker iqt*\n\\Name iqt...iqt* - Special Text - Quoted Scripture Text in Introduction\n\\Description For quoted scripture text appearing in the introduction\n\\OccursUnder imt imt1 imt2 imt3 imt4 ib ie ili ili1 ili2 im imi imq io io1 io2 io3 io4 iot ip ipi ipq ipr iq iq1 iq2 iq3 is is1 is2 imte imte1 imte2 iex\n\\TextType Other\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker ie\n\\Name ie - Introduction - End Marker\n\\Description Introduction ending marker\n\\OccursUnder id\n\\Rank 6\n\\TextProperties paragraph publishable vernacular\n\\TextType Other\n\\FontSize 10\n\\StyleType paragraph\n\n# Chapters and Verses\n\n\\Marker c\n\\Name c - Chapter Number\n\\Description Chapter number (necessary for normal Paratext operation)\n\\OccursUnder id\n\\Rank 8\n\\TextType ChapterNumber\n\\TextProperties chapter\n\\StyleType Paragraph\n\\Bold\n\\FontSize 18\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker ca\n\\Endmarker ca*\n\\Name ca...ca* - Chapter Number - Alternate\n\\Description Second (alternate) chapter number (for coding dual versification; useful for places where different traditions of chapter breaks need to be supported in the same translation)\n\\OccursUnder c \n\\TextType Other\n\\StyleType Character\n\\Italic\n\\FontSize 16\n\\Color 2263842\n#!\\ColorName green\n\n\\Marker cp\n\\Name cp - Chapter Number - Publishing Alternate\n\\Description Published chapter number (chapter string that should appear in the published text)\n\\OccursUnder c \n\\Rank 4\n\\TextType Other\n\\TextProperties paragraph\n\\StyleType Paragraph\n\\Bold\n\\FontSize 18\n\\SpaceBefore 8\n\\SpaceAfter 4\n\\Color 16711680\n#!\\ColorName highcon blue\n\n\\Marker cl\n\\Name cl - Chapter - Publishing Label\n\\Description Chapter label used for translations that add a word such as \"Chapter\" before chapter numbers (e.g. Psalms). The subsequent text is the chapter label.\n\\OccursUnder id c ms ms1 ms2 ms3 mr\n\\TextType Other\n\\TextProperties paragraph\n\\StyleType Paragraph\n\\Bold\n\\FontSize 18\n\\SpaceBefore 8\n\\SpaceAfter 4\n\\Justification Center\n\n\\Marker cd\n\\Name cd - Chapter - Description\n\\Description Chapter Description (Publishing option D, e.g. in Russian Bibles)\n\\OccursUnder c\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 11\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker v\n\\Name v - Verse Number\n\\Description A verse number (Necessary for normal paratext operation) (basic)\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 s3 d sp\n\\TextType VerseNumber\n\\TextProperties verse\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\n\\Marker va\n\\Endmarker va*\n\\Name va...va* - Verse Number - Alternate\n\\Description Second (alternate) verse number (for coding dual numeration in Psalms; see also NRSV Exo 22.1-4)\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 s3 d sp\n\\TextType Other\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\\Color 2263842\n#!\\ColorName green\n\n\\Marker vp\n\\Endmarker vp*\n\\Name vp...vp* - Verse Number - Publishing Alternate\n\\Description Published verse marker (verse string that should appear in the published text)\n\\OccursUnder cd lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 s3 d sp\n\\TextType Other\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\\Color 16711680\n#!\\ColorName highcon blue\n\n# Paragraphs\n\n\\Marker p\n\\Name p - Paragraph - Normal - First Line Indent\n\\Description Paragraph text, with first line indent (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\n\\Marker m\n\\Name m - Paragraph - Margin - No First Line Indent\n\\Description Paragraph text, with no first line indent (may occur after poetry) (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker po\n\\Name po - Paragraph - Letter Opening\n\\Description Letter opening\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\SpaceBefore 4\n\\SpaceAfter 4\n\n\\Marker pr\n\\Name pr - Paragraph - Text Refrain (right aligned)\n\\Description Text refrain (paragraph text, right aligned)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\Justification Right\n\\FontSize 12\n\n\\Marker cls\n\\Name cls - Paragraph - Letter Closing\n\\Description Letter Closing\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Justification Right\n\n\\Marker pmo\n\\Name pmo - Paragraph - Embedded Text Opening\n\\Description Embedded text opening\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr po q q1 q2 q3 q4 qc qr b s1 s2 s3 s4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pm\n\\Name pm - Paragraph - Embedded Text\n\\Description Embedded text paragraph\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr po psi q q1 q2 q3 q4 qc qr b s1 s2 s3 s4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pmc\n\\Name pmc - Paragraph - Embedded Text Closing\n\\Description Embedded text closing\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr po q q1 q2 q3 q4 qc qr b s1 s2 s3 s4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pmr\n\\Name pmr - Paragraph - Embedded Text Refrain\n\\Description Embedded text refrain (e.g. Then all the people shall say, \"Amen!\")\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr po q q1 q2 q3 q4 qc qr b s1 s2 s3 s4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Justification Right\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pi\n\\Name pi - Paragraph - Indented - Level 1 - First Line Indent\n\\Description Paragraph text, level 1 indent (if single level), with first line indent; often used for discourse (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pi1\n\\Name pi1 - Paragraph - Indented - Level 1 - First Line Indent\n\\Description Paragraph text, level 1 indent (if multiple levels), with first line indent; often used for discourse\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pi2\n\\Name pi2 - Paragraph - Indented - Level 2 - First Line Indent\n\\Description Paragraph text, level 2 indent, with first line indent; often used for discourse\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .5\n\\RightMargin .25\n\n\\Marker pi3\n\\Name pi3 - Paragraph - Indented - Level 3 - First Line Indent\n\\Description Paragraph text, level 3 indent, with first line indent; often used for discourse\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .75\n\\RightMargin .25\n\n\\Marker pc\n\\Name pc - Paragraph - Centered (for Inscription)\n\\Description Paragraph text, centered (for Inscription)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\Justification Center\n\\FontSize 12\n\n\\Marker mi\n\\Name mi - Paragraph - Indented - No First Line Indent\n\\Description Paragraph text, indented, with no first line indent; often used for discourse\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker nb\n\\Name nb - Paragraph - No Break with Previous Paragraph\n\\Description Paragraph text, with no break from previous paragraph text (at chapter boundary) (basic)\n\\OccursUnder c \n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n# Poetry\n\n\\Marker q\n\\Name q - Poetry - Indent Level 1 - Single Level Only\n\\Description Poetry text, level 1 indent (if single level)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 0.75\n\\FirstLineIndent -0.5  # 1/8 inch indent, 3/4 inch wrap\n\n\\Marker q1\n\\Name q1 - Poetry - Indent Level 1\n\\Description Poetry text, level 1 indent (if multiple levels) (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 0.75\n\\FirstLineIndent -0.5  # 1/8 inch indent, 3/4 inch wrap\n\n\\Marker q2\n\\Name q2 - Poetry - Indent Level 2\n\\Description Poetry text, level 2 indent (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 0.75\n\\FirstLineIndent -0.375  # 1/4 inch indent, 3/4 inch wrap\n\n\\Marker q3\n\\Name q3 - Poetry - Indent Level 3\n\\Description Poetry text, level 3 indent\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_3\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 0.75\n\\FirstLineIndent -0.25 # 3/8 inch indent, 3/4 inch wrap\n\n\\Marker q4\n\\Name q4 - Poetry - Indent Level 4\n\\Description Poetry text, level 4 indent\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_4\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 0.75\n\\FirstLineIndent -0.125 # 1/2 inch indent, 3/4 inch wrap\n\n\\Marker qc\n\\Name qc - Poetry - Centered\n\\Description Poetry text, centered\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic\n\\StyleType Paragraph\n\\FontSize 12\n\\Justification Center\n\n\\Marker qr\n\\Name qr - Poetry - Right Aligned\n\\Description Poetry text, Right Aligned\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic\n\\StyleType Paragraph\n\\FontSize 12\n\\Justification Right\n\n\\Marker qs\n\\Endmarker qs*\n\\Name qs...qs* - Poetry Text - Selah\n\\Description Poetry text, Selah\n\\OccursUnder q q1 q2 q3 q4 qc qr qd NEST\n\\Rank 4\n\\TextType VerseText\n\\TextProperties publishable vernacular poetic\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker qa\n\\Name qa - Poetry - Acrostic Heading/Marker\n\\Description Poetry text, Acrostic marker/heading\n\\OccursUnder c\n\\Rank 4\n\\TextType Other\n\\TextProperties paragraph publishable vernacular poetic\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\n\\Marker qac\n\\Endmarker qac*\n\\Name qac...qac* - Poetry Text - Acrostic Letter\n\\Description Poetry text, Acrostic markup of the first character of a line of acrostic poetry\n\\OccursUnder q q1 q2 q3 q4 qc qr  NEST\n\\Rank 4\n\\TextType Other\n\\TextProperties publishable vernacular poetic\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker qm\n\\Name qm - Poetry - Embedded Text - Indent Level 1 - Single Level Only\n\\Description Poetry text, embedded, level 1 indent (if single level)\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr q q1 q2 q3 q4 qc qr b\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.75  # 1/4 inch indent, 1 inch wrap\n\n\\Marker qm1\n\\Name qm1 - Poetry - Embedded Text - Indent Level 1\n\\Description Poetry text, embedded, level 1 indent (if multiple levels)\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr q q1 q2 q3 q4 qc qr b\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.75  # 1/4 inch indent, 1 inch wrap\n\n\\Marker qm2\n\\Name qm2 - Poetry - Embedded Text - Indent Level 2\n\\Description Poetry text, embedded, level 2 indent\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr q q1 q2 q3 q4 qc qr b\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.5  # 1/2 inch indent, 1 inch wrap\n\n\\Marker qm3\n\\Name qm3 - Poetry - Embedded Text - Indent Level 3\n\\Description Poetry text, embedded, level 3 indent\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr q q1 q2 q3 q4 qc qr b\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_3\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.25 # 3/4 inch indent, 1 inch wrap\n\n\\Marker qd\n\\Name qd - Poetry - Hebrew Note\n\\Description A Hebrew musical performance annotation, similar in content to Hebrew descriptive title.\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\LeftMargin .25\n\n\\Marker b\n\\Name b - Poetry - Stanza Break (Blank Line)\n\\Description Poetry text stanza break (e.g. stanza break) (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n# Titles & Headings\n\n\\Marker mt\n\\Name mt - Title - Major Title Level 1\n\\Description The main title of the book (if single level)\n\\OccursUnder id\n\\Rank 3\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Title\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker mt1\n\\Name mt1 - Title - Major Title Level 1\n\\Description The main title of the book (if multiple levels) (basic)\n\\OccursUnder id\n\\Rank 3\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Title\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 2\n\\SpaceAfter 4\n\n\\Marker mt2\n\\Name mt2 - Title - Major Title Level 2\n\\Description A secondary title usually occurring before the main title (basic)\n\\OccursUnder id\n\\Rank 3\n\\TextProperties paragraph publishable vernacular level_2\n\\TextType Title\n\\StyleType Paragraph\n\\FontSize 16\n\\Italic\n\\Justification Center\n\\SpaceAfter 2\n\n\\Marker mt3\n\\Name mt3 - Title - Major Title Level 3\n\\Description A secondary title occurring after the main title\n\\OccursUnder id\n\\Rank 3\n\\TextProperties paragraph publishable vernacular level_3\n\\TextType Title\n\\StyleType Paragraph\n\\FontSize 16\n\\Bold\n\\Justification Center\n\\SpaceBefore 2\n\\SpaceAfter 2\n\n\\Marker mt4\n\\Name mt4 - Title - Major Title level 4\n\\Description A small secondary title sometimes occurring within parentheses\n\\OccursUnder id\n\\Rank 3\n\\TextProperties paragraph publishable vernacular level_4\n\\TextType Title\n\\StyleType Paragraph\n\\FontSize 12\n\\Justification Center\n\\SpaceBefore 2\n\\SpaceAfter 2\n\n\\Marker mte\n\\Name mte - Title - [Uncommon] Major Title Ending Level 1\n\\Description The main title of the book repeated at the end of the book, level 1 (if single level)\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Title\n\\OccursUnder c\n\\Rank 2\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker mte1\n\\Name mte1 - Title - [Uncommon] Major Title Ending Level 1\n\\Description The main title of the book repeated at the end of the book, level 1 (if multiple levels)\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Title\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tc1 tc2 tc3 tc4 s3 d\n\\Rank 2\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n \n\\Marker mte2\n\\Name mte2 - Title - [Uncommon] Major Title Ending Level 2\n\\Description A secondary title occurring before or after the 'ending' main title\n\\TextProperties paragraph publishable vernacular level_2\n\\TextType Title\n\\OccursUnder mte1\n\\Rank 2\n\\StyleType Paragraph\n\\FontSize 16\n\\Italic\n\\Justification Center\n\\SpaceAfter 2\n\n\\Marker ms\n\\Name ms - Heading - Major Section Level 1\n\\Description A major section division heading, level 1 (if single level) (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 16\n\\SpaceAfter 4\n\n\\Marker ms1\n\\Name ms1 - Heading - Major Section Level 1\n\\Description A major section division heading, level 1 (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 16\n\\SpaceAfter 4\n\n\\Marker ms2\n\\Name ms2 - Heading - Major Section Level 2\n\\Description A major section division heading, level 2\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 16\n\\SpaceAfter 4\n\n\\Marker ms3\n\\Name ms3 - Heading - Major Section Level 3\n\\Description A major section division heading, level 3\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Italic\n\\Justification Center\n\\SpaceBefore 16\n\\SpaceAfter 4\n\n\\Marker mr\n\\Name mr - Heading - Major Section Range References\n\\Description A major section division references range heading (basic)\n\\OccursUnder ms ms1 ms2 ms3\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Center\n\\SpaceAfter 4\n\n\\Marker s\n\\Name s - Heading - Section Level 1\n\\Description A section heading, level 1 (if single level) (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker s1\n\\Name s1 - Heading - Section Level 1\n\\Description A section heading, level 1 (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker s2\n\\Name s2 - Heading - Section Level 2\n\\Description A section heading, level 2 (e.g. Proverbs 22-24)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker s3\n\\Name s3 - Heading - Section Level 3\n\\Description A section heading, level 3 (e.g. Genesis \"The First Day\")\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Left\n\\SpaceBefore 6\n\\SpaceAfter 3\n\n\\Marker s4\n\\Name s4 - Heading - Section Level 4\n\\Description A section heading, level 4\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_4\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Left\n\\SpaceBefore 6\n\\SpaceAfter 3\n\n\\Marker sr\n\\Name sr - Heading - Section Range References\n\\Description A section division references range heading\n\\OccursUnder s s1 s2 s3 s4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceAfter 4\n\n\\Marker r\n\\Name r - Heading - Parallel References\n\\Description Parallel reference(s) (basic)\n\\OccursUnder c s s1 s2 s3 s4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Center\n\\SpaceAfter 4\n\n\\Marker sp\n\\Name sp - Label - Speaker\n\\Description A heading, to identify the speaker (e.g. Job)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Left\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker d\n\\Name d - Label - Descriptive Title - Hebrew Subtitle\n\\Description A Hebrew text heading, to provide description (e.g. Psalms)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Center\n\\SpaceBefore 4\n\\SpaceAfter 4\n\n\\Marker sd\n\\Name sd - Label - Semantic Division Location - Level 1\n\\Description Vertical space used to divide the text into sections, level 1 (if single level)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\SpaceBefore 24\n\\SpaceAfter 24\n\n\\Marker sd1\n\\Name sd1 - Label - Semantic Division Location - Level 1\n\\Description Vertical space used to divide the text into sections, level 1 (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\SpaceBefore 24\n\\SpaceAfter 24\n\n\\Marker sd2\n\\Name sd2 - Label - Semantic Division Location - Level 2\n\\Description Vertical space used to divide the text into sections, level 2\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType Paragraph\n\\SpaceBefore 18\n\\SpaceAfter 18\n\n\\Marker sd3\n\\Name sd3 - Label - Semantic Division Location - Level 3\n\\Description Vertical space used to divide the text into sections, level 3\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType Paragraph\n\\SpaceBefore 12\n\\SpaceAfter 12\n\n\\Marker sd4\n\\Name sd4 - Label - Semantic Division Location - Level 4\n\\Description Vertical space used to divide the text into sections, level 4\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_4\n\\StyleType Paragraph\n\\SpaceBefore 8\n\\SpaceAfter 8\n\n# Tables\n\n\\Marker tr\n\\Name tr - Table - Row\n\\Description A new table row\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.25  # 6/16 inch\n\n\\Marker th1 \n\\Name th1 - Table - Column 1 Heading\n\\Description A table heading, column 1\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th2\n\\Name th2 - Table - Column 2 Heading\n\\Description A table heading, column 2\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th3\n\\Name th3 - Table - Column 3 Heading\n\\Description A table heading, column 3\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th4\n\\Name th4 - Table - Column 4 Heading\n\\Description A table heading, column 4\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th5\n\\Name th5 - Table - Column 5 Heading\n\\Description A table heading, column 5\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th6\n\\Name th6 - Table - Column 6 Heading\n\\Description A table heading, column 6\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th7\n\\Name th7 - Table - Column 7 Heading\n\\Description A table heading, column 7\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th8\n\\Name th8 - Table - Column 8 Heading\n\\Description A table heading, column 8\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th9\n\\Name th9 - Table - Column 9 Heading\n\\Description A table heading, column 9\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th10\n\\Name th10 - Table - Column 10 Heading\n\\Description A table heading, column 10\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th11\n\\Name th11 - Table - Column 11 Heading\n\\Description A table heading, column 11\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th12\n\\Name th12 - Table - Column 12 Heading\n\\Description A table heading, column 12\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker tc1\n\\Name tc1 - Table - Column 1 Cell\n\\Description A table cell item, column 1\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc2\n\\Name tc2 - Table - Column 2 Cell\n\\Description A table cell item, column 2\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc3\n\\Name tc3 - Table - Column 3 Cell\n\\Description A table cell item, column 3\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc4\n\\Name tc4 - Table - Column 4 Cell\n\\Description A table cell item, column 4\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc5\n\\Name tc5 - Table - Column 5 Cell\n\\Description A table cell item, column 5\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc6\n\\Name tc6 - Table - Column 6 Cell\n\\Description A table cell item, column 6\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc7\n\\Name tc7 - Table - Column 7 Cell\n\\Description A table cell item, column 7\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc8\n\\Name tc8 - Table - Column 8 Cell\n\\Description A table cell item, column 8\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc9\n\\Name tc9 - Table - Column 9 Cell\n\\Description A table cell item, column 9\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc10\n\\Name tc10 - Table - Column 10 Cell\n\\Description A table cell item, column 10\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc11\n\\Name tc11 - Table - Column 11 Cell\n\\Description A table cell item, column 11\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc12\n\\Name tc12 - Table - Column 12 Cell\n\\Description A table cell item, column 12\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n# Center Aligned Table Heads and Columns\n\n\\Marker thc1 \n\\Name thc1 - Table - Column 1 Heading - Center Aligned\n\\Description A table heading, column 1, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc2\n\\Name thc2 - Table - Column 2 Heading - Center Aligned\n\\Description A table heading, column 2, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc3\n\\Name thc3 - Table - Column 3 Heading - Center Aligned\n\\Description A table heading, column 3, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc4\n\\Name thc4 - Table - Column 4 Heading - Center Aligned\n\\Description A table heading, column 4, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc5\n\\Name thc5 - Table - Column 5 Heading - Center Aligned\n\\Description A table heading, column 5, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc6\n\\Name thc6 - Table - Column 6 Heading - Center Aligned\n\\Description A table heading, column 6, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc7\n\\Name thc7 - Table - Column 7 Heading - Center Aligned\n\\Description A table heading, column 7, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc8\n\\Name thc8 - Table - Column 8 Heading - Center Aligned\n\\Description A table heading, column 8, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc9\n\\Name thc9 - Table - Column 9 Heading - Center Aligned\n\\Description A table heading, column 9, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc10\n\\Name thc10 - Table - Column 10 Heading - Center Aligned\n\\Description A table heading, column 10, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc11\n\\Name thc11 - Table - Column 11 Heading - Center Aligned\n\\Description A table heading, column 11, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc12\n\\Name thc12 - Table - Column 12 Heading - Center Aligned\n\\Description A table heading, column 12, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker tcc1\n\\Name tcc1 - Table - Column 1 Cell - Center Aligned\n\\Description A table cell item, column 1, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc2\n\\Name tcc2 - Table - Column 2 Cell - Center Aligned\n\\Description A table cell item, column 2, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc3\n\\Name tcc3 - Table - Column 3 Cell - Center Aligned\n\\Description A table cell item, column 3, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc4\n\\Name tcc4 - Table - Column 4 Cell - Center Aligned\n\\Description A table cell item, column 4, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc5\n\\Name tcc5 - Table - Column 5 Cell - Center Aligned\n\\Description A table cell item, column 5, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc6\n\\Name tcc6 - Table - Column 6 Cell - Center Aligned\n\\Description A table cell item, column 6, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc7\n\\Name tcc7 - Table - Column 7 Cell - Center Aligned\n\\Description A table cell item, column 7, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc8\n\\Name tcc8 - Table - Column 8 Cell - Center Aligned\n\\Description A table cell item, column 8, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc9\n\\Name tcc9 - Table - Column 9 Cell - Center Aligned\n\\Description A table cell item, column 9, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc10\n\\Name tcc10 - Table - Column 10 Cell - Center Aligned\n\\Description A table cell item, column 10, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc11\n\\Name tcc11 - Table - Column 11 Cell - Center Aligned\n\\Description A table cell item, column 11, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc12\n\\Name tcc12 - Table - Column 12 Cell - Center Aligned\n\\Description A table cell item, column 12, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n# Right Aligned Table Heads and Columns\n\n\\Marker thr1 \n\\Name thr1 - Table - Column 1 Heading - Right Aligned\n\\Description A table heading, column 1, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Right\n\n\\Marker thr2\n\\Name thr2 - Table - Column 2 Heading - Right Aligned\n\\Description A table heading, column 2, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Right\n\n\\Marker thr3\n\\Name thr3 - Table - Column 3 Heading - Right Aligned\n\\Description A table heading, column 3, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Right\n\n\\Marker thr4\n\\Name thr4 - Table - Column 4 Heading - Right Aligned\n\\Description A table heading, column 4, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Right\n\n\\Marker thr5\n\\Name thr5 - Table - Column 5 Heading - Right Aligned\n\\Description A table heading, column 5, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Right\n\n\\Marker thr6\n\\Name thr6 - Table - Column 6 Heading - Right Aligned\n\\Description A table heading, column 6, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr7\n\\Name thr7 - Table - Column 7 Heading - Right Aligned\n\\Description A table heading, column 7, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr8\n\\Name thr8 - Table - Column 8 Heading - Right Aligned\n\\Description A table heading, column 8, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr9\n\\Name thr9 - Table - Column 9 Heading - Right Aligned\n\\Description A table heading, column 9, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr10\n\\Name thr10 - Table - Column 10 Heading - Right Aligned\n\\Description A table heading, column 10, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr11\n\\Name thr11 - Table - Column 11 Heading - Right Aligned\n\\Description A table heading, column 11, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr12\n\\Name thr12 - Table - Column 12 Heading - Right Aligned\n\\Description A table heading, column 12, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker tcr1 \n\\Name tcr1 - Table - Column 1 Cell - Right Aligned\n\\Description A table cell item, column 1, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Right\n\n\\Marker tcr2\n\\Name tcr2 - Table - Column 2 Cell - Right Aligned\n\\Description A table cell item, column 2, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Right\n\n\\Marker tcr3\n\\Name tcr3 - Table - Column 3 Cell - Right Aligned\n\\Description A table cell item, column 3, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Right\n\n\\Marker tcr4\n\\Name tcr4 - Table - Column 4 Cell - Right Aligned\n\\Description A table cell item, column 4, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Right\n\n\\Marker tcr5\n\\Name tcr5 - Table - Column 5 Cell - Right Aligned\n\\Description A table cell item, column 5, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Right\n\n\\Marker tcr6\n\\Name tcr6 - Table - Column 6 Cell - Right Aligned\n\\Description A table cell item, column 6, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr7\n\\Name tcr7 - Table - Column 7 Cell - Right Aligned\n\\Description A table cell item, column 7, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr8\n\\Name tcr8 - Table - Column 8 Cell - Right Aligned\n\\Description A table cell item, column 8, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr9\n\\Name tcr9 - Table - Column 9 Cell - Right Aligned\n\\Description A table cell item, column 9, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr10\n\\Name tcr10 - Table - Column 10 Cell - Right Aligned\n\\Description A table cell item, column 10, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr11\n\\Name tcr11 - Table - Column 11 Cell - Right Aligned\n\\Description A table cell item, column 11, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr12\n\\Name tcr12 - Table - Column 12 Cell - Right Aligned\n\\Description A table cell item, column 12, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n# Lists\n\n\\Marker lh\n\\Name lh - List Header\n\\Description List header (introductory remark)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\n\\Marker li\n\\Name li - List Entry - Level 1\n\\Description A list entry, level 1 (if single level)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.375 # 1/8 inch indent, 1/2 inch wrap\n\n\\Marker li1\n\\Name li1 - List Entry - Level 1\n\\Description A list entry, level 1 (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.375 # 1/8 inch indent, 1/2 inch wrap\n\n\\Marker li2\n\\Name li2 - List Entry - Level 2\n\\Description A list entry, level 2\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .75\n\\FirstLineIndent -.375\n\n\\Marker li3\n\\Name li3 - List Entry - Level 3\n\\Description A list entry, level 3\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.375\n\n\\Marker li4\n\\Name li4 - List Entry - Level 4\n\\Description A list entry, level 4\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_4\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1.25\n\\FirstLineIndent -.375\n\n\\Marker lf\n\\Name lf - List Footer\n\\Description List footer (concluding remark)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker lim\n\\Name lim - Embedded List Entry - Level 1\n\\Description An embedded list entry, level 1 (if single level)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .75\n\\FirstLineIndent -.375\n\\RightMargin .25\n\n\\Marker lim1\n\\Name lim1 - Embedded List Entry - Level 1\n\\Description An embedded list entry, level 1 (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .75\n\\FirstLineIndent -.375\n\\RightMargin .25\n\n\\Marker lim2\n\\Name lim2 - Embedded List Entry - Level 2\n\\Description An embedded list entry, level 2\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.375\n\n\\Marker lim3\n\\Name lim3 - Embedded List Item - Level 3\n\\Description An embedded list item, level 3\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1.25\n\\FirstLineIndent -.375\n\n\\Marker lim4\n\\Name lim4 - Embedded List Entry - Level 4\n\\Description An embedded list entry, level 4\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_4\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1.5\n\\FirstLineIndent -.375\n\n\\Marker litl\n\\Endmarker litl*\n\\Name litl...litl* - List Entry - Total\n\\Description List entry total text\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker lik\n\\Endmarker lik*\n\\Name lik...lik* - Structured List Entry - Key\n\\Description Structured list entry key text\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker liv\n\\Endmarker liv*\n\\Name liv...liv* - Structured List Entry - Value 1\n\\Description Structured list entry value 1 content (if single value)\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker liv1\n\\Endmarker liv1*\n\\Name liv1...liv1* - Structured List Entry - Value 1\n\\Description Structured list entry value 1 content (if multiple values)\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker liv2\n\\Endmarker liv2*\n\\Name liv2...liv2* - Structured List Entry - Value 2\n\\Description Structured list entry value 2 content\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker liv3\n\\Endmarker liv3*\n\\Name liv3...liv3* - Structured List Entry - Value 3\n\\Description Structured list entry value 3 content\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker liv4\n\\Endmarker liv4*\n\\Name liv4...liv4* - Structured List Entry - Value 4\n\\Description Structured list entry value 4 content\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker liv5\n\\Endmarker liv5*\n\\Name liv5...liv5* - Structured List Entry - Value 5\n\\Description Structured list entry value 5 content\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n# Footnotes\n\n\\Marker f\n\\Endmarker f*\n\\Name f...f* - Footnote \n\\Description A Footnote text item (basic)\n\\OccursUnder c cp lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 qs sp tc1 tc2 tc3 tc4 mt mt1 mt2 mt3 ms ms1 ms2 ms3 s s1 s2 s3 d ip\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Note\n\\FontSize 12\n\n\\Marker fe\n\\Endmarker fe*\n\\Name fe...fe* - Endnote\n\\Description An Endnote text item\n\\OccursUnder c lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tc1 tc2 tc3 tc4 ms ms1 ms2 ms3 s s1 s2 s3 d ip\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Note\n\\FontSize 12\n\n\\Marker fr\n\\Endmarker fr*\n\\Name fr - Footnote - Reference\n\\Description The origin reference for the footnote (basic)\n\\OccursUnder f fe\n\\TextType NoteText\n\\TextProperties publishable vernacular note\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\n\\Marker ft\n\\Endmarker ft*\n\\Name ft - Footnote - Text\n\\Description Footnote text, Protocanon (basic)\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker fk\n\\Endmarker fk*\n\\Name fk - Footnote - Keyword\n\\Description A footnote keyword (basic)\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\\Italic\n\n\\Marker fq\n\\Endmarker fq*\n\\Name fq - Footnote - Quotation or Alternate Rendering\n\\Description A footnote scripture quote or alternate rendering (basic)\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker fqa\n\\Endmarker fqa*\n\\Name fqa - Footnote - Alternate Translation Rendering\n\\Description A footnote alternate rendering for a portion of scripture text\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker fl\n\\Endmarker fl*\n\\Name fl - Footnote - Label Text\n\\Description A footnote label text item, for marking or \"labelling\" the type or alternate translation being provided in the note.\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Bold\n\n\\Marker fw\n\\Endmarker fw*\n\\Name fw - Footnote - Witness List\n\\Description A footnote witness list, for distinguishing a list of sigla representing witnesses in critical editions.\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker fp\n\\Endmarker fp*\n\\Name fp - Footnote Paragraph Mark\n\\Description A Footnote additional paragraph marker\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker fv\n\\Endmarker fv*\n\\Name fv...fv* - Footnote - Embedded Verse Number\n\\Description A verse number within the footnote text\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\n\\Marker fdc\n\\Endmarker fdc*\n\\Name DEPRECATED fdc...fdc* - Footnote - DC text\n\\Description Footnote text, applies to Deuterocanon only\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker fm\n\\Endmarker fm*\n\\Name fm - Footnote - Additional Caller to Previous Note\n\\Description An additional footnote marker location for a previous footnote \n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tc1 tc2 tc3 tc4 ms ms1 ms2 s s1 s2 s3 d ip\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\n# Cross References\n\n\\Marker x\n\\Endmarker x*\n\\Name x...x* - Cross Reference\n\\Description A list of cross references (basic)\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 qs sp tc1 tc2 tc3 tc4 mt mt1 mt2 mt3 ms ms1 ms2 s s1 s2 s3 d\n\\TextProperties publishable vernacular note crossreference\n\\TextType NoteText\n\\StyleType Note\n\\FontSize 12\n\n\\Marker xo\n\\Endmarker xo*\n\\Name xo - Cross Reference - Origin Reference\n\\Description The cross reference origin reference (basic)\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\n\\Marker xop\n\\Endmarker xop*\n\\Name xop - Cross Reference - Origin Reference Publishing Alternate\n\\Description Published cross reference origin reference (origin reference that should appear in the published text)\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker xt\n\\Endmarker xt*\n\\Name xt - Cross Reference - Target References\n\\Description The cross reference target reference(s), protocanon only (basic)\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x ef ex NEST\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n#!\\Attributes ?link-href\n\n\\Marker xta\n\\Endmarker xta*\n\\Name xta - Cross Reference - Target References Added Text\n\\Description Cross reference target references added text\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker xk\n\\Endmarker xk*\n\\Name xk - Cross Reference - Keyword\n\\Description A cross reference keyword\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker xq\n\\Endmarker xq*\n\\Name xq - Cross Reference - Quotation\n\\Description A cross-reference quotation from the scripture text\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker xot\n\\Endmarker xot*\n\\Name xot...xot* - Cross Reference - OT Target Refs (optional)\n\\Description Cross-reference target reference(s), Old Testament only\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker xnt\n\\Endmarker xnt*\n\\Name xnt...xnt* - Cross Reference - NT Target Refs (optional)\n\\Description Cross-reference target reference(s), New Testament only\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker xdc\n\\Endmarker xdc*\n\\Name DEPRECATED xdc...xdc* - Cross Reference - DC Target Refs\n\\Description Cross-reference target reference(s), Deuterocanon only\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker rq\n\\Endmarker rq*\n\\Name rq...rq* - Cross Reference - Inline Quotation References\n\\Description A cross-reference indicating the source text for the preceding quotation.\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 NEST\n\\TextType Other\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 10\n\\Italic\n\n# Other Special Text\n\n\\Marker qt\n\\Endmarker qt*\n\\Name qt...qt* - Special Text - Quoted Text - OT in NT\n\\Description For Old Testament quoted text appearing in the New Testament (basic)\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker nd\n\\Endmarker nd*\n\\Name nd...nd* - Special Text - Name of Deity\n\\Description For name of deity (basic)\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Underline\n\n\\Marker tl\n\\Endmarker tl*\n\\Name tl...tl* - Special Text - Transliterated Word\n\\Description For transliterated words\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable nonvernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker dc\n\\Endmarker dc*\n\\Name dc...dc* - Special Text - Deuterocanonical/LXX Additions\n\\Description Deuterocanonical/LXX additions or insertions in the Protocanonical text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\Italic\n\n\\Marker bk\n\\Endmarker bk*\n\\Name bk...bk* - Special Text - Quoted book title\n\\Description For the quoted name of a book\n\\OccursUnder imt imt1 imt2 imt3 imt4 imte imte1 imte2 is is1 is2 ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker sig\n\\Endmarker sig*\n\\Name sig...sig* - Special Text - Author's Signature (Epistles)\n\\Description For the signature of the author of an Epistle\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker pn\n\\Endmarker pn*\n\\Name pn...pn* - Special Text - Proper Name\n\\Description For a proper name\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\\Underline\n\n\\Marker png\n\\Endmarker png*\n\\Name png...png* - Special Text - Geographic Proper Name\n\\Description For a geographic proper name\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Underline\n\n\\Marker addpn\n\\Endmarker addpn*\n\\Name DEPRECATED addpn...addpn* - Special Text for Chinese\n\\Description For chinese words to be dot underline & underline\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n#\\Color 2263842\n##!\\ColorName green\n\\Bold\n\\Italic\n\\Underline\n\n\\Marker wj\n\\Endmarker wj*\n\\Name wj...wj* - Special Text - Words of Jesus\n\\Description For marking the words of Jesus\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Color 255\n#!\\ColorName highcon red\n\n\\Marker k\n\\Endmarker k*\n\\Name k...k* - Special Text - Keyword\n\\Description For a keyword\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Bold\n\n\\Marker sls\n\\Endmarker sls*\n\\Name sls...sls* - Special Text - Secondary Language or Text Source\n\\Description To represent where the original text is in a secondary language or from an alternate text source\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker ord\n\\Endmarker ord*\n\\Name ord...ord* - Special Text - Ordinal number text portion\n\\Description For the text portion of an ordinal number\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\n\\Marker add\n\\Endmarker add*\n\\Name add...add* - Special Text - Translational Addition\n\\Description For a translational addition to the text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n#\\Color 2263842\n##!\\ColorName green\n\\Bold\n\\Italic\n\n\\Marker lit\n\\Name lit - Special Text - Liturgical note\n\\Description For a comment or note inserted for liturgical use\n\\OccursUnder c\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\Justification Right\n\\FontSize 12\n\\Bold\n\n# Character Styling\n\n\\Marker no\n\\Endmarker no*\n\\Name no...no* - Character - Normal Text\n\\Description A character style, use normal text\n\\OccursUnder is ip ipi im imi ili ili1 ili2 imq ipq iex iq iot io1 io2 io3 io4 s s1 s2 s3 NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker it\n\\Endmarker it*\n\\Name it...it* - Character - Italic Text\n\\Description A character style, use italic text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker bd\n\\Endmarker bd*\n\\Name bd...bd* - Character - Bold Text\n\\Description A character style, use bold text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\n\\Marker bdit\n\\Endmarker bdit*\n\\Name bdit...bdit* - Character - BoldItalic Text\n\\Description A character style, use bold + italic text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\\Italic\n\n\\Marker em\n\\Endmarker em*\n\\Name em...em* - Character - Emphasized Text\n\\Description A character style, use emphasized text style\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker sc\n\\Endmarker sc*\n\\Name sc...sc* - Character - Small Caps\n\\Description A character style, for small capitalization text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Smallcaps\n\n\\Marker sup\n\\Endmarker sup*\n\\Name sup...sup* - Character - Superscript\n\\Description A character style, for superscript text. Typically for use in critical edition footnotes.\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\n# Breaks\n\n\\Marker pb\n\\Name pb - Break - Page Break\n\\Description Page Break used for new reader portions and children's bibles where content is controlled by the page\n\\OccursUnder c\n\\Rank 4\n\\TextType Other\n\\TextProperties publishable\n\\StyleType Paragraph\n\\FontSize 12\n\n# Special Features\n\n\\Marker fig\n\\Endmarker fig*\n\\Name fig...fig* - Auxiliary - Figure/Illustration/Map\n\\Description Illustration [Columns to span, height, filename, caption text]\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 ms ms1 ms2 s s1 s2 s3 d ip\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n#!\\Attributes src size ref ?alt ?loc ?copy\n\n\\Marker jmp\n\\Endmarker jmp*\n\\Name jmp...jmp* - Link text\n\\Description For associating linking attributes to a span of text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType Other\n\\StyleType Character\n\\Color 16711680\n#!\\ColorName highcon blue\n\\Underline\n#!\\Attributes ?link-href ?link-id ?link-title\n\n\\Marker pro\n\\Endmarker pro*\n\\Name DEPRECATED pro...pro* - Special Text - CJK Pronunciation\n\\Description For indicating pronunciation in CJK texts\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 ms ms1 ms2 s s1 s2 s3 d ip f fe NEST\n\\TextType Other\n\\TextProperties Nonpublishable\n\\StyleType Character\n\\FontSize 10\n\n\\Marker rb\n\\Endmarker rb*\n\\Name rb...rb* - Special Text - Ruby Glossing\n\\Description Most often used to provide a reading / pronunciation guide in ideographic scripts\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 ms ms1 ms2 s s1 s2 s3 d ip f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n#!\\Attributes gloss\n\n# Peripheral References\n\n\\Marker w\n\\Endmarker w*\n\\Name w...w* - Peripheral Ref - Wordlist Entry\n\\Description A wordlist text item\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n#!\\Attributes ?lemma ?strong ?srcloc\n\n\\Marker wh\n\\Endmarker wh*\n\\Name wh...wh* - Peripheral Ref - Hebrew Wordlist Entry\n\\Description A Hebrew wordlist text item\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker wg\n\\Endmarker wg*\n\\Name wg...wg* - Peripheral Ref - Greek Wordlist Entry\n\\Description A Greek Wordlist text item\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker wa\n\\Endmarker wa*\n\\Name wa...wa* - Peripheral Ref - Aramaic Wordlist Entry\n\\Description An Aramaic Wordlist text item\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker ndx\n\\Endmarker ndx*\n\\Name ndx...ndx* - Peripheral Ref - Subject Index Entry \n\\Description A subject index text item\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n# Peripheral Materials\n# Content Division Marker\n\n\\Marker periph\n\\Name periph - Peripherals - Content Division Marker\n\\Description Peripheral content division marker which should be followed by an additional division argument/title.\n\\TextType Section\n\\TextProperties paragraph nonpublishable vernacular\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\SpaceBefore 16\n\\SpaceAfter 4\n\\Color 33023\n#!\\ColorName orange\n\n# Additional peripheral material extensions to existing USFM markup.\n\n\\Marker p1\n\\Name p1 - Periph - Front/Back Matter Paragraph Level 1\n\\Description Front or back matter text paragraph, level 1 (if multiple levels)\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\n\\Marker p2\n\\Name p2 - Periph - Front/Back Matter Paragraph Level 2\n\\Description Front or back matter text paragraph, level 2 (if multiple levels)\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/4 inch first line indent\n\\LeftMargin .125\n\n\\Marker k1\n\\Name k1 - Periph - Concordance Keyword Level 1\n\\Description Concordance main entry text or keyword, level 1\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker k2\n\\Name k2 - Periph - Concordance Keyword Level 2\n\\Description Concordance main entry text or keyword, level 2\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker xtSee\n\\Endmarker xtSee*\n\\Name xtSee - Concordance and Names Index - Alternate Entry Target Reference\n\\Description Concordance and Names Index markup for an alternate entry target reference.\n\\OccursUnder p\n\\TextProperties publishable vernacular\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Color 16711680\n#!\\ColorName highcon blue\n\n\\Marker xtSeeAlso\n\\Endmarker xtSeeAlso*\n\\Name xtSeeAlso - Concordance and Names Index - Additional Entry Target Reference\n\\Description Concordance and Names Index markup for an additional entry target reference.\n\\OccursUnder p\n\\TextProperties publishable vernacular\n\\TextType Other\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Color 16711680\n#!\\ColorName highcon blue\n\n# Milestones - these are not compatible with USFM2, so whole entries are preceded with #!\n\n#!\\Marker qt-s\n#!\\Endmarker qt-e\n#!\\Name Quotation start/end milestone\n#!\\Description Quotation start/end milestone, level 1 (if single level)\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker qt1-s\n#!\\Endmarker qt1-e\n#!\\Name Quotation start/end milestone - Level 1\n#!\\Description Quotation start/end milestone, level 1 (if multiple levels)\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker qt2-s\n#!\\Endmarker qt2-e\n#!\\Name Quotation start/end milestone - Level 2\n#!\\Description Quotation start/end milestone, level 2\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker qt3-s\n#!\\Endmarker qt3-e\n#!\\Name Quotation start/end milestone - Level 3\n#!\\Description Quotation start/end milestone, level 3\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker qt4-s\n#!\\Endmarker qt4-e\n#!\\Name Quotation start/end milestone - Level 4\n#!\\Description Quotation start/end milestone, level 4\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker qt5-s\n#!\\Endmarker qt5-e\n#!\\Name Quotation start/end milestone - Level 5\n#!\\Description Quotation start/end milestone, level 5\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker ts-s\n#!\\Endmarker ts-e\n#!\\Name Translator's section start/end milestone\n#!\\Description Translator's section start/end milestone\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?sid ?eid\n\n# Other special text elements specified in USFM\n#   ~ = fixed (no-break) space\n#   // = discretionary line break\n\n# Obsolete, deprecated, or no longer officially part of USFM.\n# These markers may have existed in earlier resource and stylesheet revisions.\n\n\\Marker ph\n\\Name DEPRECATED ph - Paragraph - Hanging Indent - Level 1\n\\Description Paragraph text, with level 1 hanging indent (if single level)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\LeftMargin .5\n\\FirstLineIndent -.25  # 1/4 inch indent, 1/2 inch wrap\n\\FontSize 12\n\n\\Marker ph1\n\\Name DEPRECATED ph1 - Paragraph - Hanging Indent - Level 1\n\\Description Paragraph text, with level 1 hanging indent (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\LeftMargin .5\n\\FirstLineIndent -.25  # 1/4 inch indent, 1/2 inch wrap\n\\FontSize 12\n\n\\Marker ph2\n\\Name DEPRECATED ph2 - Paragraph - Hanging Indent - Level 2\n\\Description Paragraph text, with level 2 hanging indent\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\LeftMargin .75\n\\FirstLineIndent -.25  # 1/2 inch indent, 3/4 inch wrap\n\\FontSize 12\n\n\\Marker ph3\n\\Name DEPRECATED ph3 - Paragraph - Hanging Indent - Level 3\n\\Description Paragraph text, with level 3 hanging indent\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\LeftMargin 1\n\\FirstLineIndent -.25  # 3/4 inch indent, 1 inch wrap\n\\FontSize 12\n\n\\Marker phi\n\\Name DEPRECATED phi - Paragraph - Indented - Hanging Indent\n\\Description Paragraph text, indented with hanging indent\n\\OccursUnder c \n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\LeftMargin 1\n\n\\Marker tr1\n\\Name DEPRECATED tr1 - Table - Row - Level 1\n\\Description A table Row\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.25  # 6/16 inch\n\n\\Marker tr2\n\\Name DEPRECATED tr2 - Table - Row - Level 2\n\\Description A table Row\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .75\n\\FirstLineIndent -.25  # 6/16 inch\n\n\\Marker ps\n\\Name DEPRECATED ps - Paragraph - No Break with Next Paragraph\n\\Description Paragraph text, no break with next paragraph text at chapter boundary\n\\OccursUnder c \n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\n\\Marker psi\n\\Name DEPRECATED psi - Paragraph - Indented - No Break with Next\n\\Description Paragraph text, indented, with no break with next paragraph text (at chapter boundary)\n\\OccursUnder c \n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .25\n\\RightMargin .25\n\\FontSize 12\n\n\\Marker fs\n\\Endmarker fs*\n\\Name DEPRECATED fs - Footnote - Footnote Summary\n\\Description A summary text for the concept/idea/quotation from the scripture translation for which the note is being provided.\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker wr\n\\Endmarker wr*\n\\Name DEPRECATED wr...wr* - Auxiliary - Wordlist/Glossary Reference \n\\Description A Wordlist text item\n\\OccursUnder ms s lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr po q q1 q2 q3 q4 qc qr qd tc1 tc2 tc3 tc4 f fe NEST\n\\TextProperties publishable vernacular\n\\TextType VerseText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n# 2.0x peripheral markup (replaced with \\periph + Content Division Title/Argument)\n\n\\Marker pub\n\\Name DEPRECATED pub Peripherals - Front Matter Publication Data\n\\Description Front matter publication data\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker toc\n\\Name DEPRECATED toc Peripherals - Front Matter Table of Contents\n\\Description Front matter table of contents\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker pref\n\\Name DEPRECATED pref Peripherals - Front Matter Preface\n\\Description Front matter preface\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker intro\n\\Name DEPRECATED intro Peripherals - Front Matter Introduction\n\\Description Front matter introduction\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker conc\n\\Name DEPRECATED conc Peripherals - Back Matter Concordance\n\\Description Back matter concordance\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker glo\n\\Name DEPRECATED glo Peripherals - Back Matter Glossary\n\\Description Back matter glossary\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker idx\n\\Name DEPRECATED idx Peripherals - Back Matter Index\n\\Description Back matter index\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker maps\n\\Name DEPRECATED maps Peripherals - Back Matter Map Index\n\\Description Back matter map index\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker cov\n\\Name DEPRECATED cov Peripherals - Other - Cover\n\\Description Other peripheral materials - cover\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker spine\n\\Name DEPRECATED spine Peripherals - Other - Spine\n\\Description Other peripheral materials - spine\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker pubinfo\n\\Name DEPRECATED pubinfo - Publication - Information\n\\Description Publication information - Lang,Credit,Version,Copies,Publisher,Id,Logo\n\\OccursUnder id ide\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Color 16711680\n#!\\ColorName highcon blue\n\n# Concordance/Names Index Tools - special sfms for use in Publishing Assistant\n\n\\Marker zpa-xb\n\\Endmarker zpa-xb*\n\\Name zpa-xb - Periph - Book\n\\Description Book Ref\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker zpa-xc\n\\Endmarker zpa-xc*\n\\Name zpa-xc - Periph - Chapter\n\\Description Chapter Ref\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\n\\Marker zpa-xv\n\\Endmarker zpa-xv*\n\\Name zpa-xv - Periph - Verse\n\\Description Verse Ref\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker zpa-d\n\\Endmarker zpa-d*\n\\Name zpa-d - Periph - Description\n\\Description Description\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n";
// Phils Custom (cms) Checks for Paratext 10: the backend (runs in the extension host).
//
// tools/build.py makes dist/philsChecks/src/main.js from the files in src/order.json (the checks,
// global PC), then the web view HTML, the built-in usfm.sty and the version as string constants,
// then this file. Extensions may only require papi modules (no relative files, no fs), hence the
// single file. Read-only: nothing is written to the project.
//
// It adds:
//  - each check to Paratext 10's Checks panel (platformScripture.registerCheck), with the options
//    last used in the window;
//  - Tools > Phils Custom (cms) Checks... in the Scripture editor: a window that lists the checks,
//    sets their options, runs one and shows its report, whose references go to the verse.
/* global PC, PCX_WEB_VIEW_HTML, PCX_USFM_STY, PCX_VERSION */
const papi = require('@papi/backend');

const { logger } = papi;
const WEB_VIEW_TYPE = 'philsChecks.window';

let executionToken;
let builtInSty;

// ------------------------------------------------------------ helpers

function docs(summary) {
  return { method: { summary, params: [], result: { name: 'return value', schema: {} } } };
}

function verseRef(code, chapter, verse) {
  return { book: code, chapterNum: chapter, verseNum: verse };
}

async function interfaceLanguage() {
  try {
    const langs = await papi.settings.get('platform.interfaceLanguage');
    const first = Array.isArray(langs) && langs.length > 0 ? String(langs[0]).toLowerCase() : 'en';
    if (first.startsWith('es')) return 'es';
    if (first.startsWith('fr')) return 'fr';
  } catch (e) {
    logger.warn(`Phils Checks: could not read the interface language: ${e}`);
  }
  return 'en';
}

async function projectName(projectId) {
  try {
    const base = await papi.projectDataProviders.get('platform.base', projectId);
    return (await base.getSetting('platform.name')) || projectId;
  } catch (e) {
    return projectId;
  }
}

/** Books in the project (setting platformScripture.booksPresent, "0101..."), in book order. */
async function booksPresent(projectId) {
  const base = await papi.projectDataProviders.get('platform.base', projectId);
  const present = String((await base.getSetting('platformScripture.booksPresent')) || '');
  const books = [];
  for (let i = 0; i < present.length && i < PC.usfm.BOOKS.length; i++)
    if (present[i] === '1') books.push({ num: i + 1, code: PC.usfm.bookCode(i + 1) });
  return books;
}

/** The project's stylesheet from Paratext's StyleInfo; the built-in usfm.sty if it gives none. */
async function styleTable(projectId, bookNum) {
  try {
    const pdp = await papi.projectDataProviders.get('platformScripture.StyleInfo', projectId);
    const info = await pdp.getStyleInfo(bookNum || 1);
    if (info && info.markers && Object.keys(info.markers).length > 0) return PC.sty.fromStyleInfo(info);
  } catch (e) {
    logger.warn(`Phils Checks: StyleInfo not available (${e}); using the built-in usfm.sty`);
  }
  if (!builtInSty) builtInSty = PC.sty.parse(PCX_USFM_STY);
  return builtInSty;
}

function definition(checkId) {
  const def = PC.checks.get(checkId);
  if (!def) throw new Error(`Unknown check: ${checkId}`);
  return def;
}

// ------------------------------------------------------------ options (per project and check)

async function loadOptions(projectId, checkId) {
  const def = definition(checkId);
  const o = {};
  let saved = {};
  try {
    saved = JSON.parse(await papi.storage.readUserData(executionToken, `options:${projectId}:${checkId}`)) || {};
  } catch (e) {
    // nothing saved yet
  }
  def.options.forEach((d) => {
    o[d.name] = saved[d.name] !== undefined && saved[d.name] !== null ? String(saved[d.name]) : d.def;
  });
  return o;
}

async function saveOptions(projectId, checkId, options) {
  const def = definition(checkId);
  const o = {};
  def.options.forEach((d) => {
    o[d.name] = options && options[d.name] !== undefined ? String(options[d.name]) : d.def;
  });
  await papi.storage.writeUserData(executionToken, `options:${projectId}:${checkId}`, JSON.stringify(o));
  return o;
}

// ------------------------------------------------------------ the window's commands

/** The checks, in the window's language, sorted by name. */
async function listChecks(lang) {
  const L = PC.report.lang(lang || (await interfaceLanguage()));
  const list = Array.from(PC.checks.values()).map((def) => ({
    id: def.id,
    name: L.str(`Check_${def.id}_Name`),
    description: L.str(`Check_${def.id}_Desc`),
    kind: def.kind,
    options: def.options.map((d) => ({
      name: d.name,
      type: d.type,
      def: d.def,
      label: L.str(`Opt_${def.id}_${d.name}_Label`).startsWith('Opt_') ? d.name : L.str(`Opt_${def.id}_${d.name}_Label`),
      tip: L.str(`Opt_${def.id}_${d.name}_Tip`).startsWith('Opt_') ? '' : L.str(`Opt_${def.id}_${d.name}_Tip`),
    })),
  }));
  const collator = new Intl.Collator(L.code, { sensitivity: 'base' });
  list.sort((a, b) => collator.compare(a.name, b.name));
  return list;
}

/** Runs a check on every book of the project; returns its report section and its rows. */
async function runFromWindow(projectId, checkId, options, lang) {
  const def = definition(checkId);
  const used = await saveOptions(projectId, checkId, options);
  const present = await booksPresent(projectId);
  const pdp = await papi.projectDataProviders.get('platformScripture.USFM_Book', projectId);
  const books = [];
  const failed = [];
  for (const b of present) {
    try {
      const text = await pdp.getBookUSFM(verseRef(b.code, 1, 1));
      if (text !== undefined && text !== null) books.push({ num: b.num, code: b.code, text });
    } catch (e) {
      failed.push(`${b.code}: ${e}`);
    }
  }
  const sty = await styleTable(projectId, books.length > 0 ? books[0].num : 1);
  const result = PC.runCheck(def, { books, options: used, sty });
  const language = lang || (await interfaceLanguage());
  return {
    checkId,
    options: used,
    booksRead: result.booksRead,
    failed,
    count: result.findings.length,
    css: PC.report.css(def),
    html: PC.report.section(def, result, language),
    rows: PC.findingRows(result, language),
  };
}

/** Goes to "BOOK C:V" (a bare "BOOK" goes to its start) in the project's scroll group. */
async function goTo(projectId, ref) {
  const m = /^(\S+)(?:\s+(\d+)(?::(\S+))?)?$/.exec(String(ref || '').trim());
  if (!m) return false;
  const chapter = m[2] ? parseInt(m[2], 10) : 1;
  const verse = m[3] ? PC.usfm.verseNumber(m[3]) : 1;
  await papi.scrollGroups.setScrRef(undefined, verseRef(m[1], Math.max(1, chapter), verse), projectId);
  return true;
}

// ------------------------------------------------------------ the checks in the Checks panel

const VERSE_START_RE = /\\v\s+\S+\s?/g;

/** Offset of pos within its verse's text (after "\v N "); 0 at the \v itself. */
function verseOffset(chapterText, pos) {
  let last = null;
  VERSE_START_RE.lastIndex = 0;
  let m;
  while ((m = VERSE_START_RE.exec(chapterText)) !== null && m.index <= pos) last = m;
  VERSE_START_RE.lastIndex = 0;
  if (!last) return 0;
  return Math.max(0, pos - (last.index + last[0].length));
}

function refNumber(book, chapter, verse) {
  return book * 1000000 + chapter * 1000 + verse;
}

function inRange(range, bookNum, chapter, verse) {
  const s = range.start;
  const e = range.end || range.start;
  const n = refNumber(bookNum, chapter, verse);
  const lo = refNumber(PC.usfm.bookNumber(s.book), s.chapterNum, s.verseNum);
  const hi = refNumber(PC.usfm.bookNumber(e.book), e.chapterNum, range.end ? e.verseNum : s.verseNum);
  return n >= lo && n <= hi;
}

function checkDetailsOf(def) {
  return Object.freeze({
    checkName: `%philsChecks_check_${def.id}_name%`,
    checkDescription: `%philsChecks_check_${def.id}_description%`,
  });
}

/** One P10 check object for one of our checks; each book is checked on its own and cached. */
class PanelCheck {
  constructor(def) {
    this.def = def;
    this.details = checkDetailsOf(def);
    this.projectId = undefined;
    this.cache = new Map(); // bookNum -> { text, findings }
  }

  async initialize(projectId) {
    this.projectId = projectId;
    this.cache.clear();
    try {
      this.pdp = await papi.projectDataProviders.get('platformScripture.USFM_Book', projectId);
      this.options = await loadOptions(projectId, this.def.id);
      this.lang = await interfaceLanguage();
      this.sty = undefined;
    } catch (e) {
      return [String(e)];
    }
    return [];
  }

  async dispose() {
    this.projectId = undefined;
    this.pdp = undefined;
    this.cache.clear();
    return true;
  }

  getCheckDetails() {
    return this.details;
  }

  async getCheckResults(range) {
    if (!this.pdp) throw new Error('Check not initialized');
    const first = PC.usfm.bookNumber(range.start.book);
    const last = range.end ? PC.usfm.bookNumber(range.end.book) : first;
    const L = PC.report.lang(this.lang);
    const results = [];
    for (let bookNum = first; bookNum <= last && bookNum > 0; bookNum++) {
      const code = PC.usfm.bookCode(bookNum);
      let text;
      try {
        text = await this.pdp.getBookUSFM(verseRef(code, 1, 1));
      } catch (e) {
        continue;
      }
      if (!text) continue;
      let cached = this.cache.get(bookNum);
      if (!cached || cached.text !== text) {
        if (!this.sty) this.sty = await styleTable(this.projectId, bookNum);
        const result = PC.runCheck(this.def, { books: [{ num: bookNum, code, text }], options: this.options, sty: this.sty });
        cached = { text, findings: result.findings.filter((f) => f.inList) };
        this.cache.set(bookNum, cached);
      }
      const seen = new Map();
      for (const f of cached.findings) {
        const v = PC.usfm.verseNumber(f.verse);
        if (!inRange(range, bookNum, f.chapter, v)) continue;
        const ref = verseRef(code, f.chapter, v);
        const key = `${f.chapter}:${v}:${f.category}`;
        const n = (seen.get(key) || 0) + 1;
        seen.set(key, n);
        const offStart = verseOffset(f.chapterText, f.begin);
        const offEnd = verseOffset(f.chapterText, f.end);
        const message = f.localize ? f.localize(L) : f.message;
        results.push({
          checkResultType: `${this.def.id}.${f.category}`,
          checkResultUniqueId: `${f.category}#${n}`,
          projectId: this.projectId,
          verseText: f.context || '',
          itemText: f.context || message,
          messageFormatString: '%philsChecks_message%',
          formatStringArguments: { message },
          isDenied: false,
          verseRef: ref,
          start: { verseRef: ref, offset: offStart },
          end: { verseRef: ref, offset: Math.max(offStart, offEnd) },
        });
      }
    }
    return results;
  }
}

/** platform-scripture may activate after us: try for a while, in the background. */
function registerChecksWhenReady(context) {
  PC.checks.forEach((def) => {
    let tries = 0;
    const attempt = async () => {
      tries += 1;
      try {
        const unsubscribe = await papi.commands.sendCommand(
          'platformScripture.registerCheck',
          checkDetailsOf(def),
          async () => new PanelCheck(def),
        );
        context.registrations.add(unsubscribe);
        logger.info(`Phils Checks: check ${def.id} registered`);
      } catch (e) {
        if (tries < 30) setTimeout(attempt, 2000);
        else logger.error(`Phils Checks: could not register the check ${def.id}: ${e}`);
      }
    };
    attempt();
  });
}

// ------------------------------------------------------------ the window

const TITLES = {
  en: 'Phils Custom (cms) Checks',
  es: 'Verificaciones personalizadas (cms) de Phil',
  fr: 'V\u00E9rifications personnalis\u00E9es (cms) de Phil',
};

async function webViewHtml(projectId) {
  const lang = await interfaceLanguage();
  const boot = { projectId, lang, version: PCX_VERSION, projectName: await projectName(projectId) };
  // JSON inside a <script>: keep "</script>" and U+2028/9 from ending or breaking it.
  const json = JSON.stringify(boot).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
  return PCX_WEB_VIEW_HTML.replace('__PCX_BOOT__', json);
}

const webViewProvider = {
  async getWebView(savedWebView, options) {
    if (savedWebView.webViewType !== WEB_VIEW_TYPE)
      throw new Error(`${WEB_VIEW_TYPE} provider received a request for ${savedWebView.webViewType}`);
    const projectId = (options && options.projectId) || savedWebView.projectId;
    if (!projectId) return undefined;
    const lang = await interfaceLanguage();
    return {
      ...savedWebView,
      title: `${TITLES[lang]} - ${await projectName(projectId)}`,
      projectId,
      contentType: 'html',
      content: await webViewHtml(projectId),
    };
  },
};

async function openWindow(editorWebViewId) {
  let projectId;
  if (typeof editorWebViewId === 'string' && editorWebViewId) {
    try {
      const def = await papi.webViews.getOpenWebViewDefinition(editorWebViewId);
      projectId = def && def.projectId;
    } catch (e) {
      logger.warn(`Phils Checks: could not read the editor's project: ${e}`);
    }
  }
  if (!projectId) {
    try {
      projectId = await papi.dialogs.selectProject({
        title: TITLES.en,
        prompt: 'Choose the project to check',
        includeProjectInterfaces: ['platformScripture.USFM_Book'],
      });
    } catch (e) {
      logger.warn(`Phils Checks: project chooser failed: ${e}`);
    }
  }
  if (!projectId) return undefined;
  return papi.webViews.openWebView(
    WEB_VIEW_TYPE,
    { type: 'float', floatSize: { width: 1100, height: 720 } },
    { existingId: '?', existingProjectId: projectId, projectId },
  );
}

// ------------------------------------------------------------ activation

async function activate(context) {
  logger.info(`Phils Checks ${PCX_VERSION} is activating`);
  executionToken = context.executionToken;

  const register = papi.webViewProviders.registerWebViewProvider || papi.webViewProviders.register;
  const registrations = await Promise.all([
    register.call(papi.webViewProviders, WEB_VIEW_TYPE, webViewProvider),
    papi.commands.registerCommand('philsChecks.open', openWindow, docs('Open the Phils Custom (cms) Checks window')),
    papi.commands.registerCommand('philsChecks.list', listChecks, docs('List the checks')),
    papi.commands.registerCommand('philsChecks.run', runFromWindow, docs('Run a check on a project')),
    papi.commands.registerCommand('philsChecks.loadOptions', loadOptions, docs('Read the options of a check for a project')),
    papi.commands.registerCommand('philsChecks.saveOptions', saveOptions, docs('Save the options of a check for a project')),
    papi.commands.registerCommand('philsChecks.goTo', goTo, docs('Go to a verse')),
  ]);
  registrations.forEach((r) => context.registrations.add(r));
  registerChecksWhenReady(context);
  logger.info(`Phils Checks is finished activating (${PC.checks.size} checks)`);
}

async function deactivate() {
  return true;
}

exports.activate = activate;
exports.deactivate = deactivate;
