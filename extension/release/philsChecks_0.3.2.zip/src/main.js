// Phils Custom (cms) Checks 0.3.2 for Paratext 10. Built by tools/build.py from src/ - do not edit.
'use strict';
// Phils Checks core, part 1: Python regexes and string functions as Paratext's IronPython runs them.
// A port of Project_Checker\ProjectChecker\Services\PyRegex.cs, PyText.cs and Fixes.cs.
//
// IronPython's `re` is .NET Regex underneath, so \w \s \d \b have their .NET (Unicode) meaning
// whether or not re.UNICODE is given. JavaScript's do not, so translate() spells them out:
//   \s = [\f\n\r\t\v\x85\p{Z}]   \d = \p{Nd}   \w = [\p{L}\p{Mn}\p{Nd}\p{Pc}]
// and turns . ^ $ \b \A \Z (?P<..>) into their .NET meaning. Offsets are UTF-16 code units in both.
// No papi here: the build puts these files in front of main.js, and the tests load them with
// vm.runInThisContext (see src/order.json).
var PC = {};

PC.re = (function () {
  'use strict';

  var IGNORECASE = 1;
  var MULTILINE = 2;
  var DOTALL = 4;
  var UNICODE = 8;
  var VERBOSE = 16;

  var S_IN = '\\f\\n\\r\\t\\v\\x85\\p{Z}';
  var W_IN = '\\p{L}\\p{Mn}\\p{Nd}\\p{Pc}';
  var W = '[' + W_IN + ']';
  var SYNTAX = '^$\\.*+?()[]{}|/';
  var QUANT_RE = /^\{\d+(,\d*)?\}/;

  function fail(p, why) {
    throw new Error('Python regex not supported (' + why + '): ' + p);
  }

  function isAlnum(c) {
    return /[A-Za-z0-9]/.test(c);
  }

  /** Copies the argument of \x, \u, \p after the escape letter; returns the new index. */
  function copyEscapeArg(p, i, e, out) {
    if (e === 'x') {
      out.push(p.substr(i, 2));
      return i + 2;
    }
    if (e === 'u') {
      out.push(p.substr(i, 4));
      return i + 4;
    }
    if (e === 'p' || e === 'P') {
      var close = p.indexOf('}', i);
      if (p[i] !== '{' || close < 0) fail(p, '\\' + e + ' without {}');
      out.push(p.substring(i, close + 1));
      return close + 1;
    }
    return i;
  }

  /** The pattern of a Python (IronPython) regex as a JavaScript 'u' regex source. */
  function translate(p, flags) {
    flags = flags || 0;
    var out = [];
    var i = 0;
    // Inline flags at the start, e.g. (?u) or (?im).
    var lead = /^\(\?([iLmsux]+)\)/.exec(p);
    if (lead) {
      if (lead[1].indexOf('i') >= 0) flags |= IGNORECASE;
      if (lead[1].indexOf('m') >= 0) flags |= MULTILINE;
      if (lead[1].indexOf('s') >= 0) flags |= DOTALL;
      if (lead[1].indexOf('x') >= 0) flags |= VERBOSE;
      i = lead[0].length;
    }
    var verbose = (flags & VERBOSE) !== 0;
    var inClass = false;
    var classStart = false;
    while (i < p.length) {
      var c = p[i];
      if (c === '\\') {
        if (i + 1 >= p.length) fail(p, 'trailing backslash');
        var e = p[i + 1];
        i += 2;
        if (inClass) {
          classStart = false;
          if (e === 's') out.push(S_IN);
          else if (e === 'w') out.push(W_IN);
          else if (e === 'd') out.push('\\p{Nd}');
          else if (e === 'D') out.push('\\P{Nd}');
          else if (e === 'S' || e === 'W') fail(p, '\\' + e + ' inside []');
          else if (e === 'b') out.push('\\x08');
          else if (e === 'a') out.push('\\x07');
          else if ('tnrfv'.indexOf(e) >= 0) out.push('\\' + e);
          else if ('xupP'.indexOf(e) >= 0) {
            out.push('\\' + e);
            i = copyEscapeArg(p, i, e, out);
          } else if (isAlnum(e)) fail(p, '\\' + e + ' inside []');
          else if (SYNTAX.indexOf(e) >= 0 || e === '-') out.push('\\' + e);
          else out.push(e);
          continue;
        }
        if (e === 's') out.push('[' + S_IN + ']');
        else if (e === 'S') out.push('[^' + S_IN + ']');
        else if (e === 'w') out.push(W);
        else if (e === 'W') out.push('[^' + W_IN + ']');
        else if (e === 'd') out.push('\\p{Nd}');
        else if (e === 'D') out.push('\\P{Nd}');
        else if (e === 'b') out.push('(?:(?<=' + W + ')(?!' + W + ')|(?<!' + W + ')(?=' + W + '))');
        else if (e === 'B') out.push('(?:(?<=' + W + ')(?=' + W + ')|(?<!' + W + ')(?!' + W + '))');
        else if (e === 'A') out.push('(?<![\\s\\S])');
        else if (e === 'Z' || e === 'z') out.push('(?![\\s\\S])');
        else if (e === 'a') out.push('\\x07');
        else if (e === 'e') out.push('\\x1B');
        else if ('tnrfv'.indexOf(e) >= 0) out.push('\\' + e);
        else if ('xupP'.indexOf(e) >= 0) {
          out.push('\\' + e);
          i = copyEscapeArg(p, i, e, out);
        } else if (/[1-9]/.test(e)) out.push('\\' + e);
        else if (isAlnum(e)) fail(p, '\\' + e);
        else if (SYNTAX.indexOf(e) >= 0) out.push('\\' + e);
        else out.push(e);
        continue;
      }
      if (inClass) {
        if (c === ']' && !classStart) inClass = false;
        out.push(c === ']' && classStart ? '\\]' : c);
        classStart = false;
        i++;
        continue;
      }
      if (verbose && /\s/.test(c)) {
        i++;
        continue;
      }
      if (verbose && c === '#') {
        while (i < p.length && p[i] !== '\n') i++;
        continue;
      }
      if (c === '[') {
        inClass = true;
        out.push('[');
        i++;
        if (p[i] === '^') {
          out.push('^');
          i++;
        }
        classStart = true; // a ']' right after '[' or '[^' is a literal
        continue;
      }
      if (c === '(' && p[i + 1] === '?') {
        if (p[i + 2] === 'P' && p[i + 3] === '<') {
          out.push('(?<');
          i += 4;
          continue;
        }
        if (p[i + 2] === 'P' && p[i + 3] === '=') {
          var close = p.indexOf(')', i);
          out.push('\\k<' + p.substring(i + 4, close) + '>');
          i = close + 1;
          continue;
        }
        if (p[i + 2] === '#') {
          i = p.indexOf(')', i) + 1;
          continue;
        }
        if (/[iLmsux]/.test(p[i + 2] || '')) fail(p, 'inline flags inside the pattern');
        out.push('(?');
        i += 2;
        continue;
      }
      if (c === '.') {
        out.push((flags & DOTALL) !== 0 ? '[\\s\\S]' : '[^\\n]');
        i++;
        continue;
      }
      if (c === '^') {
        out.push((flags & MULTILINE) !== 0 ? '(?:^|(?<=\\n))' : '^');
        i++;
        continue;
      }
      if (c === '$') {
        out.push((flags & MULTILINE) !== 0 ? '(?=\\n|$)' : '(?=\\n?$)');
        i++;
        continue;
      }
      if (c === '{') {
        var q = QUANT_RE.exec(p.substring(i));
        if (q) {
          out.push(q[0]);
          i += q[0].length;
        } else {
          out.push('\\{');
          i++;
        }
        continue;
      }
      if (c === '}') {
        out.push('\\}');
        i++;
        continue;
      }
      out.push(c);
      i++;
    }
    if (inClass) fail(p, 'unclosed [');
    return out.join('');
  }

  /** PyRegex.Compile: a global JavaScript regex with .NET/IronPython meaning. */
  function compile(p, flags) {
    var re = new RegExp(translate(p, flags), 'gu' + ((flags || 0) & IGNORECASE ? 'i' : ''));
    re.pySource = p;
    return re;
  }

  function sticky(re) {
    if (!re.pySticky) re.pySticky = new RegExp(re.source, re.flags.replace('g', '') + 'y');
    return re.pySticky;
  }

  /**
   * Python pattern.finditer(text, pos, endpos) / .NET Regex.Matches: every match, an empty match
   * moving on by one UTF-16 unit (as .NET does). endpos makes the string end there.
   */
  function findAll(re, text, pos, endpos) {
    var list = [];
    if (endpos === undefined || endpos > text.length) endpos = text.length;
    pos = pos || 0;
    if (pos > endpos) return list;
    var s = endpos === text.length ? text : text.substring(0, endpos);
    re.lastIndex = pos;
    var m;
    while ((m = re.exec(s)) !== null) {
      list.push(m);
      if (m[0].length === 0) re.lastIndex = m.index + 1;
      if (re.lastIndex > s.length) break;
    }
    re.lastIndex = 0;
    return list;
  }

  /** Python pattern.search(text, pos, endpos): the first match or null. */
  function search(re, text, pos, endpos) {
    if (endpos === undefined || endpos > text.length) endpos = text.length;
    pos = pos || 0;
    if (pos > endpos) return null;
    var s = endpos === text.length ? text : text.substring(0, endpos);
    re.lastIndex = pos;
    var m = re.exec(s);
    re.lastIndex = 0;
    return m;
  }

  /** Python pattern.match(text, pos): anchored at pos; lookbehinds still see the text before it. */
  function matchAt(re, text, pos) {
    if (pos > text.length) return null;
    var y = sticky(re);
    y.lastIndex = pos;
    var m = y.exec(text);
    y.lastIndex = 0;
    return m;
  }

  /** re.sub with a function (or a literal string, used as is). */
  function sub(re, text, repl) {
    var parts = [];
    var pos = 0;
    findAll(re, text).forEach(function (m) {
      parts.push(text.substring(pos, m.index));
      parts.push(typeof repl === 'function' ? repl(m) : repl);
      pos = m.index + m[0].length;
    });
    parts.push(text.substring(pos));
    return parts.join('');
  }

  /** Python re.escape: a backslash before every non-alphanumeric ASCII character except _. */
  function escape(s) {
    var out = '';
    for (var i = 0; i < s.length; i++) {
      var c = s[i];
      if (!isAlnum(c) && c !== '_' && c.charCodeAt(0) < 128) out += '\\';
      out += c;
    }
    return out;
  }

  return {
    IGNORECASE: IGNORECASE,
    MULTILINE: MULTILINE,
    DOTALL: DOTALL,
    UNICODE: UNICODE,
    VERBOSE: VERBOSE,
    translate: translate,
    compile: compile,
    findAll: findAll,
    search: search,
    matchAt: matchAt,
    sub: sub,
    escape: escape,
  };
})();

/** Python string functions as IronPython has them (PyText.cs). */
PC.text = (function () {
  'use strict';

  // .NET char.IsWhiteSpace (IronPython's isspace, strip and split use it).
  var SPACE_RE = /[\t-\r\x85\p{Z}]/u;
  var MARK_RE = /\p{M}/gu;

  function isSpace(c) {
    return SPACE_RE.test(c);
  }

  function strip(s) {
    if (s === null || s === undefined) return s;
    var a = 0;
    var b = s.length;
    while (a < b && isSpace(s[a])) a++;
    while (b > a && isSpace(s[b - 1])) b--;
    return s.substring(a, b);
  }

  function rstrip(s) {
    var b = s.length;
    while (b > 0 && isSpace(s[b - 1])) b--;
    return s.substring(0, b);
  }

  function lstrip(s) {
    var a = 0;
    while (a < s.length && isSpace(s[a])) a++;
    return s.substring(a);
  }

  /** unicode.strip(chars) */
  function stripChars(s, chars) {
    var a = 0;
    var b = s.length;
    while (a < b && chars.indexOf(s[a]) >= 0) a++;
    while (b > a && chars.indexOf(s[b - 1]) >= 0) b--;
    return s.substring(a, b);
  }

  /** unicode.split() with no separator; maxsplit as in Python when given. */
  function split(s, maxsplit) {
    var parts = [];
    if (s === null || s === undefined) return parts;
    var i = 0;
    while (i < s.length) {
      while (i < s.length && isSpace(s[i])) i++;
      if (i >= s.length) break;
      if (maxsplit !== undefined && parts.length === maxsplit) {
        parts.push(rstrip(s.substring(i)));
        return parts;
      }
      var j = i;
      while (j < s.length && !isSpace(s[j])) j++;
      parts.push(s.substring(i, j));
      i = j;
    }
    return parts;
  }

  /** unicode.splitlines(): IronPython breaks only on CR, LF, CRLF, U+2028 and U+2029. */
  function splitLines(s) {
    var lines = [];
    var start = 0;
    var i = 0;
    while (i < s.length) {
      var c = s[i];
      if (c === '\n' || c === '\r' || c === '\u2028' || c === '\u2029') {
        lines.push(s.substring(start, i));
        if (c === '\r' && s[i + 1] === '\n') i++;
        start = i + 1;
      }
      i++;
    }
    if (start < s.length) lines.push(s.substring(start));
    return lines;
  }

  function lower(s) {
    return s.toLowerCase();
  }

  /** The accent-insensitive sort key (_sort_fold): NFD, without marks, lower case. */
  function sortFold(s) {
    if (s === null || s === undefined) return '';
    return s.normalize('NFD').replace(MARK_RE, '').toLowerCase();
  }

  /** string.CompareOrdinal: UTF-16 code units, as JavaScript's < compares. */
  function compare(a, b) {
    return a < b ? -1 : a > b ? 1 : 0;
  }

  /** Python's == "Yes", case-insensitive (the approved fix, Fixes.IsYes). */
  function isYes(v) {
    return v !== null && v !== undefined && lower(strip(String(v))) === 'yes';
  }

  /** Python u' ' * n */
  function repeat(c, n) {
    return n <= 0 ? '' : new Array(n + 1).join(c);
  }

  return {
    isSpace: isSpace,
    strip: strip,
    rstrip: rstrip,
    lstrip: lstrip,
    stripChars: stripChars,
    split: split,
    splitLines: splitLines,
    lower: lower,
    sortFold: sortFold,
    compare: compare,
    isYes: isYes,
    repeat: repeat,
  };
})();

// Phils Checks core, part 2: books and USFM plumbing.
// A port of Project_Checker\ProjectChecker\Services\BookCatalog.cs, ChapterSplitter.cs and Usfm.cs.
PC.usfm = (function () {
  'use strict';

  /** Paratext's canonical book list: the 1-based index is the book number. */
  var BOOKS = (
    'GEN EXO LEV NUM DEU JOS JDG RUT 1SA 2SA 1KI 2KI 1CH 2CH EZR NEH EST JOB PSA PRO ECC SNG ISA JER LAM ' +
    'EZK DAN HOS JOL AMO OBA JON MIC NAM HAB ZEP HAG ZEC MAL MAT MRK LUK JHN ACT ROM 1CO 2CO GAL EPH PHP ' +
    'COL 1TH 2TH 1TI 2TI TIT PHM HEB JAS 1PE 2PE 1JN 2JN 3JN JUD REV TOB JDT ESG WIS SIR BAR LJE S3Y SUS ' +
    'BEL 1MA 2MA 3MA 4MA 1ES 2ES MAN PS2 ODA PSS JSA JDB TBS SST DNT BLT XXA XXB XXC XXD XXE XXF XXG FRT ' +
    'BAK OTH 3ES EZA 5EZ 6EZ INT CNC GLO TDX NDX DAG PS3 2BA LBA JUB ENO 1MQ 2MQ 3MQ REP 4BA LAO'
  ).split(' ');

  function bookCode(num) {
    return num >= 1 && num <= BOOKS.length ? BOOKS[num - 1] : null;
  }

  function bookNumber(code) {
    return BOOKS.indexOf(String(code || '').toUpperCase()) + 1;
  }

  // ChapterSplitter: a chapter starts at a line whose first marker is \c N (ASCII digits).
  var CHAPTER_RE = /(?:^|(?<=\n))[ \t]*\\c[ \t]+([0-9]+)/g;

  /**
   * checking.checkAllChapters' cut of one book (ChapterSplitter.Split, IntroInChapter1): the text
   * before the first \c goes with chapter 1. Each chapter: {bookNum, bookCode, chapter, text, start,
   * lastChapter}; start = the chapter text's offset in the book.
   */
  function splitChapters(bookNum, code, usfm) {
    var result = [];
    var starts = [];
    var nums = [];
    CHAPTER_RE.lastIndex = 0;
    var m;
    while ((m = CHAPTER_RE.exec(usfm)) !== null) {
      var n = parseInt(m[1], 10);
      if (n > 2147483647) continue; // int.TryParse fails
      starts.push(m.index);
      nums.push(n);
    }
    CHAPTER_RE.lastIndex = 0;
    if (starts.length === 0) {
      result.push(make(bookNum, code, 1, usfm, 0));
    } else {
      for (var i = 0; i < starts.length; i++) {
        var end = i + 1 < starts.length ? starts[i + 1] : usfm.length;
        if (i === 0) result.push(make(bookNum, code, nums[i], usfm.substring(0, end), 0));
        else result.push(make(bookNum, code, nums[i], usfm.substring(starts[i], end), starts[i]));
      }
    }
    if (result.length > 0) result[result.length - 1].lastChapter = true;
    return result;
  }

  function make(bookNum, code, chapter, text, start) {
    return { bookNum: bookNum, bookCode: code, chapter: chapter, text: text, start: start, lastChapter: false };
  }

  var VERSE_RE = /\\v[ \t\r\n]+([^ \t\r\n\\]+)/g;
  var verseCache = { text: null, starts: [], labels: [] };

  /** Usfm.VerseAt: the label after the last \v starting at or before offset, or "0". */
  function verseAt(text, offset) {
    if (verseCache.text !== text) {
      var starts = [];
      var labels = [];
      VERSE_RE.lastIndex = 0;
      var m;
      while ((m = VERSE_RE.exec(text)) !== null) {
        starts.push(m.index);
        labels.push(m[1]);
      }
      VERSE_RE.lastIndex = 0;
      verseCache = { text: text, starts: starts, labels: labels };
    }
    var verse = '0';
    for (var i = 0; i < verseCache.starts.length; i++) {
      if (verseCache.starts[i] > offset) break;
      verse = verseCache.labels[i];
    }
    return verse;
  }

  /** Usfm.Blank: every match replaced by spaces of the same length (offsets unchanged). */
  function blank(re, text) {
    return PC.re.sub(re, text, function (m) {
      return PC.text.repeat(' ', m[0].length);
    });
  }

  /** Usfm.CollapseWhitespace: CR dropped, LF = space, runs of space/tab = one space. */
  function collapseWhitespace(s) {
    var t = s.replace(/\r/g, '').replace(/\n/g, ' ');
    var out = '';
    var prev = false;
    for (var i = 0; i < t.length; i++) {
      var c = t[i];
      var sp = c === ' ' || c === '\t';
      if (sp) {
        if (!prev) out += ' ';
      } else out += c;
      prev = sp;
    }
    return out;
  }

  /** The leading number of a verse label ("5-7" -> 5, "12a" -> 12), 0 when none. */
  function verseNumber(label) {
    var m = /^\d+/.exec(String(label || ''));
    return m ? parseInt(m[0], 10) : 0;
  }

  return {
    BOOKS: BOOKS,
    bookCode: bookCode,
    bookNumber: bookNumber,
    splitChapters: splitChapters,
    verseAt: verseAt,
    blank: blank,
    collapseWhitespace: collapseWhitespace,
    verseNumber: verseNumber,
  };
})();

// Phils Checks core, part 3: the stylesheet.
// A port of Project_Checker\ProjectChecker\Services\StylesheetService.cs (the _parse_sty /
// _merge_sty / _flag_on / _color_css / _marker_css shared by the report checks).
// A stylesheet is a Map: marker -> Map(lowercased field name -> value).
// In Paratext 10 it comes from platformScripture.StyleInfo (fromStyleInfo); the built-in usfm.sty
// and the tests use parse + merge.
PC.sty = (function () {
  'use strict';

  var T = PC.text;

  /** ParseStyText: a \Marker line opens an entry; other \Field lines set a field on it. */
  function parse(text) {
    var entries = new Map();
    var current = null;
    T.splitLines(text || '').forEach(function (raw) {
      var stripped = T.strip(raw);
      if (stripped.length === 0 || stripped[0] === '#' || stripped[0] !== '\\') return;
      var parts = T.split(stripped.substring(1), 1);
      if (parts.length === 0) return;
      var field = parts[0];
      var value = parts.length > 1 ? T.strip(parts[1]) : '';
      if (field === 'Marker') {
        current = entries.get(value);
        if (!current) {
          current = new Map();
          entries.set(value, current);
        }
      } else if (current) current.set(T.lower(field), value);
    });
    return entries;
  }

  /** usfm.sty with custom.sty laid over it, field by field. */
  function merge(base, custom) {
    var markers = new Map();
    base.forEach(function (fields, key) {
      markers.set(key, new Map(fields));
    });
    custom.forEach(function (fields, key) {
      var target = markers.get(key);
      if (!target) {
        target = new Map();
        markers.set(key, target);
      }
      fields.forEach(function (v, f) {
        target.set(f, v);
      });
    });
    return markers;
  }

  /**
   * The same table from Paratext 10's StyleInfo (merged usfm.sty + custom.sty, already resolved:
   * \Regular, \Color/\ColorName...). Its color is "#RRGGBB", kept as field "colorcss".
   */
  function fromStyleInfo(info) {
    var markers = new Map();
    var all = (info && info.markers) || {};
    Object.keys(all).forEach(function (key) {
      var s = all[key] || {};
      var f = new Map();
      if (s.styleType) f.set('styletype', String(s.styleType));
      if (s.endMarker) f.set('endmarker', String(s.endMarker));
      if (s.bold) f.set('bold', '');
      if (s.italic) f.set('italic', '');
      if (s.superscript) f.set('superscript', '');
      if (s.smallCaps) f.set('smallcaps', '');
      if (s.underline) f.set('underline', '');
      if (s.color && /^#[0-9a-fA-F]{6}$/.test(s.color)) f.set('colorcss', s.color);
      markers.set(s.marker || key, f);
    });
    return markers;
  }

  /** _flag_on: the field is present and not no/off/false/0. */
  function flagOn(fields, name) {
    if (!fields || !fields.has(name)) return false;
    var v = T.lower(T.strip(fields.get(name) || ''));
    return v !== 'no' && v !== 'off' && v !== 'false' && v !== '0';
  }

  /** _color_css: \Color is a Windows COLORREF decimal (R = low byte, B = high byte). */
  function colorCss(value) {
    if (value === null || value === undefined) return null;
    var v = T.strip(value);
    if (!/^[+-]?\d+$/.test(v)) return null;
    var n = parseInt(v, 10);
    if (!isFinite(n)) return null;
    // long arithmetic: & on a 64-bit value; JavaScript's & works on 32 bits, enough for 3 bytes.
    var r = n & 0xff;
    var g = (n >> 8) & 0xff;
    var b = (n >> 16) & 0xff;
    return 'rgb(' + r + ',' + g + ',' + b + ')';
  }

  /** _marker_css */
  function markerCss(fields) {
    if (!fields || fields.size === 0) return '';
    var parts = [];
    if (flagOn(fields, 'bold')) parts.push('font-weight:bold');
    if (flagOn(fields, 'italic')) parts.push('font-style:italic');
    if (flagOn(fields, 'superscript')) parts.push('vertical-align:super;font-size:smaller');
    if (flagOn(fields, 'smallcaps')) parts.push('font-variant:small-caps');
    if (flagOn(fields, 'underline')) parts.push('text-decoration:underline');
    if (fields.has('colorcss')) parts.push('color:' + fields.get('colorcss'));
    else if (fields.get('color')) {
      var css = colorCss(fields.get('color'));
      if (css) parts.push('color:' + css);
    }
    return parts.join(';');
  }

  /** Markers whose \StyleType is "character" (case-insensitive). */
  function characterStyles(sty) {
    var set = new Set();
    sty.forEach(function (fields, key) {
      var t = fields.get('styletype');
      if (t !== undefined && T.lower(T.strip(t)) === 'character') set.add(key);
    });
    return set;
  }

  return {
    parse: parse,
    merge: merge,
    fromStyleInfo: fromStyleInfo,
    flagOn: flagOn,
    colorCss: colorCss,
    markerCss: markerCss,
    characterStyles: characterStyles,
  };
})();

// Phils Checks core, part 4: footnote sub-markers.
// A port of Project_Checker\ProjectChecker\Services\FootnoteTokenizer.cs (report_nested_styles.py's
// _tokenize_footnote and SUBMARKER_RE, shared with find_footnotes.py).
PC.footnotes = (function () {
  'use strict';

  var R = PC.re;
  var FOOTNOTE_RE = R.compile('\\\\f\\s(.*?)\\\\f\\*', R.UNICODE | R.DOTALL);
  var SUBMARKER_RE = R.compile('\\\\\\+?[a-zA-Z][a-zA-Z0-9]*\\*?', R.UNICODE);

  /** _FOOTNOTE_LEVEL_MARKERS: the footnote's own structure, never a nested character style. */
  var LEVEL_MARKERS = new Set(['fr', 'fq', 'fqa', 'fk', 'fl', 'fp', 'ft', 'fv', 'fdc', 'fm']);

  /** _style_key: without the USFM 3 nesting '+' and the closing '*'. */
  function styleKey(marker) {
    var k = marker[0] === '+' ? marker.substring(1) : marker;
    return k[k.length - 1] === '*' ? k.substring(0, k.length - 1) : k;
  }

  /**
   * _tokenize_footnote: the inner content as segments {kind: 'text'|'close', marker, text}; the
   * leading text (the caller) has marker null. Every closing token gets its own "close" segment.
   */
  function tokenizeWithCloses(content) {
    var segments = [];
    var outer = null;
    var inner = null;
    var innerDisplay = null;
    var pos = 0;
    R.findAll(SUBMARKER_RE, content).forEach(function (m) {
      flush(segments, content, pos, m.index, inner !== null ? innerDisplay : outer);
      var raw = m[0].substring(1);
      var isClose = raw[raw.length - 1] === '*';
      var bare = raw[0] === '+' ? raw.substring(1) : raw;
      if (isClose) {
        bare = bare.substring(0, bare.length - 1);
        segments.push({ kind: 'close', marker: raw, text: '' });
        if (inner !== null && inner === bare) {
          inner = null;
          innerDisplay = null;
        } else if (outer !== null && outer === bare) outer = null;
      } else if (LEVEL_MARKERS.has(bare)) {
        inner = null;
        innerDisplay = null;
        outer = bare;
      } else {
        inner = bare;
        innerDisplay = raw;
      }
      pos = m.index + m[0].length;
    });
    flush(segments, content, pos, content.length, inner !== null ? innerDisplay : outer);
    return segments;
  }

  function flush(segs, content, start, end, marker) {
    if (end <= start) return;
    segs.push({ kind: 'text', marker: marker, text: content.substring(start, end) });
  }

  return {
    FOOTNOTE_RE: FOOTNOTE_RE,
    SUBMARKER_RE: SUBMARKER_RE,
    LEVEL_MARKERS: LEVEL_MARKERS,
    styleKey: styleKey,
    tokenizeWithCloses: tokenizeWithCloses,
  };
})();

// Phils Checks core, part 5: running a check.
// A port of Project_Checker\ProjectChecker\Checks\CheckBase.cs: the checkAllChapters loop and the
// outputError-style findings.
//
// A check is defined with PC.define({...}):
//   id, cssPrefix, original     as in Project Checker (id is also the key of its strings)
//   kind                        'report' (read-only) for now
//   options: [{name, type: 'bool'|'int'|'text', def}]
//   beginRun(run), beginBook(run, book), checkChapter(run, ch), endBook(run, book), endRun(run)
//   reportCss                   CSS of its report section (classes start with cssPrefix + '-')
//   renderReport(w, result, L)  its report section body; without it, the default grouped table
//   diffData(result)            the original-format report data the tests compare
// The run object gives state (run.state), options (run.opt), the stylesheet (run.sty) and emit.
PC.checks = new Map();

PC.define = function (def) {
  PC.checks.set(def.id, def);
  return def;
};

PC.runCheck = (function () {
  'use strict';

  function Run(def, ctx) {
    this.def = def;
    this.ctx = ctx;
    this.sty = ctx.sty || new Map();
    this.state = {};
    this.result = { checkId: def.id, findings: [], optionsUsed: {}, notes: [], reportData: null, booksRead: [] };
  }

  /** The option's value as a string (the default when not set), as CheckBase.Opt. */
  Run.prototype.opt = function (name) {
    var o = this.ctx.options || {};
    for (var i = 0; i < this.def.options.length; i++) {
      var d = this.def.options[i];
      if (d.name === name) return o[name] !== undefined && o[name] !== null ? String(o[name]) : d.def;
    }
    return o[name] !== undefined && o[name] !== null ? String(o[name]) : '';
  };

  /** A note shown above the report: a string key (of PC.strings) and its {0} {1} arguments. */
  Run.prototype.addNote = function (key) {
    this.result.notes.push({ key: key, args: Array.prototype.slice.call(arguments, 1) });
  };

  /** checking.outputError(begin, end, msg): a finding in the results list. */
  Run.prototype.emit = function (ch, begin, end, message, category) {
    var b = Math.max(0, Math.min(begin, ch.text.length));
    var e = Math.max(b, Math.min(end, ch.text.length));
    var text = ch.text.substring(b, e);
    var f = {
      checkId: this.def.id,
      category: category,
      bookNum: ch.bookNum,
      bookCode: ch.bookCode,
      chapter: ch.chapter,
      verse: PC.usfm.verseAt(ch.text, begin),
      begin: begin,
      end: end,
      text: text,
      message: message,
      context: PC.usfm.collapseWhitespace(text),
      inList: true,
      extra: {},
      localize: null,
      chapterText: ch.text,
    };
    this.result.findings.push(f);
    return f;
  };

  /** A row that exists only in the original's HTML report (no outputError call). */
  Run.prototype.emitReportOnly = function (bookNum, message, category) {
    var f = {
      checkId: this.def.id,
      category: category,
      bookNum: bookNum,
      bookCode: PC.usfm.bookCode(bookNum),
      chapter: 0,
      verse: '0',
      begin: -1,
      end: -1,
      text: null,
      message: message,
      context: null,
      inList: false,
      extra: {},
      localize: null,
      chapterText: null,
    };
    this.result.findings.push(f);
    return f;
  };

  /**
   * Runs one check. ctx = {books: [{num, code, text}], options: {name: value}, sty: Map}.
   * Books are taken in the order given (book number order).
   */
  function runCheck(def, ctx) {
    var run = new Run(def, ctx);
    def.options.forEach(function (d) {
      run.result.optionsUsed[d.name] = run.opt(d.name);
    });
    if (def.beginRun) def.beginRun(run);
    (ctx.books || []).forEach(function (book) {
      if (book.text === undefined || book.text === null) return;
      run.result.booksRead.push(book.code);
      var chapters = PC.usfm.splitChapters(book.num, book.code, book.text);
      if (def.beginBook) def.beginBook(run, book);
      chapters.forEach(function (ch) {
        def.checkChapter(run, ch);
      });
      if (def.endBook) def.endBook(run, book);
    });
    if (def.endRun) def.endRun(run);
    return run.result;
  }

  return runCheck;
})();

/** Findings as plain rows (no functions, no chapter text) in language lang, for the window. */
PC.findingRows = function (result, lang) {
  var L = PC.report.lang(lang);
  return result.findings.map(function (f, i) {
    var cat = L.str('Cat_' + f.checkId + '_' + f.category);
    return {
      id: i,
      category: f.category,
      categoryText: cat.indexOf('Cat_') === 0 ? f.category : cat,
      book: f.bookCode,
      chapter: f.chapter,
      verse: f.verse,
      inList: f.inList,
      reference: f.inList ? f.bookCode + ' ' + f.chapter + ':' + f.verse : f.bookCode,
      text: f.context,
      message: f.localize ? f.localize(L) : f.message,
    };
  });
};

// Phils Checks core, part 6: the report.
// A port of Project_Checker\ProjectChecker\Services\ReportRenderer.cs (ReportWriter and one check's
// section). The section is an HTML fragment shown inside the extension's window, so its CSS is
// scoped to .pc-report. References are links (a.pc-go with data-ref "BOOK C:V") that the window
// turns into "go to this verse".
PC.report = (function () {
  'use strict';

  var BASE_CSS =
    '{font-family:"Segoe UI",Arial,sans-serif;color:#222;background:#fff}' +
    ' h2{font-size:1.25em;margin:4px 0 8px;border-bottom:2px solid #446;padding-bottom:3px}' +
    ' h3{font-size:1.05em;margin:14px 0 6px}' +
    ' details.pc-opts{margin:6px 0 10px;font-size:.9em}' +
    ' details.pc-opts table{margin-top:4px}' +
    ' .pc-mod{font-weight:bold;color:#7a3c00}' +
    ' .pc-note{background:#fff7d6;border:1px solid #e5cf7a;padding:4px 8px;margin:6px 0}' +
    ' .pc-fail{background:#fde2e2;border:1px solid #d99;padding:4px 8px;margin:6px 0}' +
    ' details.pc-group{margin:6px 0}' +
    ' details.pc-group>summary{cursor:pointer;font-weight:bold;padding:2px 0}' +
    ' table{border-collapse:collapse;margin:4px 0}' +
    ' th,td{border:1px solid #bbb;padding:3px 8px;vertical-align:top;text-align:left}' +
    ' th{background:#eef}' +
    ' a.pc-go{color:#0b5cad;text-decoration:none;cursor:pointer}' +
    ' a.pc-go:hover{text-decoration:underline}';

  /** Prefixes every selector of a CSS text with ".pc-report ". */
  function scope(css) {
    return css
      .split('}')
      .filter(function (rule) {
        return rule.trim().length > 0;
      })
      .map(function (rule) {
        var brace = rule.indexOf('{');
        var selectors = rule.substring(0, brace).split(',');
        return (
          selectors
            .map(function (s) {
              return '.pc-report ' + s.trim();
            })
            .join(',') +
          rule.substring(brace) +
          '}'
        );
      })
      .join('\n');
  }

  /** The CSS for a check's report section. */
  function css(def) {
    return '.pc-report' + BASE_CSS.split('}')[0] + '}\n' + scope(BASE_CSS.substring(BASE_CSS.indexOf('}') + 1)) + '\n' + scope(def.reportCss || defaultCss(def.cssPrefix));
  }

  function defaultCss(p) {
    return '.' + p + '-hl{color:#c00;font-weight:bold}.' + p + '-ref{white-space:nowrap}';
  }

  /** PyText.HtmlEscape: & < > only. */
  function esc(s) {
    if (s === null || s === undefined) return '';
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  /** Escaped for an attribute value. */
  function attr(s) {
    return esc(s).replace(/"/g, '&quot;');
  }

  /** string.Format with {0} {1}... */
  function format(template, args) {
    return String(template).replace(/\{(\d+)\}/g, function (m, n) {
      var v = args[parseInt(n, 10)];
      return v === undefined ? m : String(v);
    });
  }

  /** The strings of one language: str(key) falls back to English, then to the key itself. */
  function lang(code) {
    var table = PC.strings[code] || PC.strings.en;
    function str(key) {
      if (Object.prototype.hasOwnProperty.call(table, key)) return table[key];
      if (Object.prototype.hasOwnProperty.call(PC.strings.en, key)) return PC.strings.en[key];
      return key;
    }
    return {
      code: PC.strings[code] ? code : 'en',
      str: str,
      fmt: function (key) {
        return format(str(key), Array.prototype.slice.call(arguments, 1));
      },
    };
  }

  /** A link that goes to a verse ("MAT 5:3"; a bare book code goes to its start). */
  function refLink(ref, html) {
    return '<a class="pc-go" data-ref="' + attr(ref) + '">' + (html === undefined ? esc(ref) : html) + '</a>';
  }

  function Writer() {
    this.parts = [];
  }
  Writer.prototype.line = function (html) {
    this.parts.push(html + '\n');
    return this;
  };
  Writer.prototype.toString = function () {
    return this.parts.join('');
  };

  /** CheckBase.RenderReport: one collapsible group per category, Reference | Text | Message. */
  function defaultReport(def, w, result, L) {
    if (result.findings.length === 0) {
      w.line('<p>' + esc(L.str('Rpt_NoFindings')) + '</p>');
      return;
    }
    var order = [];
    var groups = new Map();
    result.findings.forEach(function (f) {
      var cat = f.category || '';
      if (!groups.has(cat)) {
        groups.set(cat, []);
        order.push(cat);
      }
      groups.get(cat).push(f);
    });
    order.forEach(function (cat) {
      var title = L.str('Cat_' + def.id + '_' + cat);
      if (title.indexOf('Cat_') === 0) title = cat;
      var list = groups.get(cat);
      w.line('<details class="pc-group" open><summary>' + esc(title) + ' (' + list.length + ')</summary>');
      w.line(
        '<table><tr><th>' + esc(L.str('Rpt_Reference')) + '</th><th>' + esc(L.str('Rpt_Text')) + '</th><th>' +
          esc(L.str('Rpt_Message')) + '</th></tr>',
      );
      list.forEach(function (f) {
        var ref = f.inList ? f.bookCode + ' ' + f.chapter + ':' + f.verse : f.bookCode;
        w.line(
          '<tr><td class="' + def.cssPrefix + '-ref">' + refLink(ref) + '</td><td>' + esc(f.context || '') + '</td><td>' +
            esc(f.localize ? f.localize(L) : f.message || '') + '</td></tr>',
        );
      });
      w.line('</table></details>');
    });
  }

  /** ReportRenderer.AppendOptions */
  function options(def, result, L) {
    if (def.options.length === 0) return '';
    var html =
      '<details class="pc-opts"><summary>' + esc(L.str('Rpt_OptionsUsed')) + '</summary><table><tr><th>' +
      esc(L.str('Rpt_Option')) + '</th><th>' + esc(L.str('Rpt_Value')) + '</th></tr>';
    def.options.forEach(function (d) {
      var v = result.optionsUsed[d.name];
      if (v === undefined) v = d.def;
      var label = L.str('Opt_' + def.id + '_' + d.name + '_Label');
      if (label.indexOf('Opt_') === 0) label = d.name;
      html +=
        '<tr><td>' + esc(label) + ' <code>' + esc(d.name) + '</code></td><td' + (v !== d.def ? ' class="pc-mod"' : '') + '>' +
        esc(v.length === 0 ? '(' + L.str('Rpt_Empty') + ')' : v) + '</td></tr>';
    });
    return html + '</table></details>\n';
  }

  /** One check's section: heading, options used, notes, then the check's own report. */
  function section(def, result, langCode) {
    var L = lang(langCode);
    var parts = [];
    parts.push('<section class="' + def.cssPrefix + '-section">\n');
    parts.push('<h2>' + esc(L.str('Check_' + def.id + '_Name')) + '</h2>\n');
    parts.push(options(def, result, L));
    result.notes.forEach(function (n) {
      parts.push('<p class="pc-note">' + esc(L.fmt.apply(null, [n.key].concat(n.args))) + '</p>\n');
    });
    var w = new Writer();
    if (def.renderReport) def.renderReport(w, result, L);
    else defaultReport(def, w, result, L);
    parts.push(w.toString());
    parts.push('</section>\n');
    return parts.join('');
  }

  return {
    css: css,
    esc: esc,
    attr: attr,
    format: format,
    lang: lang,
    refLink: refLink,
    Writer: Writer,
    section: section,
  };
})();

// Generated by tools/make_strings.py from Project Checker's Strings.*.xaml - do not edit.
PC.strings = {
 "en": {
  "Cat_footnotes_footnote": "Footnote",
  "Cat_nested_missingplus": "Character style missing +",
  "Cat_qerrors_final": "Final punctuation in q",
  "Cat_qerrors_hanging": "Single word after punctuation",
  "Cat_qerrors_multi": "Poetry line spans multiple verses",
  "Cat_qerrors_verse": "Verse in q",
  "Cat_refnomark_ref": "Unmarked reference",
  "Cat_shortv1_short": "Short verse 1",
  "Cat_titles_missing": "Missing \\mt",
  "Cat_titles_title": "Title",
  "Check_footnotes_Desc": "Lists every footnote with its reference, caller, \\fr reference and text, formatted as in the stylesheet, plus a summary of the markers used. The results list can be searched by reference or by the markers a footnote contains, for example \"fr fq ft\".",
  "Check_footnotes_Name": "Footnotes (\\f)",
  "Check_nested_Desc": "Flags character styles inside footnotes that lack the USFM 3 '+' prefix, for example \\xt instead of \\+xt. Footnote markers such as \\fr, \\fq and \\ft are never flagged. Opening and closing markers are checked separately, so a mismatched pair is caught.",
  "Check_nested_Name": "Report of Nested Styles",
  "Check_qerrors_Desc": "Finds poetry lines (\\q, \\q1, \u2026) with structural problems: text after final punctuation, two verse numbers on one line, or text before a verse number. Optionally flags a single word left after non-final punctuation. Footnotes, cross-references and \\qs are ignored.",
  "Check_qerrors_Name": "Report of Poetry Errors",
  "Check_refnomark_Desc": "Find scripture references in text not enclosed in \\xt, \\rq, \\ior, \\fig, \\r, \\mr, or \\sr markers. Option lets you set the chapter-verse separator character.",
  "Check_refnomark_Name": "Reference without markers",
  "Check_shortv1_Desc": "Flags short verse 1 text between a paragraph marker (\\p or \\m) and the next \\p marker. Options let you set the minimum character count and add other paragraph markers to check.",
  "Check_shortv1_Name": "Short Verse 1",
  "Check_titles_Desc": "Lists the main title (\\mt\u2013\\mt3) of each book, formatted as in the stylesheet, and reports books with no \\mt. Options sort the list by title or by running header (\\h) and add an \\h column.",
  "Check_titles_Name": "Report of Titles",
  "Msg_footnotes_Footnote": "Footnote",
  "Msg_nested_MissingPlus": "Missing +: ",
  "Msg_qerrors_final": "Final punctuation in q",
  "Msg_qerrors_hanging": "Single word after punctuation",
  "Msg_qerrors_multi": "Poetry line spans multiple verses",
  "Msg_qerrors_verse": "Verse in q",
  "Msg_refnomark_Found": "Reference without markers",
  "Msg_shortv1_Chars": "{0} chars (set = {1})",
  "Opt_footnotes_HideMarkers_Label": "Hide markers in HTML report",
  "Opt_footnotes_HideMarkers_Tip": "Yes hides the marker labels (e.g. \\fq, \\+it, \\+it*) shown before each piece of footnote text in the HTML report -- the text keeps its resolved Bold/Italic/Superscript/SmallCaps/Underline/Color styling, only the marker labels themselves are hidden, for a cleaner reading view. No (default) shows the markers alongside the styled text, as today. Does not affect the Section 1 marker/style summary table or the Paratext results list.",
  "Opt_footnotes_SortAlphabetically_Label": "Sort footnotes alphabetically",
  "Opt_footnotes_SortAlphabetically_Tip": "Yes sorts the footnotes listed in the HTML report alphabetically by the footnote's own text (everything except the \\fr reference), so identical or near-identical footnotes end up next to each other for easy comparison. No (default) lists them in canonical book/chapter/verse scan order. Accented/diacritic characters are ignored when determining sort order (but are still displayed normally).",
  "Opt_qerrors_CheckDoubleVerse_Label": "Flag multiple verse markers in one poetry line?",
  "Opt_qerrors_CheckDoubleVerse_Tip": "Choose No to disable checking for two \\v markers within a single \\q/\\q1/\\q2 line (same line or continuing to the next line).",
  "Opt_qerrors_CheckFinalPunct_Label": "Flag final punctuation followed by text?",
  "Opt_qerrors_CheckFinalPunct_Tip": "Choose No to disable checking for final punctuation followed by a word character on the same poetry line.",
  "Opt_qerrors_CheckHangingWord_Label": "Flag line ending with punctuation + single word?",
  "Opt_qerrors_CheckHangingWord_Tip": "Choose Yes to flag any poetry line that ends with non-final punctuation followed by exactly one word (nothing else before end of line). May indicate the final word belongs on the following line.",
  "Opt_qerrors_CheckTextBeforeVerse_Label": "Flag text before verse marker?",
  "Opt_qerrors_CheckTextBeforeVerse_Tip": "Choose No to disable checking for text content appearing before a \\v marker in a poetry line. Normal form is \\q1 \\v N text; bad form is \\q1 text \\v N.",
  "Opt_qerrors_FinalPunctuation_Label": "Final punctuation characters",
  "Opt_qerrors_FinalPunctuation_Tip": "Characters that should end a poetry line. Flags any \\q/\\q1/\\q2 line where one of these is followed by a word character. Default is period, exclamation mark, and question mark.",
  "Opt_qerrors_MinCharsBeforePunct_Label": "Minimum characters before final punctuation",
  "Opt_qerrors_MinCharsBeforePunct_Tip": "Ignore final punctuation that appears fewer than this many characters into the poetry line text. Use this to suppress false positives on very short lines. Set to 0 to check all lines regardless of length.",
  "Opt_qerrors_NonFinalPunctuation_Label": "Non-final punctuation characters",
  "Opt_qerrors_NonFinalPunctuation_Tip": "Used only when \"Flag hanging word\" is Yes. Characters considered mid-line (non-final) punctuation.",
  "Opt_refnomark_ChapterVerseSep_Label": "Chapter-verse separator",
  "Opt_refnomark_ChapterVerseSep_Tip": "Character separating chapter from verse numbers (from Settings.xml ChapterVerseSeparator: normally : or .).",
  "Opt_shortv1_CheckOtherMarkers_Label": "Check Other Markers",
  "Opt_shortv1_CheckOtherMarkers_Tip": "Choose Yes to also check additional paragraph markers (listed below) before and after verse 1, in addition to the defaults (\\p and \\m before, \\p after).",
  "Opt_shortv1_MinChars_Label": "Minimum Characters",
  "Opt_shortv1_MinChars_Tip": "Minimum number of characters expected in verse 1 before the next paragraph marker. Shorter verse 1s will be flagged.",
  "Opt_shortv1_OtherMarkers_Label": "Other Markers",
  "Opt_shortv1_OtherMarkers_Tip": "Space-separated list of additional paragraph markers to check (without backslash), e.g.: q q1 q2 q3 q4. Only used when Check Other Markers is Yes.",
  "Opt_titles_DisplayHeader_Label": "Display Header",
  "Opt_titles_DisplayHeader_Tip": "Yes (default) adds a column to the report showing the \\h (running header) text for each book, or \"missing\" if absent. No shows only the \\mt title. Automatically turned on if Sort by Header below is Yes.",
  "Opt_titles_SortByHeader_Label": "Sort by Header",
  "Opt_titles_SortByHeader_Tip": "No (default). Yes sorts the report alphabetically by \\h text instead, overriding Sort by Title above, and automatically displays the Header column even if Display Header above is No (accented/diacritic characters are ignored when determining sort order, but are still displayed normally; books missing \\h text sort to the end).",
  "Opt_titles_SortByTitle_Label": "Sort by Title",
  "Opt_titles_SortByTitle_Tip": "No (default) lists books in canonical scan order. Yes sorts the report alphabetically by \\mt title text instead (accented/diacritic characters are ignored when determining sort order, but are still displayed normally; books with a missing title sort to the end). Overridden by Sort by Header below if that is set to Yes.",
  "Rpt_Book": "Book",
  "Rpt_Empty": "empty",
  "Rpt_Failed": "This check failed: {0}",
  "Rpt_Message": "Message",
  "Rpt_NoFindings": "No findings.",
  "Rpt_Option": "Option",
  "Rpt_OptionsUsed": "Options used",
  "Rpt_Reference": "Reference",
  "Rpt_Text": "Text",
  "Rpt_Value": "Value",
  "Rpt_footnotes_Bold": "Bold",
  "Rpt_footnotes_Caller": "Caller",
  "Rpt_footnotes_Color": "Color",
  "Rpt_footnotes_Count": "Count",
  "Rpt_footnotes_Flags": "Flags",
  "Rpt_footnotes_H1": "1. Footnote marker & style summary",
  "Rpt_footnotes_H2": "2. Footnotes found",
  "Rpt_footnotes_Hidden": "Markers are hidden.",
  "Rpt_footnotes_InSty": "In stylesheet?",
  "Rpt_footnotes_Italic": "Italic",
  "Rpt_footnotes_None": "No footnotes were found in the scanned text.",
  "Rpt_footnotes_NotInSty": "not in stylesheet",
  "Rpt_footnotes_Sample": "Sample text",
  "Rpt_footnotes_SampleCol": "Sample",
  "Rpt_footnotes_SmallCaps": "SmallCaps",
  "Rpt_footnotes_SortRef": "canonical reference",
  "Rpt_footnotes_SortText": "footnote text (alphabetically)",
  "Rpt_footnotes_StyleType": "StyleType",
  "Rpt_footnotes_Summary": "{0} footnote(s) found, sorted by {1}.",
  "Rpt_footnotes_Superscript": "Superscript",
  "Rpt_footnotes_Underline": "Underline",
  "Rpt_footnotes_Yes": "yes",
  "Rpt_nested_FootnoteText": "Footnote text",
  "Rpt_nested_H1": "1. Summary",
  "Rpt_nested_H2": "2. Footnotes with issues",
  "Rpt_nested_Marker": "Marker",
  "Rpt_nested_NoFootnotes": "No footnotes with issues were found.",
  "Rpt_nested_NoIssues": "No issues found.",
  "Rpt_nested_Occurrences": "Occurrences",
  "Rpt_nested_Summary": "{0} footnote(s) scanned, {1} flagged with a character style missing its required '+'.",
  "Rpt_qerrors_EmptyFinal": "FinalPunctuation option cannot be empty when CheckFinalPunct is Yes; the check did not run.",
  "Rpt_qerrors_EmptyNonFinal": "NonFinalPunctuation option cannot be empty when CheckHangingWord is Yes; the check did not run.",
  "Rpt_qerrors_QLine": "\\q line",
  "Rpt_shortv1_Chars": "Characters",
  "Rpt_titles_Missing": "missing",
  "Rpt_titles_NoBooks": "No books were scanned.",
  "Rpt_titles_SortH": "\\h text (alphabetically)",
  "Rpt_titles_SortMt": "\\mt title (alphabetically)",
  "Rpt_titles_SortRef": "canonical scan order",
  "Rpt_titles_SortedBy": "Sorted by {0}.",
  "Rpt_titles_Summary": "{0} book(s) scanned, {1} title(s) found, {2} missing."
 },
 "es": {
  "Cat_footnotes_footnote": "Nota al pie",
  "Cat_nested_missingplus": "Estilo de car\u00e1cter sin +",
  "Cat_qerrors_final": "Puntuaci\u00f3n final en q",
  "Cat_qerrors_hanging": "Una sola palabra despu\u00e9s de la puntuaci\u00f3n",
  "Cat_qerrors_multi": "La l\u00ednea po\u00e9tica abarca varios vers\u00edculos",
  "Cat_qerrors_verse": "Vers\u00edculo en q",
  "Cat_refnomark_ref": "Referencia sin marcar",
  "Cat_shortv1_short": "Vers\u00edculo 1 corto",
  "Cat_titles_missing": "\\mt ausente",
  "Cat_titles_title": "T\u00edtulo",
  "Check_footnotes_Desc": "Lista cada nota al pie con su referencia, llamada, referencia \\fr y texto, con el formato de la hoja de estilos, y un resumen de los marcadores usados. La lista de resultados se puede buscar por referencia o por los marcadores de la nota, por ejemplo \"fr fq ft\".",
  "Check_footnotes_Name": "Informe de las notas al pie",
  "Check_nested_Desc": "Marca los estilos de car\u00e1cter en notas al pie sin el prefijo '+' de USFM 3, por ejemplo \\xt en lugar de \\+xt. Nunca marca los marcadores propios de la nota (\\fr, \\fq, \\ft). Aperturas y cierres se revisan por separado, as\u00ed que se detecta un par desigual.",
  "Check_nested_Name": "Informe de estilos anidados",
  "Check_qerrors_Desc": "Busca l\u00edneas de poes\u00eda (\\q, \\q1, \u2026) con problemas de estructura: texto despu\u00e9s de la puntuaci\u00f3n final, dos n\u00fameros de vers\u00edculo en una l\u00ednea o texto antes de un n\u00famero de vers\u00edculo. Opcionalmente marca una sola palabra que queda tras puntuaci\u00f3n no final. Se ignoran notas, referencias cruzadas y \\qs.",
  "Check_qerrors_Name": "Informe de errores en q",
  "Check_refnomark_Desc": "Busca referencias b\u00edblicas en el texto que no est\u00e9n encerradas en marcadores \\xt, \\rq, \\ior, \\fig, \\r, \\mr o \\sr. La opci\u00f3n permite definir el car\u00e1cter separador de cap\u00edtulo y vers\u00edculo.",
  "Check_refnomark_Name": "Referencia sin marcadores",
  "Check_shortv1_Desc": "Marca el texto breve del vers\u00edculo 1 entre un marcador de p\u00e1rrafo (\\p o \\m) y el siguiente marcador \\p. Las opciones permiten definir la cantidad m\u00ednima de caracteres y agregar otros marcadores de p\u00e1rrafo a verificar.",
  "Check_shortv1_Name": "Vers\u00edculo 1 corto",
  "Check_titles_Desc": "Lista el t\u00edtulo principal (\\mt\u2013\\mt3) de cada libro, con el formato de la hoja de estilos, e informa de los libros sin \\mt. Las opciones ordenan la lista por t\u00edtulo o por encabezado (\\h) y a\u00f1aden una columna con \\h.",
  "Check_titles_Name": "Informe de los t\u00edtulos",
  "Msg_footnotes_Footnote": "Nota al pie",
  "Msg_nested_MissingPlus": "Falta +: ",
  "Msg_qerrors_final": "Puntuaci\u00f3n final en q",
  "Msg_qerrors_hanging": "Una sola palabra despu\u00e9s de la puntuaci\u00f3n",
  "Msg_qerrors_multi": "La l\u00ednea po\u00e9tica abarca varios vers\u00edculos",
  "Msg_qerrors_verse": "Vers\u00edculo en q",
  "Msg_refnomark_Found": "Referencia sin marcadores",
  "Msg_shortv1_Chars": "{0} caracteres (m\u00ednimo = {1})",
  "Opt_footnotes_HideMarkers_Label": "\u00bfOcultar los marcadores en el informe HTML?",
  "Opt_footnotes_HideMarkers_Tip": "S\u00ed oculta las etiquetas de marcador (p. ej. \\fq, \\+it, \\+it*) que aparecen antes de cada fragmento de texto de la nota en el informe HTML -- el texto conserva su formato de Negrita/Cursiva/Super\u00edndice/Versalitas/Subrayado/Color, solo se ocultan las etiquetas de marcador, para una vista de lectura m\u00e1s limpia. No (predeterminado) muestra los marcadores junto al texto con estilo, como hasta ahora. No afecta la tabla resumen de marcadores y estilos de la Secci\u00f3n 1 ni la lista de resultados de Paratext.",
  "Opt_footnotes_SortAlphabetically_Label": "\u00bfOrdenar las notas al pie alfab\u00e9ticamente?",
  "Opt_footnotes_SortAlphabetically_Tip": "S\u00ed ordena las notas al pie del informe HTML alfab\u00e9ticamente seg\u00fan el propio texto de la nota (todo excepto la referencia \\fr), de modo que las notas id\u00e9nticas o casi id\u00e9nticas queden juntas para facilitar su comparaci\u00f3n. No (predeterminado) las lista en el orden de escaneo can\u00f3nico de libro/cap\u00edtulo/vers\u00edculo. Los caracteres acentuados o con diacr\u00edticos se ignoran al determinar el orden (pero se siguen mostrando normalmente).",
  "Opt_qerrors_CheckDoubleVerse_Label": "\u00bfMarcar m\u00faltiples marcadores de vers\u00edculo en una l\u00ednea po\u00e9tica?",
  "Opt_qerrors_CheckDoubleVerse_Tip": "Elija No para deshabilitar la verificaci\u00f3n de dos marcadores \\v dentro de una sola l\u00ednea \\q/\\q1/\\q2 (en la misma l\u00ednea o continuando a la siguiente).",
  "Opt_qerrors_CheckFinalPunct_Label": "\u00bfMarcar puntuaci\u00f3n final seguida de texto?",
  "Opt_qerrors_CheckFinalPunct_Tip": "Elija No para deshabilitar la verificaci\u00f3n de puntuaci\u00f3n final seguida de un car\u00e1cter de palabra en la misma l\u00ednea po\u00e9tica.",
  "Opt_qerrors_CheckHangingWord_Label": "\u00bfMarcar l\u00ednea que termina con puntuaci\u00f3n + una sola palabra?",
  "Opt_qerrors_CheckHangingWord_Tip": "Elija S\u00ed para marcar cualquier l\u00ednea po\u00e9tica que termina con puntuaci\u00f3n no final seguida de exactamente una palabra (nada m\u00e1s antes del fin de l\u00ednea). Puede indicar que la \u00faltima palabra pertenece a la l\u00ednea siguiente.",
  "Opt_qerrors_CheckTextBeforeVerse_Label": "\u00bfMarcar texto antes del marcador de vers\u00edculo?",
  "Opt_qerrors_CheckTextBeforeVerse_Tip": "Elija No para deshabilitar la verificaci\u00f3n de contenido de texto que aparece antes de un marcador \\v en una l\u00ednea po\u00e9tica. La forma normal es \\q1 \\v N texto; la forma incorrecta es \\q1 texto \\v N.",
  "Opt_qerrors_FinalPunctuation_Label": "Caracteres de puntuaci\u00f3n final",
  "Opt_qerrors_FinalPunctuation_Tip": "Caracteres que deben terminar una l\u00ednea po\u00e9tica. Marca cualquier l\u00ednea \\q/\\q1/\\q2 donde alguno de estos es seguido por un car\u00e1cter de palabra. El valor predeterminado es punto, signo de exclamaci\u00f3n y signo de interrogaci\u00f3n.",
  "Opt_qerrors_MinCharsBeforePunct_Label": "Caracteres m\u00ednimos antes de la puntuaci\u00f3n final",
  "Opt_qerrors_MinCharsBeforePunct_Tip": "Ignore la puntuaci\u00f3n final que aparece con menos de esta cantidad de caracteres en el texto de la l\u00ednea po\u00e9tica. Use esto para suprimir falsos positivos en l\u00edneas muy cortas. Establezca en 0 para verificar todas las l\u00edneas sin importar su longitud.",
  "Opt_qerrors_NonFinalPunctuation_Label": "Caracteres de puntuaci\u00f3n no final",
  "Opt_qerrors_NonFinalPunctuation_Tip": "Se usa solo cuando \"Marcar palabra suelta\" es S\u00ed. Caracteres considerados puntuaci\u00f3n de mitad de l\u00ednea (no final).",
  "Opt_refnomark_ChapterVerseSep_Label": "Separador de cap\u00edtulo y vers\u00edculo",
  "Opt_refnomark_ChapterVerseSep_Tip": "Car\u00e1cter que separa el cap\u00edtulo del n\u00famero de vers\u00edculo (del atributo ChapterVerseSeparator en Settings.xml: normalmente : o .).",
  "Opt_shortv1_CheckOtherMarkers_Label": "Verificar otros marcadores",
  "Opt_shortv1_CheckOtherMarkers_Tip": "Elija S\u00ed para tambi\u00e9n verificar marcadores de p\u00e1rrafo adicionales (listados abajo) antes y despu\u00e9s del vers\u00edculo 1, adem\u00e1s de los predeterminados (\\p y \\m antes, \\p despu\u00e9s).",
  "Opt_shortv1_MinChars_Label": "Caracteres m\u00ednimos",
  "Opt_shortv1_MinChars_Tip": "N\u00famero m\u00ednimo de caracteres esperados en el vers\u00edculo 1 antes del siguiente marcador de p\u00e1rrafo. Se marcar\u00e1n los vers\u00edculos 1 m\u00e1s cortos que esto.",
  "Opt_shortv1_OtherMarkers_Label": "Otros marcadores",
  "Opt_shortv1_OtherMarkers_Tip": "Lista separada por espacios de marcadores de p\u00e1rrafo adicionales a verificar (sin barra invertida), p. ej.: q q1 q2 q3 q4. Solo se usa cuando Verificar otros marcadores es S\u00ed.",
  "Opt_titles_DisplayHeader_Label": "Mostrar encabezado",
  "Opt_titles_DisplayHeader_Tip": "S\u00ed (predeterminado) agrega una columna al informe que muestra el texto \\h (encabezado de p\u00e1gina) de cada libro, o \"ausente\" si no est\u00e1 presente. No muestra solo el t\u00edtulo \\mt. Se activa autom\u00e1ticamente si Ordenar por encabezado est\u00e1 en S\u00ed.",
  "Opt_titles_SortByHeader_Label": "Ordenar por encabezado",
  "Opt_titles_SortByHeader_Tip": "No (predeterminado). S\u00ed ordena el informe alfab\u00e9ticamente por el texto \\h en su lugar, anulando Ordenar por t\u00edtulo, y muestra autom\u00e1ticamente la columna de encabezado aunque Mostrar encabezado est\u00e9 en No (los caracteres acentuados/diacr\u00edticos se ignoran al determinar el orden, pero se siguen mostrando normalmente; los libros sin texto \\h se ordenan al final).",
  "Opt_titles_SortByTitle_Label": "Ordenar por t\u00edtulo",
  "Opt_titles_SortByTitle_Tip": "No (predeterminado) lista los libros en el orden can\u00f3nico de escaneo. S\u00ed ordena el informe alfab\u00e9ticamente por el texto del t\u00edtulo \\mt en su lugar (los caracteres acentuados/diacr\u00edticos se ignoran al determinar el orden, pero se siguen mostrando normalmente; los libros con t\u00edtulo ausente se ordenan al final). Anulado por Ordenar por encabezado si este est\u00e1 en S\u00ed.",
  "Rpt_Book": "Libro",
  "Rpt_Empty": "vac\u00edo",
  "Rpt_Failed": "Esta verificaci\u00f3n fall\u00f3: {0}",
  "Rpt_Message": "Mensaje",
  "Rpt_NoFindings": "No se encontr\u00f3 nada.",
  "Rpt_Option": "Opci\u00f3n",
  "Rpt_OptionsUsed": "Opciones usadas",
  "Rpt_Reference": "Referencia",
  "Rpt_Text": "Texto",
  "Rpt_Value": "Valor",
  "Rpt_footnotes_Bold": "Negrita",
  "Rpt_footnotes_Caller": "Llamada",
  "Rpt_footnotes_Color": "Color",
  "Rpt_footnotes_Count": "Cantidad",
  "Rpt_footnotes_Flags": "Indicadores",
  "Rpt_footnotes_H1": "1. Resumen de marcadores y estilos de notas al pie",
  "Rpt_footnotes_H2": "2. Notas al pie encontradas",
  "Rpt_footnotes_Hidden": "Los marcadores est\u00e1n ocultos.",
  "Rpt_footnotes_InSty": "\u00bfEn la hoja de estilo?",
  "Rpt_footnotes_Italic": "Cursiva",
  "Rpt_footnotes_None": "No se encontraron notas al pie en el texto escaneado.",
  "Rpt_footnotes_NotInSty": "no est\u00e1 en la hoja de estilo",
  "Rpt_footnotes_Sample": "Texto de muestra",
  "Rpt_footnotes_SampleCol": "Muestra",
  "Rpt_footnotes_SmallCaps": "Versalitas",
  "Rpt_footnotes_SortRef": "la referencia can\u00f3nica",
  "Rpt_footnotes_SortText": "el texto de la nota (alfab\u00e9ticamente)",
  "Rpt_footnotes_StyleType": "Tipo de estilo",
  "Rpt_footnotes_Summary": "Se encontraron {0} nota(s) al pie, ordenadas por {1}.",
  "Rpt_footnotes_Superscript": "Super\u00edndice",
  "Rpt_footnotes_Underline": "Subrayado",
  "Rpt_footnotes_Yes": "s\u00ed",
  "Rpt_nested_FootnoteText": "Texto de la nota",
  "Rpt_nested_H1": "1. Resumen",
  "Rpt_nested_H2": "2. Notas al pie con problemas",
  "Rpt_nested_Marker": "Marcador",
  "Rpt_nested_NoFootnotes": "No se encontraron notas al pie con problemas.",
  "Rpt_nested_NoIssues": "No se encontraron problemas.",
  "Rpt_nested_Occurrences": "Ocurrencias",
  "Rpt_nested_Summary": "Se escanearon {0} nota(s) al pie; se marcaron {1} con un estilo de car\u00e1cter al que le falta el '+' requerido.",
  "Rpt_qerrors_EmptyFinal": "La opci\u00f3n FinalPunctuation no puede estar vac\u00eda cuando CheckFinalPunct es S\u00ed; la verificaci\u00f3n no se ejecut\u00f3.",
  "Rpt_qerrors_EmptyNonFinal": "La opci\u00f3n NonFinalPunctuation no puede estar vac\u00eda cuando CheckHangingWord es S\u00ed; la verificaci\u00f3n no se ejecut\u00f3.",
  "Rpt_qerrors_QLine": "L\u00ednea \\q",
  "Rpt_shortv1_Chars": "Caracteres",
  "Rpt_titles_Missing": "ausente",
  "Rpt_titles_NoBooks": "No se escane\u00f3 ning\u00fan libro.",
  "Rpt_titles_SortH": "el texto \\h (alfab\u00e9ticamente)",
  "Rpt_titles_SortMt": "el t\u00edtulo \\mt (alfab\u00e9ticamente)",
  "Rpt_titles_SortRef": "el orden can\u00f3nico de escaneo",
  "Rpt_titles_SortedBy": "Ordenado por {0}.",
  "Rpt_titles_Summary": "{0} libro(s) escaneado(s), {1} t\u00edtulo(s) encontrado(s), {2} ausente(s)."
 },
 "fr": {
  "Cat_footnotes_footnote": "Note de bas de page",
  "Cat_nested_missingplus": "Style de caract\u00e8re sans +",
  "Cat_qerrors_final": "Ponctuation finale dans q",
  "Cat_qerrors_hanging": "Un seul mot apr\u00e8s la ponctuation",
  "Cat_qerrors_multi": "La ligne po\u00e9tique couvre plusieurs versets",
  "Cat_qerrors_verse": "Verset dans q",
  "Cat_refnomark_ref": "R\u00e9f\u00e9rence non balis\u00e9e",
  "Cat_shortv1_short": "Verset 1 court",
  "Cat_titles_missing": "\\mt absent",
  "Cat_titles_title": "Titre",
  "Check_footnotes_Desc": "Liste chaque note de bas de page avec sa r\u00e9f\u00e9rence, son appel, sa r\u00e9f\u00e9rence \\fr et son texte, mis en forme selon la feuille de style, et un r\u00e9sum\u00e9 des marqueurs employ\u00e9s. Les r\u00e9sultats peuvent \u00eatre filtr\u00e9s par r\u00e9f\u00e9rence ou par marqueurs, par exemple \u00ab fr fq ft \u00bb.",
  "Check_footnotes_Name": "Notes de bas de page (\\f)",
  "Check_nested_Desc": "Signale les styles de caract\u00e8re des notes de bas de page sans le pr\u00e9fixe '+' de USFM 3, par exemple \\xt au lieu de \\+xt. Les marqueurs propres aux notes (\\fr, \\fq, \\ft) ne sont jamais signal\u00e9s. Ouvrants et fermants sont v\u00e9rifi\u00e9s s\u00e9par\u00e9ment, ce qui d\u00e9tecte une paire mal assortie.",
  "Check_nested_Name": "Rapport des styles imbriqu\u00e9s",
  "Check_qerrors_Desc": "Trouve les lignes de po\u00e9sie (\\q, \\q1, \u2026) avec un probl\u00e8me de structure : texte apr\u00e8s la ponctuation finale, deux num\u00e9ros de verset sur une ligne ou texte avant un num\u00e9ro de verset. Peut signaler un mot isol\u00e9 apr\u00e8s une ponctuation non finale. Notes, renvois et \\qs sont ignor\u00e9s.",
  "Check_qerrors_Name": "Rapport des erreurs de po\u00e9sie",
  "Check_refnomark_Desc": "Recherche dans le texte les r\u00e9f\u00e9rences bibliques qui ne sont pas encadr\u00e9es par les marqueurs \\xt, \\rq, \\ior, \\fig, \\r, \\mr ou \\sr. Une option permet de d\u00e9finir le caract\u00e8re s\u00e9parateur entre chapitre et verset.",
  "Check_refnomark_Name": "R\u00e9f\u00e9rence sans marqueurs",
  "Check_shortv1_Desc": "Signale un texte court du verset 1 entre un marqueur de paragraphe (\\p ou \\m) et le marqueur \\p suivant. Les options permettent de d\u00e9finir le nombre minimal de caract\u00e8res et d'ajouter d'autres marqueurs de paragraphe \u00e0 v\u00e9rifier.",
  "Check_shortv1_Name": "Verset 1 court",
  "Check_titles_Desc": "Liste le titre principal (\\mt\u2013\\mt3) de chaque livre, mis en forme selon la feuille de style, et signale les livres sans \\mt. Les options trient la liste par titre ou par en-t\u00eate courant (\\h) et ajoutent une colonne \\h.",
  "Check_titles_Name": "Rapport des titres",
  "Msg_footnotes_Footnote": "Note de bas de page",
  "Msg_nested_MissingPlus": "+ manquant : ",
  "Msg_qerrors_final": "Ponctuation finale dans q",
  "Msg_qerrors_hanging": "Un seul mot apr\u00e8s la ponctuation",
  "Msg_qerrors_multi": "La ligne po\u00e9tique couvre plusieurs versets",
  "Msg_qerrors_verse": "Verset dans q",
  "Msg_refnomark_Found": "R\u00e9f\u00e9rence sans marqueurs",
  "Msg_shortv1_Chars": "{0} caract\u00e8res (minimum = {1})",
  "Opt_footnotes_HideMarkers_Label": "Masquer les marqueurs dans le rapport HTML",
  "Opt_footnotes_HideMarkers_Tip": "\u00ab Oui \u00bb masque les \u00e9tiquettes de marqueur (p. ex. \\fq, \\+it, \\+it*) affich\u00e9es avant chaque segment de texte de note dans le rapport HTML -- le texte conserve sa mise en forme Gras/Italique/Exposant/Petites capitales/Soulign\u00e9/Couleur r\u00e9solue ; seules les \u00e9tiquettes de marqueur elles-m\u00eames sont masqu\u00e9es, pour une lecture plus claire. \u00ab Non \u00bb (par d\u00e9faut) affiche les marqueurs \u00e0 c\u00f4t\u00e9 du texte mis en forme, comme actuellement. N'affecte pas le tableau r\u00e9capitulatif des marqueurs/styles de la section 1 ni la liste des r\u00e9sultats de Paratext.",
  "Opt_footnotes_SortAlphabetically_Label": "Trier les notes de bas de page par ordre alphab\u00e9tique",
  "Opt_footnotes_SortAlphabetically_Tip": "\u00ab Oui \u00bb trie les notes de bas de page du rapport HTML par ordre alphab\u00e9tique de leur propre texte (tout sauf la r\u00e9f\u00e9rence \\fr), de sorte que les notes identiques ou presque identiques se retrouvent c\u00f4te \u00e0 c\u00f4te pour faciliter la comparaison. \u00ab Non \u00bb (par d\u00e9faut) les r\u00e9pertorie dans l'ordre canonique d'analyse livre/chapitre/verset. Les caract\u00e8res accentu\u00e9s/diacritiques sont ignor\u00e9s pour d\u00e9terminer l'ordre de tri (mais restent affich\u00e9s normalement).",
  "Opt_qerrors_CheckDoubleVerse_Label": "Signaler plusieurs marqueurs de verset dans une ligne de po\u00e9sie ?",
  "Opt_qerrors_CheckDoubleVerse_Tip": "Choisissez \u00ab Non \u00bb pour d\u00e9sactiver la v\u00e9rification de deux marqueurs \\v dans une m\u00eame ligne \\q/\\q1/\\q2 (sur la m\u00eame ligne ou en continuant sur la ligne suivante).",
  "Opt_qerrors_CheckFinalPunct_Label": "Signaler une ponctuation finale suivie de texte ?",
  "Opt_qerrors_CheckFinalPunct_Tip": "Choisissez \u00ab Non \u00bb pour d\u00e9sactiver la v\u00e9rification d'une ponctuation finale suivie d'un caract\u00e8re de mot sur la m\u00eame ligne de po\u00e9sie.",
  "Opt_qerrors_CheckHangingWord_Label": "Signaler une ligne se terminant par une ponctuation + un seul mot ?",
  "Opt_qerrors_CheckHangingWord_Tip": "Choisissez \u00ab Oui \u00bb pour signaler toute ligne de po\u00e9sie se terminant par une ponctuation non finale suivie d'exactement un mot (rien d'autre avant la fin de la ligne). Cela peut indiquer que le dernier mot appartient \u00e0 la ligne suivante.",
  "Opt_qerrors_CheckTextBeforeVerse_Label": "Signaler du texte avant le marqueur de verset ?",
  "Opt_qerrors_CheckTextBeforeVerse_Tip": "Choisissez \u00ab Non \u00bb pour d\u00e9sactiver la v\u00e9rification du contenu textuel apparaissant avant un marqueur \\v dans une ligne de po\u00e9sie. La forme normale est \\q1 \\v N texte ; la forme incorrecte est \\q1 texte \\v N.",
  "Opt_qerrors_FinalPunctuation_Label": "Caract\u00e8res de ponctuation finale",
  "Opt_qerrors_FinalPunctuation_Tip": "Caract\u00e8res qui doivent terminer une ligne de po\u00e9sie. Signale toute ligne \\q/\\q1/\\q2 o\u00f9 l'un d'eux est suivi d'un caract\u00e8re de mot. Par d\u00e9faut : point, point d'exclamation et point d'interrogation.",
  "Opt_qerrors_MinCharsBeforePunct_Label": "Nombre minimal de caract\u00e8res avant la ponctuation finale",
  "Opt_qerrors_MinCharsBeforePunct_Tip": "Ignore la ponctuation finale qui appara\u00eet \u00e0 moins de ce nombre de caract\u00e8res du d\u00e9but du texte de la ligne de po\u00e9sie. Utilisez ce r\u00e9glage pour supprimer les faux positifs sur les lignes tr\u00e8s courtes. R\u00e9glez sur 0 pour v\u00e9rifier toutes les lignes, quelle que soit leur longueur.",
  "Opt_qerrors_NonFinalPunctuation_Label": "Caract\u00e8res de ponctuation non finale",
  "Opt_qerrors_NonFinalPunctuation_Tip": "Utilis\u00e9 uniquement lorsque \u00ab Signaler une ligne se terminant par une ponctuation + un seul mot ? \u00bb est r\u00e9gl\u00e9 sur \u00ab Oui \u00bb. Caract\u00e8res consid\u00e9r\u00e9s comme de la ponctuation de milieu de ligne (non finale).",
  "Opt_refnomark_ChapterVerseSep_Label": "S\u00e9parateur chapitre-verset",
  "Opt_refnomark_ChapterVerseSep_Tip": "Caract\u00e8re s\u00e9parant le num\u00e9ro de chapitre du num\u00e9ro de verset (d'apr\u00e8s ChapterVerseSeparator dans Settings.xml : normalement : ou .).",
  "Opt_shortv1_CheckOtherMarkers_Label": "V\u00e9rifier d'autres marqueurs",
  "Opt_shortv1_CheckOtherMarkers_Tip": "Choisissez \u00ab Oui \u00bb pour v\u00e9rifier aussi d'autres marqueurs de paragraphe (list\u00e9s ci-dessous) avant et apr\u00e8s le verset 1, en plus de ceux par d\u00e9faut (\\p et \\m avant, \\p apr\u00e8s).",
  "Opt_shortv1_MinChars_Label": "Nombre minimal de caract\u00e8res",
  "Opt_shortv1_MinChars_Tip": "Nombre minimal de caract\u00e8res attendus dans le verset 1 avant le marqueur de paragraphe suivant. Les versets 1 plus courts seront signal\u00e9s.",
  "Opt_shortv1_OtherMarkers_Label": "Autres marqueurs",
  "Opt_shortv1_OtherMarkers_Tip": "Liste, s\u00e9par\u00e9e par des espaces, de marqueurs de paragraphe suppl\u00e9mentaires \u00e0 v\u00e9rifier (sans barre oblique inverse), p. ex. : q q1 q2 q3 q4. Utilis\u00e9 uniquement lorsque \u00ab V\u00e9rifier d'autres marqueurs \u00bb est r\u00e9gl\u00e9 sur \u00ab Oui \u00bb.",
  "Opt_titles_DisplayHeader_Label": "Afficher l'en-t\u00eate",
  "Opt_titles_DisplayHeader_Tip": "\u00ab Oui \u00bb (par d\u00e9faut) ajoute au rapport une colonne affichant le texte de \\h (titre courant) de chaque livre, ou \u00ab manquant \u00bb s'il est absent. \u00ab Non \u00bb affiche uniquement le titre \\mt. Activ\u00e9 automatiquement si \u00ab Trier par en-t\u00eate \u00bb ci-dessous est r\u00e9gl\u00e9 sur \u00ab Oui \u00bb.",
  "Opt_titles_SortByHeader_Label": "Trier par en-t\u00eate",
  "Opt_titles_SortByHeader_Tip": "\u00ab Non \u00bb (par d\u00e9faut). \u00ab Oui \u00bb trie plut\u00f4t le rapport par ordre alphab\u00e9tique du texte de \\h, en rempla\u00e7ant \u00ab Trier par titre \u00bb ci-dessus, et affiche automatiquement la colonne \u00ab En-t\u00eate \u00bb m\u00eame si \u00ab Afficher l'en-t\u00eate \u00bb ci-dessus est r\u00e9gl\u00e9 sur \u00ab Non \u00bb (les caract\u00e8res accentu\u00e9s/diacritiques sont ignor\u00e9s pour d\u00e9terminer l'ordre de tri, mais restent affich\u00e9s normalement ; les livres sans texte \\h sont plac\u00e9s \u00e0 la fin).",
  "Opt_titles_SortByTitle_Label": "Trier par titre",
  "Opt_titles_SortByTitle_Tip": "\u00ab Non \u00bb (par d\u00e9faut) r\u00e9pertorie les livres dans l'ordre canonique d'analyse. \u00ab Oui \u00bb trie plut\u00f4t le rapport par ordre alphab\u00e9tique du texte du titre \\mt (les caract\u00e8res accentu\u00e9s/diacritiques sont ignor\u00e9s pour d\u00e9terminer l'ordre de tri, mais restent affich\u00e9s normalement ; les livres sans titre sont plac\u00e9s \u00e0 la fin). Remplac\u00e9 par \u00ab Trier par en-t\u00eate \u00bb ci-dessous si cette option est r\u00e9gl\u00e9e sur \u00ab Oui \u00bb.",
  "Rpt_Book": "Livre",
  "Rpt_Empty": "vide",
  "Rpt_Failed": "Cette v\u00e9rification a \u00e9chou\u00e9 : {0}",
  "Rpt_Message": "Message",
  "Rpt_NoFindings": "Aucun r\u00e9sultat.",
  "Rpt_Option": "Option",
  "Rpt_OptionsUsed": "Options utilis\u00e9es",
  "Rpt_Reference": "R\u00e9f\u00e9rence",
  "Rpt_Text": "Texte",
  "Rpt_Value": "Valeur",
  "Rpt_footnotes_Bold": "Gras",
  "Rpt_footnotes_Caller": "Appel",
  "Rpt_footnotes_Color": "Couleur",
  "Rpt_footnotes_Count": "Nombre",
  "Rpt_footnotes_Flags": "Attributs",
  "Rpt_footnotes_H1": "1. R\u00e9sum\u00e9 des marqueurs et styles des notes",
  "Rpt_footnotes_H2": "2. Notes trouv\u00e9es",
  "Rpt_footnotes_Hidden": "Les marqueurs sont masqu\u00e9s.",
  "Rpt_footnotes_InSty": "Dans la feuille de style ?",
  "Rpt_footnotes_Italic": "Italique",
  "Rpt_footnotes_None": "Aucune note n'a \u00e9t\u00e9 trouv\u00e9e dans le texte analys\u00e9.",
  "Rpt_footnotes_NotInSty": "absent de la feuille de style",
  "Rpt_footnotes_Sample": "Texte d'exemple",
  "Rpt_footnotes_SampleCol": "Exemple",
  "Rpt_footnotes_SmallCaps": "Petites capitales",
  "Rpt_footnotes_SortRef": "r\u00e9f\u00e9rence canonique",
  "Rpt_footnotes_SortText": "texte de la note (ordre alphab\u00e9tique)",
  "Rpt_footnotes_StyleType": "Type de style",
  "Rpt_footnotes_Summary": "{0} note(s) trouv\u00e9e(s), tri\u00e9e(s) par {1}.",
  "Rpt_footnotes_Superscript": "Exposant",
  "Rpt_footnotes_Underline": "Soulign\u00e9",
  "Rpt_footnotes_Yes": "oui",
  "Rpt_nested_FootnoteText": "Texte de la note",
  "Rpt_nested_H1": "1. R\u00e9sum\u00e9",
  "Rpt_nested_H2": "2. Notes de bas de page avec probl\u00e8mes",
  "Rpt_nested_Marker": "Marqueur",
  "Rpt_nested_NoFootnotes": "Aucune note avec probl\u00e8me n'a \u00e9t\u00e9 trouv\u00e9e.",
  "Rpt_nested_NoIssues": "Aucun probl\u00e8me trouv\u00e9.",
  "Rpt_nested_Occurrences": "Occurrences",
  "Rpt_nested_Summary": "{0} note(s) analys\u00e9e(s), {1} signal\u00e9e(s) avec un style de caract\u00e8re sans le '+' requis.",
  "Rpt_qerrors_EmptyFinal": "L'option FinalPunctuation ne peut pas \u00eatre vide quand CheckFinalPunct vaut Oui ; la v\u00e9rification n'a pas \u00e9t\u00e9 ex\u00e9cut\u00e9e.",
  "Rpt_qerrors_EmptyNonFinal": "L'option NonFinalPunctuation ne peut pas \u00eatre vide quand CheckHangingWord vaut Oui ; la v\u00e9rification n'a pas \u00e9t\u00e9 ex\u00e9cut\u00e9e.",
  "Rpt_qerrors_QLine": "Ligne \\q",
  "Rpt_shortv1_Chars": "Caract\u00e8res",
  "Rpt_titles_Missing": "absent",
  "Rpt_titles_NoBooks": "Aucun livre n'a \u00e9t\u00e9 analys\u00e9.",
  "Rpt_titles_SortH": "texte \\h (ordre alphab\u00e9tique)",
  "Rpt_titles_SortMt": "titre \\mt (ordre alphab\u00e9tique)",
  "Rpt_titles_SortRef": "ordre canonique d'analyse",
  "Rpt_titles_SortedBy": "Tri\u00e9 par {0}.",
  "Rpt_titles_Summary": "{0} livre(s) analys\u00e9(s), {1} titre(s) trouv\u00e9(s), {2} absent(s)."
 }
};

// Short Verse 1: a port of Project_Checker\ProjectChecker\Checks\ShortVerse1Check.cs
// (CMS/Short_V_1/short_v_1.py). Flags a short verse-1 text between a paragraph marker (\p or \m,
// plus OtherMarkers when CheckOtherMarkers is Yes) and the next \p (plus OtherMarkers).
(function () {
  'use strict';
  var R = PC.re;
  var T = PC.text;

  // short_v_1.py INLINE_RE: footnotes / cross-references on one line only.
  var INLINE_RE = R.compile('\\\\f\\s[^\\r\\n]*?\\\\f\\*|\\\\x\\s[^\\r\\n]*?\\\\x\\*', R.UNICODE);
  var VERSE1_RE = R.compile('\\\\v\\s+1(?!\\d)(?:-\\d+)?[ \\t\\r\\n]+', R.UNICODE);
  // All paragraph-type markers: used to find the marker just before \v 1.
  var ALL_PARA_RE = R.compile('\\\\(p(?:[crhi]\\d?)?|q[a-z]?\\d?|mi?|nb|b|li\\d?)(?=[\\s\\\\]|$)', R.UNICODE | R.MULTILINE);
  var CHAR_MARKER_RE = R.compile('\\\\[a-zA-Z]+\\d*\\*?\\s*', R.UNICODE);

  PC.define({
    id: 'shortv1',
    cssPrefix: 'sv',
    original: 'Short_V_1/short_v_1.py',
    kind: 'report',
    options: [
      { name: 'MinChars', type: 'int', def: '40' },
      { name: 'CheckOtherMarkers', type: 'bool', def: 'No' },
      { name: 'OtherMarkers', type: 'text', def: 'q q1 q2 q3 q4' },
    ],

    beginRun: function (run) {
      var before = new Set(['p', 'm']);
      var after = ['p'];
      if (T.isYes(run.opt('CheckOtherMarkers'))) {
        T.split(run.opt('OtherMarkers')).forEach(function (m) {
          var t = T.strip(m);
          if (t.length === 0) return;
          before.add(t);
          if (after.indexOf(t) < 0) after.push(t);
        });
      }
      // Longest first, so \q1 is tried before \q. (The C# sort is not stable; equal lengths
      // cannot change what matches here, because the lookahead needs a space or backslash.)
      after.sort(function (a, b) {
        return b.length - a.length;
      });
      var minChars = T.strip(run.opt('MinChars'));
      if (!/^[+-]?\d+$/.test(minChars)) throw new Error('MinChars is not a whole number: ' + run.opt('MinChars'));
      run.state = {
        before: before,
        afterRe: R.compile('\\\\(' + after.map(R.escape).join('|') + ')(?=[\\s\\\\]|$)', R.UNICODE | R.MULTILINE),
        minChars: parseInt(minChars, 10),
      };
    },

    checkChapter: function (run, ch) {
      var s = run.state;
      var clean = PC.usfm.blank(INLINE_RE, ch.text);
      var v1 = R.search(VERSE1_RE, clean, 0);
      if (!v1) return;

      // The paragraph marker just before \v 1 must be in the "before" set.
      var prev = R.findAll(ALL_PARA_RE, clean, 0, v1.index);
      if (prev.length === 0 || !s.before.has(prev[prev.length - 1][1])) return;

      // The next paragraph marker after verse 1's content must be in the "after" set.
      var contentStart = v1.index + v1[0].length;
      var next = R.search(s.afterRe, clean, contentStart);
      if (!next) return;

      var contentEnd = next.index;
      var verse1Text = clean.substring(contentStart, contentEnd);
      var count = T.strip(R.sub(CHAR_MARKER_RE, verse1Text, '')).length;
      if (count < s.minChars) {
        var displayEnd = contentEnd;
        while (displayEnd > contentStart && '\r\n\t '.indexOf(clean[displayEnd - 1]) >= 0) displayEnd--;
        var f = run.emit(ch, v1.index, displayEnd, count + ' chars (set = ' + s.minChars + ')', 'short');
        f.extra.chars = String(count);
        var min = s.minChars;
        f.localize = function (L) {
          return L.fmt('Msg_shortv1_Chars', count, min);
        };
      }
    },
  });
})();

// Report of Titles: a port of Project_Checker\ProjectChecker\Checks\TitlesCheck.cs
// (CMS/find_titles/Find_Titles.py). Lists the \mt / \mt1-9 title of each canonical book (1-66),
// optionally with \h, styled from the stylesheet; books with no \mt are reported as missing.
(function () {
  'use strict';
  var R = PC.re;
  var T = PC.text;
  var esc = PC.report.esc;

  // Only bare \h and \mt with zero or one digit (Find_Titles.py HEADER_MARKER_RE).
  var HEADER_RE = R.compile('^\\\\(mt[0-9]?|h)[ \\t]+([^\\r\\n]*)', R.UNICODE | R.MULTILINE);
  var WS_RUN_RE = R.compile('[ \\t]+', R.UNICODE);

  function yes(v) {
    return T.lower(T.strip(v || '')) === 'yes';
  }

  function inScope(n) {
    return n >= 1 && n <= 66;
  }

  function collapseWs(s) {
    return R.sub(WS_RUN_RE, s.replace(/\r/g, '').replace(/\n/g, ' '), ' ');
  }

  // A literal // in \mt text forces a soft line break; it is not part of the wording.
  function stripMtSoftBreaks(s) {
    return T.strip(collapseWs(s.split('//').join(' ')));
  }

  function mtLabel(segs, missing) {
    if (!segs) return missing;
    return segs
      .map(function (kv) {
        return '\\' + kv[0] + ' ' + kv[1];
      })
      .join(' ');
  }

  // _flush_book: only for a book with NO \mt or \h anywhere; the row is report-only.
  function flushBook(run, bookNum) {
    var s = run.state;
    if (bookNum === null || !inScope(bookNum)) return;
    if (s.resolved) return;
    s.missingCount++;
    s.rows.push({ bookNum: bookNum, bookLabel: PC.usfm.bookCode(bookNum), mtCombined: null, mtSegments: null, hText: null });
    var f = run.emitReportOnly(bookNum, 'missing', 'missing');
    f.localize = function (L) {
      return L.str('Rpt_titles_Missing');
    };
  }

  /** Python sorted(key=(missing, _sort_fold(value), book_num)); missing last. */
  function stableSort(rows, value) {
    return rows
      .map(function (r, i) {
        return { i: i, r: r };
      })
      .sort(function (a, b) {
        var va = value(a.r);
        var vb = value(b.r);
        var ma = va === null ? 1 : 0;
        var mb = vb === null ? 1 : 0;
        if (ma !== mb) return ma - mb;
        var c = T.compare(va === null ? '' : T.sortFold(va), vb === null ? '' : T.sortFold(vb));
        if (c !== 0) return c;
        if (a.r.bookNum !== b.r.bookNum) return a.r.bookNum - b.r.bookNum;
        return a.i - b.i;
      })
      .map(function (x) {
        return x.r;
      });
  }

  function orderedRows(d) {
    if (d.sortMode === 'mt')
      return stableSort(d.rows, function (r) {
        return r.mtCombined;
      });
    if (d.sortMode === 'h')
      return stableSort(d.rows, function (r) {
        return r.hText ? r.hText : null;
      });
    return d.rows.slice();
  }

  function mtCell(d, r, missingHtml) {
    if (r.mtCombined === null) return missingHtml;
    if (!r.mtSegments || r.mtSegments.length === 0) return esc(r.mtCombined);
    var parts = [];
    r.mtSegments.forEach(function (kv) {
      if (kv[1].length === 0) return;
      var css = PC.sty.markerCss(d.sty.get(kv[0]));
      var style = css.length > 0 ? ' style="' + css + '"' : '';
      parts.push('<span' + style + '>' + esc(kv[1]) + '</span>');
    });
    return parts.length > 0 ? parts.join(' ') : esc(r.mtCombined);
  }

  function hCell(r, missingHtml) {
    return r.hText ? esc(r.hText) : missingHtml;
  }

  PC.define({
    id: 'titles',
    cssPrefix: 'ti',
    original: 'find_titles/Find_Titles.py',
    kind: 'report',
    options: [
      { name: 'SortByTitle', type: 'bool', def: 'No' },
      { name: 'DisplayHeader', type: 'bool', def: 'Yes' },
      { name: 'SortByHeader', type: 'bool', def: 'No' },
    ],
    reportCss: '.ti-missing{color:#999;font-style:italic}.ti-table td:first-child{font-weight:bold}',

    beginRun: function (run) {
      var byTitle = yes(run.opt('SortByTitle'));
      var byHeader = yes(run.opt('SortByHeader'));
      run.state = {
        displayH: yes(run.opt('DisplayHeader')) || byHeader,
        sortMode: byHeader ? 'h' : byTitle ? 'mt' : 'reference',
        prevBook: null,
        resolved: false,
        hText: null,
        seenBooks: new Set(),
        rows: [],
        titleCount: 0,
        missingCount: 0,
        sty: run.sty,
      };
    },

    checkChapter: function (run, ch) {
      var s = run.state;
      var bookNum = ch.bookNum;
      if (s.prevBook === null || bookNum !== s.prevBook) {
        flushBook(run, s.prevBook);
        s.prevBook = bookNum;
        s.resolved = false;
        s.hText = null;
      }
      if (!inScope(bookNum)) return;
      s.seenBooks.add(bookNum);
      if (s.resolved) return;

      var matches = R.findAll(HEADER_RE, ch.text);
      if (matches.length === 0) return;

      var h = null;
      var mtParts = [];
      matches.forEach(function (m) {
        var kind = m[1];
        var val = T.strip(collapseWs(m[2]));
        if (kind === 'h' && h === null) h = val;
        else if (kind.indexOf('mt') === 0) mtParts.push([kind, val]);
      });
      if (h === null && mtParts.length === 0) return;

      s.resolved = true;
      s.hText = h;
      var mtCombined = null;
      var mtSegments = null;
      var anchor = 0;
      var label;
      var i;
      if (mtParts.length > 0) {
        s.titleCount++;
        for (i = 0; i < matches.length; i++)
          if (matches[i][1].indexOf('mt') === 0) {
            anchor = matches[i].index;
            break;
          }
        // In document order: some books put \mt2 before \mt1.
        var vals = [];
        mtSegments = [];
        mtParts.forEach(function (kv) {
          if (kv[1].length === 0) return;
          vals.push(kv[1]);
          mtSegments.push([kv[0], stripMtSoftBreaks(kv[1])]);
        });
        mtCombined = stripMtSoftBreaks(vals.join(' '));
        label = mtLabel(mtSegments);
      } else {
        s.missingCount++;
        for (i = 0; i < matches.length; i++)
          if (matches[i][1] === 'h') {
            anchor = matches[i].index;
            break;
          }
        label = 'missing';
      }
      var message = label;
      if (s.displayH) message = label + '  \\h ' + (h ? h : 'missing');

      // Zero-width anchor: go-to works, Paratext's TEXT column stays empty.
      var f = run.emit(ch, anchor, anchor, message, mtCombined !== null ? 'title' : 'missing');
      var segs = mtSegments;
      var hCopy = h;
      var displayH = s.displayH;
      f.localize = function (L) {
        var miss = L.str('Rpt_titles_Missing');
        var lbl = mtLabel(segs, miss);
        return displayH ? lbl + '  \\h ' + (hCopy ? hCopy : miss) : lbl;
      };
      f.context = mtCombined !== null ? mtCombined : '';
      if (h !== null) f.extra.h = h;
      if (mtCombined !== null) f.extra.mt = mtCombined;
      s.rows.push({ bookNum: bookNum, bookLabel: PC.usfm.bookCode(bookNum), mtCombined: mtCombined, mtSegments: mtSegments, hText: s.hText });
    },

    endRun: function (run) {
      flushBook(run, run.state.prevBook);
      run.result.reportData = run.state;
    },

    renderReport: function (w, result, L) {
      var d = result.reportData;
      if (!d) return;
      var missing = '<span class="ti-missing">' + esc(L.str('Rpt_titles_Missing')) + '</span>';
      w.line('<p>' + esc(L.fmt('Rpt_titles_Summary', d.seenBooks.size, d.titleCount, d.missingCount)) + '</p>');
      if (d.rows.length === 0) {
        w.line('<p><i>' + esc(L.str('Rpt_titles_NoBooks')) + '</i></p>');
        return;
      }
      var sortKey = d.sortMode === 'mt' ? 'Rpt_titles_SortMt' : d.sortMode === 'h' ? 'Rpt_titles_SortH' : 'Rpt_titles_SortRef';
      w.line('<p>' + esc(L.fmt('Rpt_titles_SortedBy', L.str(sortKey))) + '</p>');
      w.line('<table class="ti-table"><tr><th>' + esc(L.str('Rpt_Book')) + '</th><th>\\mt</th>' + (d.displayH ? '<th>\\h</th>' : '') + '</tr>');
      orderedRows(d).forEach(function (r) {
        w.line(
          '<tr><td>' + PC.report.refLink(r.bookLabel + ' 1:0', esc(r.bookLabel)) + '</td><td>' + mtCell(d, r, missing) + '</td>' +
            (d.displayH ? '<td>' + hCell(r, missing) + '</td>' : '') + '</tr>',
        );
      });
      w.line('</table>');
    },

    diffData: function (result) {
      var d = result.reportData;
      if (!d) return null;
      var missing = '<span class="missing">missing</span>';
      var rows = orderedRows(d).map(function (r) {
        var cells = [r.bookLabel, mtCell(d, r, missing)];
        if (d.displayH) cells.push(hCell(r, missing));
        return cells;
      });
      var sortLabel = d.sortMode === 'mt' ? '\\mt title (alphabetically)' : d.sortMode === 'h' ? '\\h text (alphabetically)' : 'canonical scan order';
      return {
        summary: d.seenBooks.size + ' book(s) scanned, ' + d.titleCount + ' title(s) found, ' + d.missingCount + ' missing.',
        sort: 'Sorted by ' + sortLabel + '.',
        rows: rows,
      };
    },
  });
})();

// Report of Nested Styles: a port of Project_Checker\ProjectChecker\Checks\NestedStylesCheck.cs
// (CMS/report_nested_styles/report_nested_styles.py). Flags character styles inside \f...\f* that
// lack the USFM 3 '+' (\xt instead of \+xt). Footnote-level markers are never flagged; markers the
// stylesheet does not declare as StyleType Character are out of scope.
(function () {
  'use strict';
  var R = PC.re;
  var T = PC.text;
  var FN = PC.footnotes;
  var esc = PC.report.esc;

  var CHAPTER_RE = R.compile('\\\\c\\s+(\\d+)', R.UNICODE);
  var VERSE_RE = R.compile('\\\\v\\s+(\\d+(?:[,-]\\d+)*)\\s*', R.UNICODE);
  var WS_RUN_RE = R.compile('[ \\t]+', R.UNICODE);

  /** _is_issue: a known character style token missing its '+'. */
  function isIssue(d, raw) {
    var hasPlus = raw[0] === '+';
    var bare = hasPlus ? raw.substring(1) : raw;
    var key = bare[bare.length - 1] === '*' ? bare.substring(0, bare.length - 1) : bare;
    if (FN.LEVEL_MARKERS.has(key)) return false;
    if (!d.characterStyles.has(key)) return false;
    return !hasPlus;
  }

  function collapseWs(s) {
    return R.sub(WS_RUN_RE, s.replace(/\r/g, '').replace(/\n/g, ' '), ' ');
  }

  /** _render_segments, with CSS class names supplied by the caller. */
  function renderSegments(d, segments, tag, tagErr, indent) {
    var out = '';
    segments.forEach(function (seg) {
      var marker = seg.marker;
      if (seg.kind === 'close') {
        out += '<span class="' + (isIssue(d, marker) ? tag + ' ' + tagErr : tag) + '">' + esc(marker) + '</span>';
        return;
      }
      if (marker === 'fp') out += '<br><span class="' + indent + '"></span>';
      var text = esc(collapseWs(seg.text));
      if (T.strip(text).length === 0) return;
      if (marker === null) {
        out += '<span>' + text + '</span>';
        return;
      }
      var css = PC.sty.markerCss(d.sty.get(FN.styleKey(marker)));
      var style = css.length > 0 ? ' style="' + css + '"' : '';
      var cls = isIssue(d, marker) ? tag + ' ' + tagErr : tag;
      out += '<span class="' + cls + '">' + esc(marker) + '</span><span' + style + '>' + text + '</span>';
    });
    return out;
  }

  function sortedCounts(d) {
    var list = Array.from(d.issueCounts.entries());
    list.sort(function (a, b) {
      if (a[1] !== b[1]) return b[1] - a[1];
      return T.compare(a[0], b[0]);
    });
    return list;
  }

  PC.define({
    id: 'nested',
    cssPrefix: 'ns',
    original: 'report_nested_styles/report_nested_styles.py',
    kind: 'report',
    options: [],
    reportCss:
      '.ns-tag{display:inline-block;font-size:10px;font-family:monospace;color:#666;background:#eee;' +
      'border:1px solid #ccc;border-radius:3px;padding:0 3px;margin:0 3px 0 8px;vertical-align:middle}' +
      '.ns-tag-err{color:#c00;background:#fee;border-color:#c00;font-weight:bold}' +
      '.ns-indent{display:inline-block;width:2ch}',

    beginRun: function (run) {
      run.state = {
        sty: run.sty,
        characterStyles: PC.sty.characterStyles(run.sty),
        issueCounts: new Map(),
        occurrences: [],
        total: 0,
        flagged: 0,
      };
    },

    checkChapter: function (run, ch) {
      var d = run.state;
      var bookLabel = ch.bookNum >= 1 && ch.bookNum <= 66 ? ch.bookCode : 'Book ' + ch.bookNum;
      var cm = R.search(CHAPTER_RE, ch.text, 0);
      var chapterLabel = cm ? cm[1] : '?';
      var verses = R.findAll(VERSE_RE, ch.text).map(function (vm) {
        return [vm.index + vm[0].length, vm[1]];
      });

      R.findAll(FN.FOOTNOTE_RE, ch.text).forEach(function (m) {
        d.total++;
        var content = m[1];
        var issues = [];
        R.findAll(FN.SUBMARKER_RE, content).forEach(function (t) {
          var display = t[0].substring(1);
          if (isIssue(d, display)) issues.push(display);
        });
        if (issues.length === 0) return;

        d.flagged++;
        issues.forEach(function (code) {
          d.issueCounts.set(code, (d.issueCounts.get(code) || 0) + 1);
        });
        var list = Array.from(new Set(issues)).sort(T.compare).join(', ');
        var f = run.emit(ch, m.index, m.index + m[0].length, 'Missing +: ' + list, 'missingplus');
        f.localize = function (L) {
          return L.str('Msg_nested_MissingPlus') + list;
        };

        // _verse_at: the last \v whose end (after trailing spaces) is <= the offset, else "-".
        var v = null;
        for (var i = 0; i < verses.length; i++) {
          if (verses[i][0] <= m.index) v = verses[i][1];
          else break;
        }
        d.occurrences.push({
          ref: bookLabel + ' ' + chapterLabel + ':' + (v === null ? '-' : v),
          linkRef: ch.bookCode + ' ' + ch.chapter + ':' + PC.usfm.verseAt(ch.text, m.index),
          segments: FN.tokenizeWithCloses(content),
        });
      });
    },

    endRun: function (run) {
      run.result.reportData = run.state;
    },

    renderReport: function (w, result, L) {
      var d = result.reportData;
      if (!d) return;
      w.line('<h3>' + esc(L.str('Rpt_nested_H1')) + '</h3>');
      w.line('<p>' + esc(L.fmt('Rpt_nested_Summary', d.total, d.flagged)) + '</p>');
      if (d.issueCounts.size === 0) w.line('<p><i>' + esc(L.str('Rpt_nested_NoIssues')) + '</i></p>');
      else {
        w.line('<table><tr><th>' + esc(L.str('Rpt_nested_Marker')) + '</th><th>' + esc(L.str('Rpt_nested_Occurrences')) + '</th></tr>');
        sortedCounts(d).forEach(function (kv) {
          w.line('<tr><td>\\' + esc(kv[0]) + '</td><td>' + kv[1] + '</td></tr>');
        });
        w.line('</table>');
      }
      w.line('<h3>' + esc(L.str('Rpt_nested_H2')) + '</h3>');
      if (d.occurrences.length === 0) {
        w.line('<p><i>' + esc(L.str('Rpt_nested_NoFootnotes')) + '</i></p>');
        return;
      }
      w.line('<details class="pc-group" open><summary>' + esc(L.str('Rpt_nested_H2')) + ' (' + d.occurrences.length + ')</summary>');
      w.line('<table><tr><th>' + esc(L.str('Rpt_Reference')) + '</th><th>' + esc(L.str('Rpt_nested_FootnoteText')) + '</th></tr>');
      d.occurrences.forEach(function (o) {
        w.line(
          '<tr><td><b>' + PC.report.refLink(o.linkRef, esc(o.ref)) + '</b></td><td>' +
            renderSegments(d, o.segments, 'ns-tag', 'ns-tag-err', 'ns-indent') + '</td></tr>',
        );
      });
      w.line('</table></details>');
    },

    diffData: function (result) {
      var d = result.reportData;
      if (!d) return null;
      return {
        summary: d.total + ' footnote(s) scanned, ' + d.flagged + ' flagged with a character style missing its required &#39;+&#39;.',
        counts: sortedCounts(d).map(function (kv) {
          return ['\\' + esc(kv[0]), String(kv[1])];
        }),
        rows: d.occurrences.map(function (o) {
          return [esc(o.ref), renderSegments(d, o.segments, 'tag', 'tag-err', 'indent')];
        }),
      };
    },
  });
})();

// Reference Without Markers: a port of Project_Checker\ProjectChecker\Checks\RefWithoutMarkersCheck.cs
// (CMS/reference_without_markers/reference_without_markers.py). Flags scripture references in the
// text that are not inside \xt, \rq, \ior, \fig, \r, \mr, \sr (or \x, \fr, \xo, \rem). Footnote
// \ft text is still scanned.
(function () {
  'use strict';
  var R = PC.re;

  // Whole \x...\x* spans (inside them \xt needs no closing marker), then \xt / \+xt spans outside.
  var MARKED_SPAN_RE = R.compile(
    '\\\\x\\s.*?\\\\x\\*' +
      '|\\\\[+]?xt\\b.*?\\\\[+]?xt\\*' +
      '|\\\\[+]?xt\\b[^\\\\]*' +
      '|\\\\rq\\b.*?\\\\rq\\*' +
      '|\\\\ior\\b.*?\\\\ior\\*' +
      '|\\\\fig\\b.*?\\\\fig\\*',
    R.UNICODE | R.DOTALL,
  );
  // Line-level reference markers (\r, \mr, \sr): blanked to the end of the line.
  var LINE_REF_RE = R.compile('\\\\(?:r|mr|sr)\\b[^\\r\\n]*', R.UNICODE);
  // \fr and \xo: blanked to the next marker.
  var ORIG_MARKER_RE = R.compile('\\\\(?:fr|xo)\\b[^\\\\]*', R.UNICODE);
  // \rem: free-text remarks, blanked to the next marker.
  var REM_MARKER_RE = R.compile('\\\\rem\\b[^\\\\]*', R.UNICODE);

  // _L: any letter, [^\W\d_] (.NET: a word character that is not a digit or _).
  var L = '(?:(?![\\d_])\\w)';
  // _COMB: U+0300-036F, U+0610-065F, U+1DC0-1DFF, U+FE20-FE2F.
  var COMB = '[\\u0300-\\u036f\\u0610-\\u065f\\u1dc0-\\u1dff\\ufe20-\\ufe2f]';
  var BC = '(?:' + L + COMB + '*)';

  PC.define({
    id: 'refnomark',
    cssPrefix: 'rw',
    original: 'reference_without_markers/reference_without_markers.py',
    kind: 'report',
    options: [{ name: 'ChapterVerseSep', type: 'text', def: ':', required: true }],

    beginRun: function (run) {
      var sep = run.opt('ChapterVerseSep');
      if (sep.length === 0) throw new Error('ChapterVerseSep must not be empty');
      var cvs = R.escape(sep);
      var pat =
        '(?<!\\w)' +
        // The book name is optional: "Mat 5:12" or a bare "5:12".
        '(?:' +
        // Numbered books: "1 S", "2 Cr", "3 Jn", "1 Corintios" (NBSP allowed).
        '(?:[123][ \\u00a0]' + BC + '{1,}' +
        // Abbreviation or spelled name, at least 2 letters.
        '|' + BC + '{2,})' +
        '[ \\t]+' +
        ')?' +
        '\\d{1,3}' + cvs +
        // Not an all-zero verse ("50.00").
        '(?!0{2,3}(?!\\d))' +
        '\\d{1,3}[a-z]?' +
        // Range end: hyphen or en dash; verse range or across chapters.
        '(?:[-\\u2013]\\d{1,3}(?:' + cvs + '\\d{1,3})?[a-z]?)?' +
        // Verse lists: ", 63-71" or ",24".
        '(?:,[ ]?\\d{1,3}[a-z]?(?:-\\d{1,3}[a-z]?)?)*';
      run.state.bareRefRe = R.compile(pat, R.UNICODE);
    },

    checkChapter: function (run, ch) {
      var b = PC.usfm.blank(MARKED_SPAN_RE, ch.text);
      b = PC.usfm.blank(LINE_REF_RE, b);
      b = PC.usfm.blank(ORIG_MARKER_RE, b);
      b = PC.usfm.blank(REM_MARKER_RE, b);
      R.findAll(run.state.bareRefRe, b).forEach(function (m) {
        var f = run.emit(ch, m.index, m.index + m[0].length, '', 'ref');
        f.localize = function (L2) {
          return L2.str('Msg_refnomark_Found');
        };
      });
    },
  });
})();

// q Errors: a port of Project_Checker\ProjectChecker\Checks\QErrorsCheck.cs (CMS/q_errors/q_error.py).
// Flags poetry lines (\q, \q1, \q2..., with Project Checker's approved fixes) with final punctuation
// followed by more text (p1a/p1b), two verses on one line (p2a/p2b), text before the verse marker
// (p3) and, optionally, a line ending in non-final punctuation plus one hanging word (p4). One
// finding per match start: the first pattern (p1a..p4) to match there wins.
(function () {
  'use strict';
  var R = PC.re;
  var T = PC.text;
  var U = PC.usfm;
  var esc = PC.report.esc;

  // Notes, cross-references, \qs...\qs* and \fig on one line, plus any closing marker.
  var INLINE_RE = R.compile(
    '\\\\f\\s[^\\r\\n]*?\\\\f\\*|\\\\x\\s[^\\r\\n]*?\\\\x\\*|\\\\qs\\s[^\\r\\n]*?\\\\qs\\*|\\\\fig\\s[^\\r\\n]*?\\\\fig\\*|\\\\[a-z]+\\*',
    R.UNICODE,
  );
  var Q_VERSE_RE = R.compile('\\\\q\\d?[ \\t]+\\\\v[ \\t]+(\\d+)');
  var DIGITS_RE = R.compile('\\d+', R.UNICODE);
  var Q_MARK_RE = R.compile('\\\\q\\d?[ \\t\\r\\n]+', R.UNICODE);
  var NEWLINE_RE = R.compile('\\r?\\n', R.UNICODE);
  var H_WS_RE = R.compile('[ \\t]*', R.UNICODE);
  var VERSE_START_RE = R.compile('\\\\v\\s', R.UNICODE);
  var WS_RUN_RE = R.compile('[ \\t]+', R.UNICODE);
  // _display_parts: the line without note/xref/\qs/\fig spans and without character markers that
  // open and close on it; a closing marker also takes a |attribute part before it.
  var DISPLAY_DROP_RE = R.compile(
    '\\\\f\\s[^\\r\\n]*?\\\\f\\*|\\\\x\\s[^\\r\\n]*?\\\\x\\*|\\\\qs\\s[^\\r\\n]*?\\\\qs\\*|\\\\fig\\s[^\\r\\n]*?\\\\fig\\*' +
      '|(?:\\|[^\\\\\\r\\n]*)?\\\\\\+?([A-Za-z]+\\d*)\\*',
    R.UNICODE,
  );
  var DISPLAY_OPEN_RE = R.compile('\\\\\\+?([A-Za-z]+\\d*)[ ]', R.UNICODE);

  var MSG_FINAL = 'Final punctuation in q';
  var MSG_VERSE = 'Verse in q';
  var MSG_MULTI = 'Poetry line spans multiple verses';
  var MSG_HANGING = 'Single word after punctuation';
  var MSG_ORDER = [MSG_FINAL, MSG_VERSE, MSG_MULTI, MSG_HANGING];

  /** make_char_class: \ ] ^ - escaped inside [...]. */
  function makeCharClass(chars) {
    var s = '[';
    for (var i = 0; i < chars.length; i++) {
      if ('\\]^-'.indexOf(chars[i]) >= 0) s += '\\';
      s += chars[i];
    }
    return s + ']';
  }

  function collapseWs(s) {
    return R.sub(WS_RUN_RE, s.replace(/\r/g, '').replace(/\n/g, ' '), ' ');
  }

  /** _line_end: one line at a time from the \q, going on only when the next line opens with \v. */
  function lineEnd(processed, lineStart) {
    var n = processed.length;
    var qm = R.matchAt(Q_MARK_RE, processed, lineStart);
    var pos = lineStart + (qm ? qm[0].length : 0);
    for (;;) {
      var nl = R.search(NEWLINE_RE, processed, pos);
      if (!nl) return n;
      var after = nl.index + nl[0].length;
      var ws = R.matchAt(H_WS_RE, processed, after);
      var afterWs = after + (ws ? ws[0].length : 0);
      if (R.matchAt(VERSE_START_RE, processed, afterWs)) {
        pos = afterWs;
        continue;
      }
      return nl.index;
    }
  }

  function keepUndropped(text, drop, origin, a, b) {
    var out = '';
    for (var i = a; i < b; i++) {
      var k = i - origin;
      if (k >= 0 && k < drop.length && drop[k]) continue;
      out += text[i];
    }
    return out;
  }

  /** _display_parts: before the trigger, the trigger, and after it (to lineEnd). */
  function displayParts(text, start, trigStart, trigEnd, end) {
    var seg = text.substring(start, start + Math.max(0, end - start));
    var drop = new Array(seg.length);
    R.findAll(DISPLAY_DROP_RE, seg).forEach(function (m) {
      for (var i = m.index; i < m.index + m[0].length; i++) drop[i] = true;
      if (m[1] === undefined) return;
      var name = m[1].toLowerCase();
      var opener = null;
      R.findAll(DISPLAY_OPEN_RE, seg.substring(0, m.index)).forEach(function (o) {
        if (o[1].toLowerCase() === name) opener = o;
      });
      if (opener) for (var j = opener.index; j < opener.index + opener[0].length; j++) drop[j] = true;
    });
    return [
      keepUndropped(text, drop, start, start, trigStart),
      keepUndropped(text, drop, start, trigStart, trigEnd),
      keepUndropped(text, drop, start, trigEnd, Math.max(trigEnd, end)),
    ];
  }

  function catOf(msg) {
    return msg === MSG_FINAL ? 'final' : msg === MSG_MULTI ? 'multi' : msg === MSG_HANGING ? 'hanging' : 'verse';
  }

  function report(run, ch, text, processed, reported, m, msg, cat) {
    var start = m.index;
    var end = m.index + m[0].length;
    if (reported.has(start)) return;
    reported.add(start);
    // Patterns end on the space after \v: take in the verse number.
    var take = Math.min(6, text.length - end);
    var vm = R.matchAt(DIGITS_RE, text.substring(end, end + take), 0);
    var ext = vm ? vm[0].length : 0;
    var f = run.emit(ch, start, end + ext, msg, cat);
    f.localize = function (L) {
      return L.str('Msg_qerrors_' + cat);
    };

    // _ReorderOutput: text beginning "\q \v N" was reported at the previous verse; use N.
    var shown = f.text.replace(/\r/g, '').replace(/\n/g, ' ');
    var qv = R.matchAt(Q_VERSE_RE, shown, 0);
    if (qv && /^[0-9]+$/.test(f.verse)) f.verse = qv[1];
    var ref = f.bookCode + ' ' + f.chapter + ':' + f.verse;

    var trigStart = m.indices[1][0];
    var trigEnd = m.indices[1][1];
    var te = trigEnd === end ? trigEnd + ext : trigEnd;
    var parts = displayParts(text, start, trigStart, te, lineEnd(processed, start));
    var trig = parts[1];
    run.state.rows.push({
      ref: ref,
      linkRef: f.bookCode + ' ' + f.chapter + ':' + f.verse,
      msg: msg,
      before: esc(collapseWs(parts[0])),
      period: msg === MSG_FINAL && trig === '.',
      trigger: esc(collapseWs(trig)),
      after: esc(collapseWs(parts[2])),
    });
    f.context = collapseWs(parts[0] + parts[1] + parts[2]);
  }

  function lineHtml(r, err, errPeriod) {
    return r.before + '<span class="' + (r.period ? err + ' ' + errPeriod : err) + '">' + r.trigger + '</span>' + r.after;
  }

  function grouped(d) {
    var byMsg = new Map();
    d.rows.forEach(function (r) {
      if (!byMsg.has(r.msg)) byMsg.set(r.msg, []);
      byMsg.get(r.msg).push(r);
    });
    return MSG_ORDER.filter(function (m) {
      return byMsg.has(m);
    }).map(function (m) {
      return [m, byMsg.get(m)];
    });
  }

  /** Compiled with the 'd' flag, so match.indices gives group 1's place. */
  function compileD(p, flags) {
    var re = R.compile(p, flags);
    var d = new RegExp(re.source, re.flags + 'd');
    d.pySource = p;
    return d;
  }

  PC.define({
    id: 'qerrors',
    cssPrefix: 'qe',
    original: 'q_errors/q_error.py',
    kind: 'report',
    options: [
      { name: 'FinalPunctuation', type: 'text', def: '.!?' },
      { name: 'MinCharsBeforePunct', type: 'int', def: '0' },
      { name: 'NonFinalPunctuation', type: 'text', def: ',;:' },
      { name: 'CheckFinalPunct', type: 'bool', def: 'Yes' },
      { name: 'CheckDoubleVerse', type: 'bool', def: 'Yes' },
      { name: 'CheckTextBeforeVerse', type: 'bool', def: 'Yes' },
      { name: 'CheckHangingWord', type: 'bool', def: 'No' },
    ],
    reportCss: '.qe-err{color:#c00;font-weight:bold}.qe-err-period{font-size:calc(1em + 2pt)}',

    beginRun: function (run) {
      var s = (run.state = { rows: [], compiled: false });
      var final = run.opt('FinalPunctuation');
      var nonFinal = run.opt('NonFinalPunctuation');
      var checkFinal = T.isYes(run.opt('CheckFinalPunct'));
      var checkDouble = T.isYes(run.opt('CheckDoubleVerse'));
      var checkBefore = T.isYes(run.opt('CheckTextBeforeVerse'));
      var checkHanging = T.isYes(run.opt('CheckHangingWord'));
      if (checkFinal && final.length === 0) {
        run.addNote('Rpt_qerrors_EmptyFinal');
        return;
      }
      if (checkHanging && nonFinal.length === 0) {
        run.addNote('Rpt_qerrors_EmptyNonFinal');
        return;
      }
      var mc = T.strip(run.opt('MinCharsBeforePunct'));
      var minChars = /^[+-]?\d+$/.test(mc) ? parseInt(mc, 10) : 0;
      if (minChars < 0) minChars = 0;

      // [ \t\r\n]+: the poetry marker may stand on its own line (\q3 and deeper count too).
      var q = '\\\\q\\d?[ \\t\\r\\n]+';
      var eol = '[ \\t]*\\r?\\n[ \\t]*';
      var beforePunct = '[^\\r\\n]{' + minChars + ',}?';
      var f = R.UNICODE | R.MULTILINE;
      if (checkFinal) {
        var punct = makeCharClass(final);
        s.p1a = compileD(q + beforePunct + '(' + punct + ')' + '(?=[^\\r\\n]*\\w)', f);
        s.p1b = compileD(q + beforePunct + punct + eol + '(' + '\\\\v\\s' + ')', f);
      }
      if (checkDouble) {
        s.p2a = compileD(q + '[^\\r\\n]*\\\\v\\s+\\d+[^\\r\\n]*(' + '\\\\v\\s' + ')', f);
        s.p2b = compileD(q + '[^\\r\\n]*\\\\v\\s+\\d+[^\\r\\n]*' + eol + '(' + '\\\\v\\s' + ')', f);
      }
      if (checkBefore) s.p3 = compileD(q + '(' + '[ \\t]*[^ \\t\\r\\n\\\\][^\\r\\n]*(?:\\r?\\n[ \\t]*)?' + ')' + '\\\\v\\s', f);
      if (checkHanging)
        s.p4 = compileD(q + '[^\\r\\n]*(' + makeCharClass(nonFinal) + '[ \\t]+\\w+' + ')' + '[ \\t]*(?=\\r?$|\\\\q)', f);
      s.compiled = true;
    },

    checkChapter: function (run, ch) {
      var s = run.state;
      if (!s.compiled) return;
      var text = ch.text;
      var processed = U.blank(INLINE_RE, text);
      var reported = new Set();
      function each(re, src, msg, cat) {
        if (!re) return;
        R.findAll(re, src).forEach(function (m) {
          report(run, ch, text, processed, reported, m, msg, cat);
        });
      }
      each(s.p1a, processed, MSG_FINAL, 'final');
      each(s.p1b, processed, MSG_VERSE, 'verse');
      // Approved fix: the later patterns also run on the blanked text (offsets are the same).
      each(s.p2a, processed, MSG_MULTI, 'multi');
      each(s.p2b, processed, MSG_VERSE, 'verse');
      each(s.p3, processed, MSG_VERSE, 'verse');
      each(s.p4, processed, MSG_HANGING, 'hanging');
    },

    endRun: function (run) {
      run.result.reportData = run.state;
    },

    renderReport: function (w, result, L) {
      var d = result.reportData;
      if (!d || !d.compiled) return;
      if (d.rows.length === 0) {
        w.line('<p><i>' + esc(L.str('Rpt_nested_NoIssues')) + '</i></p>');
        return;
      }
      grouped(d).forEach(function (g) {
        w.line('<details class="pc-group" open><summary>' + esc(L.str('Msg_qerrors_' + catOf(g[0]))) + ' (' + g[1].length + ')</summary>');
        w.line('<table><tr><th>' + esc(L.str('Rpt_Reference')) + '</th><th>' + esc(L.str('Rpt_qerrors_QLine')) + '</th></tr>');
        g[1].forEach(function (r) {
          w.line('<tr><td><b>' + PC.report.refLink(r.linkRef, esc(r.ref)) + '</b></td><td>' + lineHtml(r, 'qe-err', 'qe-err-period') + '</td></tr>');
        });
        w.line('</table></details>');
      });
    },

    diffData: function (result) {
      var d = result.reportData;
      if (!d || !d.compiled) return null;
      var rows = [];
      grouped(d).forEach(function (g) {
        g[1].forEach(function (r) {
          rows.push([g[0] + ' (' + g[1].length + ')', esc(r.ref), lineHtml(r, 'err', 'err-period')]);
        });
      });
      return { rows: rows };
    },
  });

})();

// Find Footnotes: a port of Project_Checker\ProjectChecker\Checks\FootnotesCheck.cs
// (CMS/find_footnotes/find_footnotes.py). Lists every footnote with its reference, caller, \fr and
// text in the stylesheet's formatting, plus every sub-marker token seen and its style.
(function () {
  'use strict';
  var R = PC.re;
  var T = PC.text;
  var FN = PC.footnotes;
  var esc = PC.report.esc;
  var EM_DASH = '\u2014';

  var CHAPTER_RE = R.compile('\\\\c\\s+(\\d+)', R.UNICODE);
  var VERSE_RE = R.compile('\\\\v\\s+(\\d+(?:[,-]\\d+)*)\\s*', R.UNICODE);
  var WS_RUN_RE = R.compile('[ \\t]+', R.UNICODE);

  function yes(v) {
    return T.lower(T.strip(v || '')) === 'yes';
  }

  function collapseWs(s) {
    return R.sub(WS_RUN_RE, s.replace(/\r/g, '').replace(/\n/g, ' '), ' ');
  }

  var ORIGINAL = {
    yes: 'yes',
    notInSty: 'not in stylesheet',
    bold: 'Bold',
    italic: 'Italic',
    superscript: 'Superscript',
    smallCaps: 'SmallCaps',
    underline: 'Underline',
    sample: 'Sample text',
    tag: 'tag',
    swatch: 'swatch',
    indent: 'indent',
  };

  function localized(L) {
    return {
      yes: L.str('Rpt_footnotes_Yes'),
      notInSty: L.str('Rpt_footnotes_NotInSty'),
      bold: L.str('Rpt_footnotes_Bold'),
      italic: L.str('Rpt_footnotes_Italic'),
      superscript: L.str('Rpt_footnotes_Superscript'),
      smallCaps: L.str('Rpt_footnotes_SmallCaps'),
      underline: L.str('Rpt_footnotes_Underline'),
      sample: L.str('Rpt_footnotes_Sample'),
      tag: 'fn-tag',
      swatch: 'fn-swatch',
      indent: 'fn-indent',
    };
  }

  function sortedMarkers(d) {
    return Array.from(d.markerCounts.keys()).sort(T.compare);
  }

  /** _marker_row_html */
  function markerRow(d, marker, l) {
    var fields = d.sty.get(FN.styleKey(marker)) || new Map();
    var css = PC.sty.markerCss(fields);
    var flags = [];
    if (PC.sty.flagOn(fields, 'bold')) flags.push(l.bold);
    if (PC.sty.flagOn(fields, 'italic')) flags.push(l.italic);
    if (PC.sty.flagOn(fields, 'superscript')) flags.push(l.superscript);
    if (PC.sty.flagOn(fields, 'smallcaps')) flags.push(l.smallCaps);
    if (PC.sty.flagOn(fields, 'underline')) flags.push(l.underline);
    var flagsStr = flags.length > 0 ? flags.join(', ') : EM_DASH;
    var cssColor = fields.get('colorcss') || (fields.get('color') ? PC.sty.colorCss(fields.get('color')) : null);
    var swatch = cssColor ? '<span class="' + l.swatch + '" style="background:' + cssColor + '"></span>' : '';
    var styletype = fields.get('styletype') || EM_DASH;
    var sample = '<span' + (css.length > 0 ? ' style="' + css + '"' : '') + '>' + l.sample + '</span>';
    var found = fields.size > 0 ? l.yes : l.notInSty;
    return (
      '<tr><td>\\' + esc(marker) + '</td><td>' + (d.markerCounts.get(marker) || 0) + '</td><td>' + esc(found) + '</td><td>' + swatch +
      '</td><td>' + esc(styletype) + '</td><td>' + esc(flagsStr) + '</td><td>' + sample + '</td></tr>'
    );
  }

  /** _render_segments */
  function renderSegments(d, segments, l) {
    var out = '';
    segments.forEach(function (seg) {
      var marker = seg.marker;
      if (seg.kind === 'close') {
        if (!d.hideMarkers) out += '<span class="' + l.tag + '">' + esc(marker) + '</span>';
        return;
      }
      // \fp starts a new paragraph in the note: shown even when markers are hidden.
      if (marker === 'fp') out += '<br><span class="' + l.indent + '"></span>';
      var text = esc(collapseWs(seg.text));
      if (T.strip(text).length === 0) return;
      var css = PC.sty.markerCss(d.sty.get(FN.styleKey(marker)));
      var style = css.length > 0 ? ' style="' + css + '"' : '';
      var tag = d.hideMarkers ? '' : '<span class="' + l.tag + '">' + esc(marker) + '</span>';
      out += tag + '<span' + style + '>' + text + '</span>';
    });
    return out;
  }

  function ordered(d) {
    if (!d.sortAlpha) return d.occurrences.slice();
    return d.occurrences
      .map(function (o, i) {
        return { o: o, i: i };
      })
      .sort(function (a, b) {
        var c = T.compare(a.o.sortKey, b.o.sortKey);
        if (c !== 0) return c;
        c = T.compare(a.o.ref, b.o.ref);
        return c !== 0 ? c : a.i - b.i;
      })
      .map(function (x) {
        return x.o;
      });
  }

  function occurrenceRow(d, o, l, callerClass, link) {
    var frCss = PC.sty.markerCss(d.sty.get('fr'));
    var frStyle = frCss.length > 0 ? ' style="' + frCss + '"' : '';
    var callerCell = o.caller.length > 0 ? esc(o.caller) : '';
    var frCell = o.frText.length > 0 ? '<span' + frStyle + '>' + esc(o.frText) + '</span>' : '';
    var ref = link ? PC.report.refLink(o.linkRef, esc(o.ref)) : esc(o.ref);
    return (
      '<tr><td><b>' + ref + '</b></td><td class="' + callerClass + '">' + callerCell + '</td><td>' + frCell + '</td><td>' +
      renderSegments(d, o.rest, l) + '</td></tr>'
    );
  }

  PC.define({
    id: 'footnotes',
    cssPrefix: 'fn',
    original: 'find_footnotes/find_footnotes.py',
    kind: 'report',
    options: [
      { name: 'SortAlphabetically', type: 'bool', def: 'No' },
      { name: 'HideMarkers', type: 'bool', def: 'No' },
    ],
    reportCss:
      '.fn-tag{display:inline-block;font-size:10px;font-family:monospace;color:#666;background:#eee;' +
      'border:1px solid #ccc;border-radius:3px;padding:0 3px;margin:0 3px 0 8px;vertical-align:middle}' +
      '.fn-swatch{display:inline-block;width:12px;height:12px;border:1px solid #888;vertical-align:middle;margin-right:4px}' +
      '.fn-caller{color:#888;font-family:monospace}.fn-indent{display:inline-block;width:2ch}',

    beginRun: function (run) {
      run.state = {
        sortAlpha: yes(run.opt('SortAlphabetically')),
        hideMarkers: yes(run.opt('HideMarkers')),
        sty: run.sty,
        markerCounts: new Map(),
        occurrences: [],
        total: 0,
      };
    },

    checkChapter: function (run, ch) {
      var d = run.state;
      var bookLabel = ch.bookNum >= 1 && ch.bookNum <= 66 ? ch.bookCode : 'Book ' + ch.bookNum;
      var cm = R.search(CHAPTER_RE, ch.text, 0);
      var chapterLabel = cm ? cm[1] : '?';
      var verses = R.findAll(VERSE_RE, ch.text).map(function (vm) {
        return [vm.index + vm[0].length, vm[1]];
      });

      R.findAll(FN.FOOTNOTE_RE, ch.text).forEach(function (m) {
        d.total++;
        var content = m[1];
        var segments = FN.tokenizeWithCloses(content);
        // Every marker token as written: \w, \w*, \+w and \+w* are separate rows.
        R.findAll(FN.SUBMARKER_RE, content).forEach(function (t) {
          var display = t[0].substring(1);
          d.markerCounts.set(display, (d.markerCounts.get(display) || 0) + 1);
        });

        var caller = '';
        var fr = '';
        var rest = [];
        segments.forEach(function (seg) {
          if (seg.marker === null) caller += seg.text;
          else if (seg.marker === 'fr') fr += seg.text;
          else rest.push(seg);
        });
        var restText = T.strip(
          collapseWs(
            rest
              .filter(function (s) {
                return T.strip(s.text).length > 0;
              })
              .map(function (s) {
                return s.text;
              })
              .join(' '),
          ),
        );

        var distinct = new Set();
        segments.forEach(function (seg) {
          if (seg.marker !== null && seg.kind !== 'close') distinct.add(seg.marker);
        });
        var markers = Array.from(distinct).sort(T.compare).join(' ');
        var f = run.emit(ch, m.index, m.index + m[0].length, distinct.size > 0 ? 'Footnote: ' + markers : 'Footnote', 'footnote');
        f.localize = function (L) {
          return markers.length > 0 ? L.str('Msg_footnotes_Footnote') + ': ' + markers : L.str('Msg_footnotes_Footnote');
        };

        var v = null;
        for (var i = 0; i < verses.length; i++) {
          if (verses[i][0] <= m.index) v = verses[i][1];
          else break;
        }
        d.occurrences.push({
          ref: bookLabel + ' ' + chapterLabel + ':' + (v === null ? '-' : v),
          linkRef: ch.bookCode + ' ' + ch.chapter + ':' + PC.usfm.verseAt(ch.text, m.index),
          caller: T.strip(collapseWs(caller)),
          frText: T.strip(collapseWs(fr)),
          rest: rest,
          sortKey: T.sortFold(restText),
        });
      });
    },

    endRun: function (run) {
      run.result.reportData = run.state;
    },

    renderReport: function (w, result, L) {
      var d = result.reportData;
      if (!d) return;
      var l = localized(L);
      w.line('<h3>' + esc(L.str('Rpt_footnotes_H1')) + '</h3>');
      if (d.markerCounts.size === 0) w.line('<p><i>' + esc(L.str('Rpt_footnotes_None')) + '</i></p>');
      else {
        w.line(
          '<table><tr><th>' + esc(L.str('Rpt_nested_Marker')) + '</th><th>' + esc(L.str('Rpt_footnotes_Count')) + '</th><th>' +
            esc(L.str('Rpt_footnotes_InSty')) + '</th><th>' + esc(L.str('Rpt_footnotes_Color')) + '</th><th>' +
            esc(L.str('Rpt_footnotes_StyleType')) + '</th><th>' + esc(L.str('Rpt_footnotes_Flags')) + '</th><th>' +
            esc(L.str('Rpt_footnotes_SampleCol')) + '</th></tr>',
        );
        sortedMarkers(d).forEach(function (mk) {
          w.line(markerRow(d, mk, l));
        });
        w.line('</table>');
      }
      w.line('<h3>' + esc(L.str('Rpt_footnotes_H2')) + '</h3>');
      if (d.total === 0) {
        w.line('<p><i>' + esc(L.str('Rpt_footnotes_None')) + '</i></p>');
        return;
      }
      var sortLabel = L.str(d.sortAlpha ? 'Rpt_footnotes_SortText' : 'Rpt_footnotes_SortRef');
      var mode = d.hideMarkers ? ' ' + L.str('Rpt_footnotes_Hidden') : '';
      w.line('<p>' + esc(L.fmt('Rpt_footnotes_Summary', d.total, sortLabel) + mode) + '</p>');
      w.line('<details class="pc-group" open><summary>' + esc(L.str('Rpt_footnotes_H2')) + ' (' + d.total + ')</summary>');
      w.line(
        '<table><tr><th>' + esc(L.str('Rpt_Reference')) + '</th><th>' + esc(L.str('Rpt_footnotes_Caller')) + '</th><th>\\fr</th><th>' +
          esc(L.str('Rpt_nested_FootnoteText')) + '</th></tr>',
      );
      ordered(d).forEach(function (o) {
        w.line(occurrenceRow(d, o, l, 'fn-caller', true));
      });
      w.line('</table></details>');
    },

    diffData: function (result) {
      var d = result.reportData;
      if (!d) return null;
      var r = {
        markers: sortedMarkers(d).map(function (mk) {
          return markerRow(d, mk, ORIGINAL);
        }),
        rows: ordered(d).map(function (o) {
          return occurrenceRow(d, o, ORIGINAL, 'caller', false);
        }),
      };
      if (d.total > 0)
        r.summary =
          d.total + ' footnote(s) found, sorted by ' + (d.sortAlpha ? 'footnote text (alphabetically)' : 'canonical reference') + '.' +
          (d.hideMarkers ? ' Markers are hidden.' : '');
      return r;
    },
  });
})();

const PCX_VERSION = "0.3.2";
const PCX_WEB_VIEW_HTML = "<!doctype html>\n<html>\n  <head>\n    <meta charset=\"utf-8\" />\n    <style>\n      :root {\n        --pc-bg: #ffffff;\n        --pc-fg: #1f2328;\n        --pc-muted: #59636e;\n        --pc-line: #d0d7de;\n        --pc-head: #f3f5f7;\n        --pc-sel: #dbeafe;\n        --pc-accent: #0b6bcb;\n        --pc-warn: #9a3412;\n      }\n      @media (prefers-color-scheme: dark) {\n        :root {\n          --pc-bg: #1e1f22;\n          --pc-fg: #e6e6e6;\n          --pc-muted: #a0a6ad;\n          --pc-line: #3a3d42;\n          --pc-head: #2a2c30;\n          --pc-sel: #1e3a5f;\n          --pc-accent: #6cb6ff;\n          --pc-warn: #fdba74;\n        }\n      }\n      html,\n      body {\n        margin: 0;\n        height: 100%;\n        background: var(--pc-bg);\n        color: var(--pc-fg);\n        font: 13px/1.4 'Segoe UI', system-ui, sans-serif;\n      }\n      body {\n        display: flex;\n        gap: 10px;\n        padding: 8px 12px;\n        box-sizing: border-box;\n      }\n      #left {\n        width: 260px;\n        flex: none;\n        display: flex;\n        flex-direction: column;\n        gap: 6px;\n      }\n      #right {\n        flex: 1;\n        min-width: 0;\n        display: flex;\n        flex-direction: column;\n        gap: 6px;\n      }\n      #list {\n        flex: 1;\n        overflow: auto;\n        border: 1px solid var(--pc-line);\n        border-radius: 4px;\n      }\n      .item {\n        padding: 5px 8px;\n        cursor: pointer;\n        border-bottom: 1px solid var(--pc-line);\n      }\n      .item.sel {\n        background: var(--pc-sel);\n      }\n      .item .kind {\n        color: var(--pc-muted);\n        font-size: 11px;\n      }\n      h1 {\n        font-size: 15px;\n        margin: 0;\n      }\n      #desc {\n        color: var(--pc-muted);\n      }\n      #opts {\n        display: grid;\n        grid-template-columns: max-content 1fr;\n        gap: 4px 10px;\n        align-items: center;\n      }\n      #opts label {\n        font-weight: 600;\n      }\n      select,\n      input[type='text'],\n      input[type='number'] {\n        font: inherit;\n        background: var(--pc-bg);\n        color: var(--pc-fg);\n        border: 1px solid var(--pc-line);\n        border-radius: 3px;\n        padding: 2px 4px;\n      }\n      input[type='text'] {\n        width: 100%;\n        box-sizing: border-box;\n      }\n      button {\n        font: inherit;\n        padding: 3px 12px;\n        border: 1px solid var(--pc-line);\n        background: var(--pc-head);\n        color: var(--pc-fg);\n        border-radius: 4px;\n        cursor: pointer;\n      }\n      button.primary {\n        background: var(--pc-accent);\n        border-color: var(--pc-accent);\n        color: #fff;\n        font-weight: 600;\n      }\n      button:disabled {\n        opacity: 0.5;\n        cursor: default;\n      }\n      .row {\n        display: flex;\n        gap: 8px;\n        align-items: center;\n        flex-wrap: wrap;\n      }\n      .spinner {\n        display: inline-block;\n        width: 12px;\n        height: 12px;\n        border: 2px solid var(--pc-line);\n        border-top-color: var(--pc-accent);\n        border-radius: 50%;\n        animation: spin 0.8s linear infinite;\n        vertical-align: -2px;\n        margin-right: 6px;\n      }\n      @keyframes spin {\n        to {\n          transform: rotate(360deg);\n        }\n      }\n      #busy {\n        display: none;\n        flex-direction: column;\n        align-items: center;\n        justify-content: center;\n        gap: 12px;\n        padding: 40px 20px;\n        color: #333;\n        font-size: 14px;\n      }\n      #busy .spinner {\n        width: 32px;\n        height: 32px;\n        border-width: 4px;\n        margin: 0;\n      }\n      #busy .track {\n        width: 60%;\n        max-width: 420px;\n        height: 8px;\n        background: #e5e7eb;\n        border-radius: 4px;\n        overflow: hidden;\n      }\n      #busy .track > div {\n        height: 100%;\n        width: 0;\n        background: #0b6bcb;\n        transition: width 0.2s;\n      }\n      #bar {\n        height: 4px;\n        background: var(--pc-head);\n        border-radius: 2px;\n        overflow: hidden;\n        display: none;\n      }\n      #bar > div {\n        height: 100%;\n        width: 0;\n        background: var(--pc-accent);\n        transition: width 0.2s;\n      }\n      #status {\n        color: var(--pc-muted);\n      }\n      #status.err {\n        color: var(--pc-warn);\n        font-weight: 600;\n      }\n      #out {\n        flex: 1;\n        overflow: auto;\n        border: 1px solid var(--pc-line);\n        border-radius: 4px;\n        background: #fff;\n      }\n      .pc-report {\n        padding: 8px 12px;\n      }\n      .muted {\n        color: var(--pc-muted);\n        font-size: 11px;\n      }\n    </style>\n  </head>\n  <body>\n    <div id=\"left\">\n      <div id=\"checksLabel\" style=\"font-weight: 600\"></div>\n      <div id=\"list\"><div class=\"item\" id=\"loading\"><span class=\"spinner\"></span><span>Loading...</span></div></div>\n      <div class=\"muted\" id=\"version\"></div>\n    </div>\n    <div id=\"right\">\n      <h1 id=\"name\"></h1>\n      <div id=\"desc\"></div>\n      <div id=\"opts\"></div>\n      <div class=\"row\">\n        <button class=\"primary\" id=\"run\"></button>\n        <button class=\"primary\" id=\"open\" style=\"display: none\"></button>\n        <button id=\"defaults\"></button>\n        <label><input type=\"checkbox\" id=\"otherBooks\" /> <span id=\"otherBooksLabel\"></span></label>\n        <span id=\"status\"></span>\n      </div>\n      <div id=\"bar\"><div></div></div>\n      <div id=\"out\">\n        <div id=\"busy\"><span class=\"spinner\"></span><div id=\"busyText\"></div><div class=\"track\"><div id=\"busyBar\"></div></div></div>\n        <div id=\"report\"></div>\n      </div>\n    </div>\n    <script>\n      const BOOT = __PCX_BOOT__;\n      const papi = require('@papi/frontend');\n\n      const STR = {\n        en: {\n          checks: 'Checks',\n          loading: 'Loading the list of checks...',\n          opening: 'Opening the project...',\n          reading: 'Reading {0} ({1} of {2})...',\n          checking: 'Running {0}...',\n          building: 'Preparing the report...',\n          showing: 'Showing the report...',\n          open: 'Open {0}...',\n          opensWindow: '{0} opens in its own window, where it scans the project.',\n          otherBooks: 'Include non-Bible books (FRT, BAK, OTH, XXA...)',\n          report: 'Report',\n          run: 'Run',\n          defaults: 'Restore defaults',\n          yes: 'Yes',\n          no: 'No',\n          running: 'Running {0}...',\n          done: '{0} result(s) in {1} book(s).',\n          failed: 'The check failed: {0}',\n          notRead: 'Not read: {0}',\n          noOptions: 'This check has no options.',\n          notWhole: '{0} must be a whole number.',\n        },\n        es: {\n          checks: 'Verificaciones',\n          loading: 'Cargando la lista de verificaciones...',\n          opening: 'Abriendo el proyecto...',\n          reading: 'Leyendo {0} ({1} de {2})...',\n          checking: 'Ejecutando {0}...',\n          building: 'Preparando el informe...',\n          showing: 'Mostrando el informe...',\n          open: 'Abrir {0}...',\n          opensWindow: '{0} se abre en su propia ventana, donde examina el proyecto.',\n          otherBooks: 'Incluir los libros que no son de la Biblia (FRT, BAK, OTH, XXA...)',\n          report: 'Informe',\n          run: 'Ejecutar',\n          defaults: 'Restaurar valores predeterminados',\n          yes: 'S\u00ed',\n          no: 'No',\n          running: 'Ejecutando {0}...',\n          done: '{0} resultado(s) en {1} libro(s).',\n          failed: 'La verificaci\u00f3n fall\u00f3: {0}',\n          notRead: 'No se ley\u00f3: {0}',\n          noOptions: 'Esta verificaci\u00f3n no tiene opciones.',\n          notWhole: '{0} debe ser un n\u00famero entero.',\n        },\n        fr: {\n          checks: 'V\u00e9rifications',\n          loading: 'Chargement de la liste des v\u00e9rifications...',\n          opening: 'Ouverture du projet...',\n          reading: 'Lecture de {0} ({1} sur {2})...',\n          checking: 'Ex\u00e9cution de {0}...',\n          building: 'Pr\u00e9paration du rapport...',\n          showing: 'Affichage du rapport...',\n          open: 'Ouvrir {0}...',\n          opensWindow: '{0} s\u2019ouvre dans sa propre fen\u00eatre, o\u00f9 il examine le projet.',\n          otherBooks: 'Inclure les livres hors Bible (FRT, BAK, OTH, XXA...)',\n          report: 'Rapport',\n          run: 'Lancer',\n          defaults: 'R\u00e9tablir les valeurs par d\u00e9faut',\n          yes: 'Oui',\n          no: 'Non',\n          running: 'Ex\u00e9cution de {0}...',\n          done: '{0} r\u00e9sultat(s) dans {1} livre(s).',\n          failed: 'La v\u00e9rification a \u00e9chou\u00e9 : {0}',\n          notRead: 'Non lu : {0}',\n          noOptions: 'Cette v\u00e9rification n\u2019a pas d\u2019options.',\n          notWhole: '{0} doit \u00eatre un nombre entier.',\n        },\n      };\n      const S = STR[BOOT.lang] || STR.en;\n      const KIND = {\n        en: { report: 'Report', changes: 'Changes text' },\n        es: { report: 'Informe', changes: 'Cambia el texto' },\n        fr: { report: 'Rapport', changes: 'Modifie le texte' },\n      }[BOOT.lang] || { report: 'Report', changes: 'Changes text' };\n\n      let checks = [];\n      let current = null;\n      let busy = false;\n      const $ = (id) => document.getElementById(id);\n\n      function fmt(s, ...args) {\n        return s.replace(/\\{(\\d+)\\}/g, (m, n) => (args[n] === undefined ? m : String(args[n])));\n      }\n\n      /** The status line; working = with the spinner. */\n      function status(text, isError, working) {\n        const el = $('status');\n        el.textContent = '';\n        if (working) {\n          const sp = document.createElement('span');\n          sp.className = 'spinner';\n          el.appendChild(sp);\n        }\n        el.appendChild(document.createTextNode(text || ''));\n        el.className = isError ? 'err' : '';\n        $('busy').style.display = working ? 'flex' : 'none';\n        $('report').style.display = working ? 'none' : '';\n        if (working) $('busyText').textContent = text || '';\n      }\n\n      /** The progress bar: fraction 0..1, or null to hide it. */\n      function bar(fraction) {\n        $('bar').style.display = fraction === null ? 'none' : 'block';\n        const w = Math.round(Math.max(0, Math.min(1, fraction || 0)) * 100) + '%';\n        $('bar').firstElementChild.style.width = w;\n        $('busyBar').style.width = w;\n        $('busyBar').parentElement.style.visibility = fraction === null ? 'hidden' : 'visible';\n      }\n\n      function showProgress(p) {\n        if (!p || p.runId !== runId || !busy) return;\n        if (p.phase === 'open') status(S.opening, false, true);\n        else if (p.phase === 'read') status(fmt(S.reading, p.book, p.done + 1, p.total), false, true);\n        else if (p.phase === 'check') status(fmt(S.checking, current ? current.name : ''), false, true);\n        else if (p.phase === 'report') status(S.building, false, true);\n        if (p.total > 0) bar(p.phase === 'read' ? (p.done / p.total) * 0.9 : p.phase === 'open' ? 0 : 0.95);\n      }\n\n      // Progress sent by the backend while a check runs (book by book).\n      let runId = null;\n      try {\n        const onProgress = papi.network.getNetworkEvent('philsChecks.onProgress');\n        onProgress(showProgress);\n      } catch (e) {\n        // no progress events: the spinner alone shows that it is working\n      }\n\n      function drawList() {\n        const list = $('list');\n        list.textContent = '';\n        checks.forEach((c) => {\n          const div = document.createElement('div');\n          div.className = 'item' + (current && current.id === c.id ? ' sel' : '');\n          const name = document.createElement('div');\n          name.textContent = c.name;\n          const kind = document.createElement('div');\n          kind.className = 'kind';\n          kind.textContent = KIND[c.kind] || c.kind;\n          div.append(name, kind);\n          div.addEventListener('click', () => select(c.id));\n          div.addEventListener('dblclick', () => run());\n          list.appendChild(div);\n        });\n      }\n\n      function drawOptions(values) {\n        const box = $('opts');\n        box.textContent = '';\n        if (current.options.length === 0) {\n          const p = document.createElement('div');\n          p.className = 'muted';\n          p.textContent = S.noOptions;\n          box.appendChild(p);\n          return;\n        }\n        current.options.forEach((o) => {\n          const label = document.createElement('label');\n          label.textContent = o.label;\n          label.title = o.tip;\n          label.htmlFor = 'opt_' + o.name;\n          let input;\n          if (o.type === 'bool') {\n            input = document.createElement('select');\n            [\n              ['Yes', S.yes],\n              ['No', S.no],\n            ].forEach(([v, t]) => {\n              const op = document.createElement('option');\n              op.value = v;\n              op.textContent = t;\n              input.appendChild(op);\n            });\n            input.value = String(values[o.name]).trim().toLowerCase() === 'yes' ? 'Yes' : 'No';\n          } else {\n            input = document.createElement('input');\n            input.type = o.type === 'int' ? 'number' : 'text';\n            input.value = values[o.name];\n          }\n          input.id = 'opt_' + o.name;\n          input.title = o.tip;\n          box.append(label, input);\n        });\n      }\n\n      function readOptions() {\n        const o = {};\n        for (const d of current.options) {\n          const v = $('opt_' + d.name).value;\n          if (d.type === 'int' && !/^\\s*[+-]?\\d+\\s*$/.test(v)) throw new Error(fmt(S.notWhole, d.label));\n          o[d.name] = v;\n        }\n        return o;\n      }\n\n      async function select(id) {\n        current = checks.find((c) => c.id === id);\n        drawList();\n        $('name').textContent = current.name;\n        $('desc').textContent = current.description;\n        $('report').textContent = '';\n        status('');\n        bar(null);\n        const opens = !!current.opens;\n        $('run').style.display = opens ? 'none' : '';\n        $('defaults').style.display = opens ? 'none' : '';\n        $('otherBooks').parentElement.style.display = opens ? 'none' : '';\n        $('open').style.display = opens ? '' : 'none';\n        if (opens) {\n          $('open').textContent = fmt(S.open, current.name);\n          $('opts').textContent = '';\n          const p = document.createElement('div');\n          p.className = 'muted';\n          p.textContent = fmt(S.opensWindow, current.name);\n          $('opts').appendChild(p);\n          return;\n        }\n        let values = {};\n        try {\n          values = await papi.commands.sendCommand('philsChecks.loadOptions', BOOT.projectId, id);\n        } catch (e) {\n          current.options.forEach((o) => (values[o.name] = o.def));\n        }\n        drawOptions(values);\n      }\n\n      function showReport(res) {\n        const out = $('report');\n        out.textContent = '';\n        const style = document.createElement('style');\n        style.textContent = res.css;\n        const div = document.createElement('div');\n        div.className = 'pc-report';\n        // The report is built by the extension from escaped project text.\n        div.innerHTML = res.html;\n        out.append(style, div);\n      }\n\n      async function run() {\n        if (!current || busy) return;\n        if (current.opens) {\n          openOther();\n          return;\n        }\n        let options;\n        try {\n          options = readOptions();\n        } catch (e) {\n          status(e.message, true);\n          return;\n        }\n        busy = true;\n        $('run').disabled = true;\n        $('list').style.pointerEvents = 'none';\n        runId = String(Date.now()) + Math.random();\n        status(fmt(S.running, current.name), false, true);\n        bar(0);\n        $('report').textContent = '';\n        const myRun = runId;\n        const poll = setInterval(() => {\n          papi.commands\n            .sendCommand('philsChecks.progress', BOOT.projectId, myRun)\n            .then(showProgress)\n            .catch(() => {});\n        }, 250);\n        try {\n          const res = await papi.commands.sendCommand('philsChecks.run', BOOT.projectId, current.id, options, BOOT.lang, {\n            otherBooks: $('otherBooks').checked,\n            runId,\n          });\n          status(S.showing, false, true);\n          bar(1);\n          // Let the window paint the status before a big report is laid out.\n          await new Promise((r) => setTimeout(r, 30));\n          showReport(res);\n          let text = fmt(S.done, res.count, res.booksRead.length);\n          if (res.failed.length > 0) text += ' ' + fmt(S.notRead, res.failed.join('; '));\n          status(text, res.failed.length > 0);\n        } catch (e) {\n          status(fmt(S.failed, e && e.message ? e.message : e), true);\n        } finally {\n          clearInterval(poll);\n          busy = false;\n          runId = null;\n          bar(null);\n          $('run').disabled = false;\n          $('list').style.pointerEvents = '';\n        }\n      }\n\n      $('out').addEventListener('click', (ev) => {\n        const a = ev.target.closest ? ev.target.closest('a.pc-go') : null;\n        if (!a) return;\n        ev.preventDefault();\n        papi.commands.sendCommand('philsChecks.goTo', BOOT.projectId, a.getAttribute('data-ref')).catch((e) => status(String(e), true));\n      });\n\n      function openOther() {\n        papi.commands.sendCommand(current.opens, undefined, BOOT.projectId).catch((e) => status(String(e), true));\n      }\n\n      $('run').addEventListener('click', run);\n      $('open').addEventListener('click', openOther);\n      $('defaults').addEventListener('click', () => {\n        if (!current) return;\n        const values = {};\n        current.options.forEach((o) => (values[o.name] = o.def));\n        drawOptions(values);\n      });\n\n      async function start() {\n        $('checksLabel').textContent = S.checks;\n        $('run').textContent = S.run;\n        $('defaults').textContent = S.defaults;\n        $('otherBooksLabel').textContent = S.otherBooks;\n        $('otherBooks').checked = !!BOOT.otherBooks;\n        $('version').textContent = (BOOT.projectName ? BOOT.projectName + ' \u00b7 ' : '') + BOOT.version;\n        $('loading').lastChild.textContent = S.loading;\n        status(S.loading, false, true);\n        bar(null);\n        if (!BOOT.projectName)\n          papi.commands\n            .sendCommand('philsChecks.projectName', BOOT.projectId)\n            .then((n) => {\n              if (n) $('version').textContent = n + ' \\u00b7 ' + BOOT.version;\n            })\n            .catch(() => {});\n        try {\n          checks = await papi.commands.sendCommand('philsChecks.list', BOOT.lang);\n        } catch (e) {\n          status(String(e), true);\n          return;\n        }\n        status('');\n        drawList();\n        if (checks.length > 0) select(checks[0].id);\n      }\n      start();\n    </script>\n  </body>\n</html>\n";
const PCX_USFM_STY = "# Version=3.0.11\n# ********************************************************************\n# * usfm.sty is the default stylesheet for Paratext projects         *\n# *   using USFM markup.                                             *\n# * Latest documentation and stylesheets are maintained at:          *\n# *   http://markups.paratext.org/usfm                               *\n# ********************************************************************\n\n# File Identification\n\n\\Marker id\n\\Name id - File - Identification\n\\Description File identification information (BOOKID, FILENAME, EDITOR, MODIFICATION DATE)\n\\StyleType Paragraph\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular book\n\\FontSize 12\n\n\\Marker usfm\n\\Name usfm - File - USFM Version ID\n\\Description File markup version information\n\\OccursUnder id\n\\Rank 1\n\\StyleType Paragraph\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\FontSize 12\n\n\\Marker ide\n\\Name ide - File - Encoding\n\\Description File encoding information\n\\OccursUnder id\n\\Rank 1\n\\StyleType Paragraph\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\FontSize 12\n\n# Headers\n\n\\Marker h\n\\Name h - File - Header\n\\Description Running header text for a book (basic)\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker h1\n\\Name DEPRECATED h1 - File - Header\n\\Description Running header text\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker h2\n\\Name DEPRECATED h2 - File - Left Header\n\\Description Running header text, left side of page\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker h3\n\\Name DEPRECATED h3 - File - Right Header\n\\Description Running header text, right side of page\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker toc1\n\\Name toc1 - File - Long Table of Contents Text\n\\Description Long table of contents text\n\\OccursUnder h h1 h2 h3 id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Bold\n\\Color 16384\n#!\\ColorName highcon green\n\n\\Marker toc2\n\\Name toc2 - File - Short Table of Contents Text\n\\Description Short table of contents text\n\\OccursUnder h h1 h2 h3 id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Color 16384\n#!\\ColorName highcon green\n\n\\Marker toc3\n\\Name toc3 - File - Book Abbreviation\n\\Description Book Abbreviation\n\\OccursUnder h h1 h2 h3 id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Italic\n\\Color 128\n#!\\ColorName lowcon red\n\n\\Marker toca1\n\\Name toca1 - File - Alternative Language Long Table of Contents Text\n\\Description Alternative language long table of contents text\n\\OccursUnder h h1 h2 h3\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 10\n\\Italic\n\\Color 8421504\n#!\\ColorName gray\n\n\\Marker toca2\n\\Name toca2 - File - Alternative Language Short Table of Contents Text\n\\Description Alternative language short table of contents text\n\\OccursUnder h h1 h2 h3\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 10\n\\Italic\n\\Color 8421504\n#!\\ColorName gray\n\n\\Marker toca3\n\\Name toca3 - File - Alternative Language Book Abbreviation\n\\Description Alternative language book Abbreviation\n\\OccursUnder h h1 h2 h3\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 10\n\\Italic\n\\Color 8421504\n#!\\ColorName gray\n\n# Remarks and Comments\n\n\\Marker rem\n\\Name rem - File - Remark\n\\Description Comments and remarks\n\\OccursUnder id ide c\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Color 16711680\n#!\\ColorName highcon blue\n\n\\Marker sts\n\\Name sts - File - Status\n\\Description Status of this file\n\\OccursUnder id ide c\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Color 16711680\n#!\\ColorName highcon blue\n\n\\Marker restore\n\\Name restore - File - Restore Information\n\\Description Project restore information\n\\OccursUnder id\n\\Rank 99\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Color 16711680\n#!\\ColorName highcon blue\n\n# Introduction\n\n\\Marker imt\n\\Name imt - Introduction - Major Title Level 1\n\\Description Introduction major title, level 1 (if single level) (basic)\n\\OccursUnder id\n\\Rank 5\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Other\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker imt1\n\\Name imt1 - Introduction - Major Title Level 1\n\\Description Introduction major title, level 1 (if multiple levels)\n\\OccursUnder id\n\\Rank 5\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Other\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker imt2\n\\Name imt2 - Introduction - Major Title Level 2\n\\Description Introduction major title, level 2\n\\OccursUnder id\n\\Rank 5\n\\TextProperties paragraph publishable vernacular level_2\n\\TextType other\n\\StyleType Paragraph\n\\FontSize 13\n\\Italic\n\\Justification Center\n\\SpaceBefore 6\n\\SpaceAfter 3\n\n\\Marker imt3\n\\Name imt3 - Introduction - Major Title Level 3\n\\Description Introduction major title, level 3\n\\OccursUnder id\n\\Rank 5\n\\TextProperties paragraph publishable vernacular level_3\n\\TextType Other\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceBefore 2\n\\SpaceAfter 2\n\n\\Marker imt4\n\\Name imt4 - Introduction - Major Title Level 4\n\\Description Introduction major title, level 4 (usually within parenthesis)\n\\OccursUnder id\n\\Rank 5\n\\TextProperties paragraph publishable vernacular level_4\n\\TextType Other\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Center\n\\SpaceBefore 2\n\\SpaceAfter 2\n \n\\Marker imte\n\\Name imte - Introduction - [Uncommon] Major Title at Introduction End Level 1\n\\Description Introduction major title at introduction end, level 1 (if single level)\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Other\n\\OccursUnder id\n\\Rank 7\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker imte1\n\\Name imte1 - Introduction - [Uncommon] Major Title at Introduction End Level 1\n\\Description Introduction major title at introduction end, level 1 (if multiple levels)\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Other\n\\OccursUnder id\n\\Rank 7\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker imte2\n\\Name imte2 - Introduction - [Uncommon] Major Title at Introduction End Level 2\n\\Description Introduction major title at introduction end, level 2\n\\TextProperties paragraph publishable vernacular level_2\n\\TextType Other\n\\OccursUnder id\n\\Rank 7\n\\StyleType Paragraph\n\\FontSize 16\n\\Italic\n\\Justification Center\n\\SpaceAfter 2 \n\n\\Marker is\n\\Name is - Introduction - Section Heading Level 1\n\\Description Introduction section heading, level 1 (if single level) (basic)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker is1 \n\\Name is1 - Introduction - Section Heading Level 1\n\\Description Introduction section heading, level 1 (if multiple levels)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker is2\n\\Name is2 - Introduction - Section Heading Level 2\n\\Description Introduction section heading, level 2 \n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker iot \n\\Name iot - Introduction - Outline Title\n\\Description Introduction outline title (basic)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker io\n\\Name io - Introduction - Outline Level 1\n\\Description Introduction outline text, level 1 (if single level)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\n\\Marker io1\n\\Name io1 - Introduction - Outline Level 1\n\\Description Introduction outline text, level 1 (if multiple levels) (basic)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\n\\Marker io2\n\\Name io2 - Introduction - Outline Level 2\n\\Description Introduction outline text, level 2 \n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .75\n\n\\Marker io3\n\\Name io3 - Introduction - Outline Level 3\n\\Description Introduction outline text, level 3 \n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1\n\n\\Marker io4\n\\Name io4 - Introduction - Outline Level 4\n\\Description Introduction outline text, level 4 \n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_4\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1.25\n\n\\Marker ior\n\\Endmarker ior*\n\\Name ior...ior* - Introduction - Outline References Range\n\\Description Introduction references range for outline entry; for marking references separately\n\\OccursUnder id io io1 io2 io3 io4 NEST\n\\TextType Other\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker ip\n\\Name ip - Introduction - Paragraph\n\\Description Introduction prose paragraph (basic)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\n\\Marker im\n\\Name im - Introduction - Paragraph - no first line indent\n\\Description Introduction prose paragraph, with no first line indent (may occur after poetry)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker ipi\n\\Name ipi - Introduction - Indented Para - first line indent\n\\Description Introduction prose paragraph, indented, with first line indent\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker imi\n\\Name imi - Introduction - Indented Para - no first line indent\n\\Description Introduction prose paragraph text, indented, with no first line indent\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker ili\n\\Name ili - Introduction - List Entry - Level 1\n\\Description A list entry, level 1 (if single level)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.375 # 1/8 inch indent, 1/2 inch wrap\n\n\\Marker ili1\n\\Name ili1 - Introduction - List Entry - Level 1\n\\Description A list entry, level 1 (if multiple levels)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.375 # 1/8 inch indent, 1/2 inch wrap\n\n\\Marker ili2\n\\Name ili2 - Introduction - List Entry - Level 2\n\\Description A list entry, level 2\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .75\n\\FirstLineIndent -.375\n\n\\Marker ipq\n\\Name ipq - Introduction - Paragraph - quote from text\n\\Description Introduction prose paragraph, quote from the body text\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\Italic\n\n\\Marker imq\n\\Name imq - Introduction - Paragraph - quote from text - no first line indent\n\\Description Introduction prose paragraph, quote from the body text, with no first line indent\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\\Italic\n\n\\Marker ipr\n\\Name ipr - Introduction - Paragraph - right aligned\n\\Description Introduction prose paragraph, right aligned\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\\Justification Right\n\\Italic\n\n\\Marker ib\n\\Name ib - Introduction - Blank Line\n\\Description Introduction blank line\n\\OccursUnder id\n\\Rank 6\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType Other\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker iq\n\\Name iq - Introduction - Poetry Level 1\n\\Description Introduction poetry text, level 1 (if single level)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular poetic level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.75  # 1/4 inch indent, 1 inch wrap\n\\Italic\n\n\\Marker iq1\n\\Name iq1 - Introduction - Poetry Level 1\n\\Description Introduction poetry text, level 1 (if multiple levels)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular poetic level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.75  # 1/4 inch indent, 1 inch wrap\n\\Italic\n\n\\Marker iq2\n\\Name iq2 - Introduction - Poetry Level 2\n\\Description Introduction poetry text, level 2 \n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular poetic level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.5  # 1/2 inch indent, 1 inch wrap\n\\Italic\n\n\\Marker iq3\n\\Name iq3 - Introduction - Poetry Level 3\n\\Description Introduction poetry text, level 3\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular poetic level_3\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.25 # 3/4 inch indent, 1 inch wrap\n\\Italic\n\n\\Marker iex\n\\Name iex - Introduction - Explanatory or Bridge Text\n\\Description Introduction explanatory or bridge text (e.g. explanation of missing book in Short Old Testament)\n\\OccursUnder id c\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\SpaceBefore 4\n\\SpaceAfter 4\n\n\\Marker iqt\n\\Endmarker iqt*\n\\Name iqt...iqt* - Special Text - Quoted Scripture Text in Introduction\n\\Description For quoted scripture text appearing in the introduction\n\\OccursUnder imt imt1 imt2 imt3 imt4 ib ie ili ili1 ili2 im imi imq io io1 io2 io3 io4 iot ip ipi ipq ipr iq iq1 iq2 iq3 is is1 is2 imte imte1 imte2 iex\n\\TextType Other\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker ie\n\\Name ie - Introduction - End Marker\n\\Description Introduction ending marker\n\\OccursUnder id\n\\Rank 6\n\\TextProperties paragraph publishable vernacular\n\\TextType Other\n\\FontSize 10\n\\StyleType paragraph\n\n# Chapters and Verses\n\n\\Marker c\n\\Name c - Chapter Number\n\\Description Chapter number (necessary for normal Paratext operation)\n\\OccursUnder id\n\\Rank 8\n\\TextType ChapterNumber\n\\TextProperties chapter\n\\StyleType Paragraph\n\\Bold\n\\FontSize 18\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker ca\n\\Endmarker ca*\n\\Name ca...ca* - Chapter Number - Alternate\n\\Description Second (alternate) chapter number (for coding dual versification; useful for places where different traditions of chapter breaks need to be supported in the same translation)\n\\OccursUnder c \n\\TextType Other\n\\StyleType Character\n\\Italic\n\\FontSize 16\n\\Color 2263842\n#!\\ColorName green\n\n\\Marker cp\n\\Name cp - Chapter Number - Publishing Alternate\n\\Description Published chapter number (chapter string that should appear in the published text)\n\\OccursUnder c \n\\Rank 4\n\\TextType Other\n\\TextProperties paragraph\n\\StyleType Paragraph\n\\Bold\n\\FontSize 18\n\\SpaceBefore 8\n\\SpaceAfter 4\n\\Color 16711680\n#!\\ColorName highcon blue\n\n\\Marker cl\n\\Name cl - Chapter - Publishing Label\n\\Description Chapter label used for translations that add a word such as \"Chapter\" before chapter numbers (e.g. Psalms). The subsequent text is the chapter label.\n\\OccursUnder id c ms ms1 ms2 ms3 mr\n\\TextType Other\n\\TextProperties paragraph\n\\StyleType Paragraph\n\\Bold\n\\FontSize 18\n\\SpaceBefore 8\n\\SpaceAfter 4\n\\Justification Center\n\n\\Marker cd\n\\Name cd - Chapter - Description\n\\Description Chapter Description (Publishing option D, e.g. in Russian Bibles)\n\\OccursUnder c\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 11\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker v\n\\Name v - Verse Number\n\\Description A verse number (Necessary for normal paratext operation) (basic)\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 s3 d sp\n\\TextType VerseNumber\n\\TextProperties verse\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\n\\Marker va\n\\Endmarker va*\n\\Name va...va* - Verse Number - Alternate\n\\Description Second (alternate) verse number (for coding dual numeration in Psalms; see also NRSV Exo 22.1-4)\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 s3 d sp\n\\TextType Other\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\\Color 2263842\n#!\\ColorName green\n\n\\Marker vp\n\\Endmarker vp*\n\\Name vp...vp* - Verse Number - Publishing Alternate\n\\Description Published verse marker (verse string that should appear in the published text)\n\\OccursUnder cd lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 s3 d sp\n\\TextType Other\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\\Color 16711680\n#!\\ColorName highcon blue\n\n# Paragraphs\n\n\\Marker p\n\\Name p - Paragraph - Normal - First Line Indent\n\\Description Paragraph text, with first line indent (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\n\\Marker m\n\\Name m - Paragraph - Margin - No First Line Indent\n\\Description Paragraph text, with no first line indent (may occur after poetry) (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker po\n\\Name po - Paragraph - Letter Opening\n\\Description Letter opening\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\SpaceBefore 4\n\\SpaceAfter 4\n\n\\Marker pr\n\\Name pr - Paragraph - Text Refrain (right aligned)\n\\Description Text refrain (paragraph text, right aligned)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\Justification Right\n\\FontSize 12\n\n\\Marker cls\n\\Name cls - Paragraph - Letter Closing\n\\Description Letter Closing\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Justification Right\n\n\\Marker pmo\n\\Name pmo - Paragraph - Embedded Text Opening\n\\Description Embedded text opening\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr po q q1 q2 q3 q4 qc qr b s1 s2 s3 s4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pm\n\\Name pm - Paragraph - Embedded Text\n\\Description Embedded text paragraph\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr po psi q q1 q2 q3 q4 qc qr b s1 s2 s3 s4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pmc\n\\Name pmc - Paragraph - Embedded Text Closing\n\\Description Embedded text closing\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr po q q1 q2 q3 q4 qc qr b s1 s2 s3 s4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pmr\n\\Name pmr - Paragraph - Embedded Text Refrain\n\\Description Embedded text refrain (e.g. Then all the people shall say, \"Amen!\")\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr po q q1 q2 q3 q4 qc qr b s1 s2 s3 s4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Justification Right\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pi\n\\Name pi - Paragraph - Indented - Level 1 - First Line Indent\n\\Description Paragraph text, level 1 indent (if single level), with first line indent; often used for discourse (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pi1\n\\Name pi1 - Paragraph - Indented - Level 1 - First Line Indent\n\\Description Paragraph text, level 1 indent (if multiple levels), with first line indent; often used for discourse\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pi2\n\\Name pi2 - Paragraph - Indented - Level 2 - First Line Indent\n\\Description Paragraph text, level 2 indent, with first line indent; often used for discourse\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .5\n\\RightMargin .25\n\n\\Marker pi3\n\\Name pi3 - Paragraph - Indented - Level 3 - First Line Indent\n\\Description Paragraph text, level 3 indent, with first line indent; often used for discourse\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .75\n\\RightMargin .25\n\n\\Marker pc\n\\Name pc - Paragraph - Centered (for Inscription)\n\\Description Paragraph text, centered (for Inscription)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\Justification Center\n\\FontSize 12\n\n\\Marker mi\n\\Name mi - Paragraph - Indented - No First Line Indent\n\\Description Paragraph text, indented, with no first line indent; often used for discourse\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker nb\n\\Name nb - Paragraph - No Break with Previous Paragraph\n\\Description Paragraph text, with no break from previous paragraph text (at chapter boundary) (basic)\n\\OccursUnder c \n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n# Poetry\n\n\\Marker q\n\\Name q - Poetry - Indent Level 1 - Single Level Only\n\\Description Poetry text, level 1 indent (if single level)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 0.75\n\\FirstLineIndent -0.5  # 1/8 inch indent, 3/4 inch wrap\n\n\\Marker q1\n\\Name q1 - Poetry - Indent Level 1\n\\Description Poetry text, level 1 indent (if multiple levels) (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 0.75\n\\FirstLineIndent -0.5  # 1/8 inch indent, 3/4 inch wrap\n\n\\Marker q2\n\\Name q2 - Poetry - Indent Level 2\n\\Description Poetry text, level 2 indent (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 0.75\n\\FirstLineIndent -0.375  # 1/4 inch indent, 3/4 inch wrap\n\n\\Marker q3\n\\Name q3 - Poetry - Indent Level 3\n\\Description Poetry text, level 3 indent\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_3\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 0.75\n\\FirstLineIndent -0.25 # 3/8 inch indent, 3/4 inch wrap\n\n\\Marker q4\n\\Name q4 - Poetry - Indent Level 4\n\\Description Poetry text, level 4 indent\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_4\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 0.75\n\\FirstLineIndent -0.125 # 1/2 inch indent, 3/4 inch wrap\n\n\\Marker qc\n\\Name qc - Poetry - Centered\n\\Description Poetry text, centered\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic\n\\StyleType Paragraph\n\\FontSize 12\n\\Justification Center\n\n\\Marker qr\n\\Name qr - Poetry - Right Aligned\n\\Description Poetry text, Right Aligned\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic\n\\StyleType Paragraph\n\\FontSize 12\n\\Justification Right\n\n\\Marker qs\n\\Endmarker qs*\n\\Name qs...qs* - Poetry Text - Selah\n\\Description Poetry text, Selah\n\\OccursUnder q q1 q2 q3 q4 qc qr qd NEST\n\\Rank 4\n\\TextType VerseText\n\\TextProperties publishable vernacular poetic\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker qa\n\\Name qa - Poetry - Acrostic Heading/Marker\n\\Description Poetry text, Acrostic marker/heading\n\\OccursUnder c\n\\Rank 4\n\\TextType Other\n\\TextProperties paragraph publishable vernacular poetic\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\n\\Marker qac\n\\Endmarker qac*\n\\Name qac...qac* - Poetry Text - Acrostic Letter\n\\Description Poetry text, Acrostic markup of the first character of a line of acrostic poetry\n\\OccursUnder q q1 q2 q3 q4 qc qr  NEST\n\\Rank 4\n\\TextType Other\n\\TextProperties publishable vernacular poetic\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker qm\n\\Name qm - Poetry - Embedded Text - Indent Level 1 - Single Level Only\n\\Description Poetry text, embedded, level 1 indent (if single level)\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr q q1 q2 q3 q4 qc qr b\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.75  # 1/4 inch indent, 1 inch wrap\n\n\\Marker qm1\n\\Name qm1 - Poetry - Embedded Text - Indent Level 1\n\\Description Poetry text, embedded, level 1 indent (if multiple levels)\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr q q1 q2 q3 q4 qc qr b\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.75  # 1/4 inch indent, 1 inch wrap\n\n\\Marker qm2\n\\Name qm2 - Poetry - Embedded Text - Indent Level 2\n\\Description Poetry text, embedded, level 2 indent\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr q q1 q2 q3 q4 qc qr b\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.5  # 1/2 inch indent, 1 inch wrap\n\n\\Marker qm3\n\\Name qm3 - Poetry - Embedded Text - Indent Level 3\n\\Description Poetry text, embedded, level 3 indent\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr q q1 q2 q3 q4 qc qr b\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_3\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.25 # 3/4 inch indent, 1 inch wrap\n\n\\Marker qd\n\\Name qd - Poetry - Hebrew Note\n\\Description A Hebrew musical performance annotation, similar in content to Hebrew descriptive title.\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\LeftMargin .25\n\n\\Marker b\n\\Name b - Poetry - Stanza Break (Blank Line)\n\\Description Poetry text stanza break (e.g. stanza break) (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n# Titles & Headings\n\n\\Marker mt\n\\Name mt - Title - Major Title Level 1\n\\Description The main title of the book (if single level)\n\\OccursUnder id\n\\Rank 3\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Title\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker mt1\n\\Name mt1 - Title - Major Title Level 1\n\\Description The main title of the book (if multiple levels) (basic)\n\\OccursUnder id\n\\Rank 3\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Title\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 2\n\\SpaceAfter 4\n\n\\Marker mt2\n\\Name mt2 - Title - Major Title Level 2\n\\Description A secondary title usually occurring before the main title (basic)\n\\OccursUnder id\n\\Rank 3\n\\TextProperties paragraph publishable vernacular level_2\n\\TextType Title\n\\StyleType Paragraph\n\\FontSize 16\n\\Italic\n\\Justification Center\n\\SpaceAfter 2\n\n\\Marker mt3\n\\Name mt3 - Title - Major Title Level 3\n\\Description A secondary title occurring after the main title\n\\OccursUnder id\n\\Rank 3\n\\TextProperties paragraph publishable vernacular level_3\n\\TextType Title\n\\StyleType Paragraph\n\\FontSize 16\n\\Bold\n\\Justification Center\n\\SpaceBefore 2\n\\SpaceAfter 2\n\n\\Marker mt4\n\\Name mt4 - Title - Major Title level 4\n\\Description A small secondary title sometimes occurring within parentheses\n\\OccursUnder id\n\\Rank 3\n\\TextProperties paragraph publishable vernacular level_4\n\\TextType Title\n\\StyleType Paragraph\n\\FontSize 12\n\\Justification Center\n\\SpaceBefore 2\n\\SpaceAfter 2\n\n\\Marker mte\n\\Name mte - Title - [Uncommon] Major Title Ending Level 1\n\\Description The main title of the book repeated at the end of the book, level 1 (if single level)\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Title\n\\OccursUnder c\n\\Rank 2\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker mte1\n\\Name mte1 - Title - [Uncommon] Major Title Ending Level 1\n\\Description The main title of the book repeated at the end of the book, level 1 (if multiple levels)\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Title\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tc1 tc2 tc3 tc4 s3 d\n\\Rank 2\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n \n\\Marker mte2\n\\Name mte2 - Title - [Uncommon] Major Title Ending Level 2\n\\Description A secondary title occurring before or after the 'ending' main title\n\\TextProperties paragraph publishable vernacular level_2\n\\TextType Title\n\\OccursUnder mte1\n\\Rank 2\n\\StyleType Paragraph\n\\FontSize 16\n\\Italic\n\\Justification Center\n\\SpaceAfter 2\n\n\\Marker ms\n\\Name ms - Heading - Major Section Level 1\n\\Description A major section division heading, level 1 (if single level) (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 16\n\\SpaceAfter 4\n\n\\Marker ms1\n\\Name ms1 - Heading - Major Section Level 1\n\\Description A major section division heading, level 1 (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 16\n\\SpaceAfter 4\n\n\\Marker ms2\n\\Name ms2 - Heading - Major Section Level 2\n\\Description A major section division heading, level 2\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 16\n\\SpaceAfter 4\n\n\\Marker ms3\n\\Name ms3 - Heading - Major Section Level 3\n\\Description A major section division heading, level 3\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Italic\n\\Justification Center\n\\SpaceBefore 16\n\\SpaceAfter 4\n\n\\Marker mr\n\\Name mr - Heading - Major Section Range References\n\\Description A major section division references range heading (basic)\n\\OccursUnder ms ms1 ms2 ms3\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Center\n\\SpaceAfter 4\n\n\\Marker s\n\\Name s - Heading - Section Level 1\n\\Description A section heading, level 1 (if single level) (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker s1\n\\Name s1 - Heading - Section Level 1\n\\Description A section heading, level 1 (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker s2\n\\Name s2 - Heading - Section Level 2\n\\Description A section heading, level 2 (e.g. Proverbs 22-24)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker s3\n\\Name s3 - Heading - Section Level 3\n\\Description A section heading, level 3 (e.g. Genesis \"The First Day\")\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Left\n\\SpaceBefore 6\n\\SpaceAfter 3\n\n\\Marker s4\n\\Name s4 - Heading - Section Level 4\n\\Description A section heading, level 4\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_4\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Left\n\\SpaceBefore 6\n\\SpaceAfter 3\n\n\\Marker sr\n\\Name sr - Heading - Section Range References\n\\Description A section division references range heading\n\\OccursUnder s s1 s2 s3 s4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceAfter 4\n\n\\Marker r\n\\Name r - Heading - Parallel References\n\\Description Parallel reference(s) (basic)\n\\OccursUnder c s s1 s2 s3 s4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Center\n\\SpaceAfter 4\n\n\\Marker sp\n\\Name sp - Label - Speaker\n\\Description A heading, to identify the speaker (e.g. Job)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Left\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker d\n\\Name d - Label - Descriptive Title - Hebrew Subtitle\n\\Description A Hebrew text heading, to provide description (e.g. Psalms)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Center\n\\SpaceBefore 4\n\\SpaceAfter 4\n\n\\Marker sd\n\\Name sd - Label - Semantic Division Location - Level 1\n\\Description Vertical space used to divide the text into sections, level 1 (if single level)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\SpaceBefore 24\n\\SpaceAfter 24\n\n\\Marker sd1\n\\Name sd1 - Label - Semantic Division Location - Level 1\n\\Description Vertical space used to divide the text into sections, level 1 (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\SpaceBefore 24\n\\SpaceAfter 24\n\n\\Marker sd2\n\\Name sd2 - Label - Semantic Division Location - Level 2\n\\Description Vertical space used to divide the text into sections, level 2\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType Paragraph\n\\SpaceBefore 18\n\\SpaceAfter 18\n\n\\Marker sd3\n\\Name sd3 - Label - Semantic Division Location - Level 3\n\\Description Vertical space used to divide the text into sections, level 3\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType Paragraph\n\\SpaceBefore 12\n\\SpaceAfter 12\n\n\\Marker sd4\n\\Name sd4 - Label - Semantic Division Location - Level 4\n\\Description Vertical space used to divide the text into sections, level 4\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_4\n\\StyleType Paragraph\n\\SpaceBefore 8\n\\SpaceAfter 8\n\n# Tables\n\n\\Marker tr\n\\Name tr - Table - Row\n\\Description A new table row\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.25  # 6/16 inch\n\n\\Marker th1 \n\\Name th1 - Table - Column 1 Heading\n\\Description A table heading, column 1\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th2\n\\Name th2 - Table - Column 2 Heading\n\\Description A table heading, column 2\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th3\n\\Name th3 - Table - Column 3 Heading\n\\Description A table heading, column 3\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th4\n\\Name th4 - Table - Column 4 Heading\n\\Description A table heading, column 4\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th5\n\\Name th5 - Table - Column 5 Heading\n\\Description A table heading, column 5\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th6\n\\Name th6 - Table - Column 6 Heading\n\\Description A table heading, column 6\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th7\n\\Name th7 - Table - Column 7 Heading\n\\Description A table heading, column 7\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th8\n\\Name th8 - Table - Column 8 Heading\n\\Description A table heading, column 8\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th9\n\\Name th9 - Table - Column 9 Heading\n\\Description A table heading, column 9\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th10\n\\Name th10 - Table - Column 10 Heading\n\\Description A table heading, column 10\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th11\n\\Name th11 - Table - Column 11 Heading\n\\Description A table heading, column 11\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th12\n\\Name th12 - Table - Column 12 Heading\n\\Description A table heading, column 12\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker tc1\n\\Name tc1 - Table - Column 1 Cell\n\\Description A table cell item, column 1\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc2\n\\Name tc2 - Table - Column 2 Cell\n\\Description A table cell item, column 2\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc3\n\\Name tc3 - Table - Column 3 Cell\n\\Description A table cell item, column 3\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc4\n\\Name tc4 - Table - Column 4 Cell\n\\Description A table cell item, column 4\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc5\n\\Name tc5 - Table - Column 5 Cell\n\\Description A table cell item, column 5\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc6\n\\Name tc6 - Table - Column 6 Cell\n\\Description A table cell item, column 6\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc7\n\\Name tc7 - Table - Column 7 Cell\n\\Description A table cell item, column 7\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc8\n\\Name tc8 - Table - Column 8 Cell\n\\Description A table cell item, column 8\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc9\n\\Name tc9 - Table - Column 9 Cell\n\\Description A table cell item, column 9\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc10\n\\Name tc10 - Table - Column 10 Cell\n\\Description A table cell item, column 10\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc11\n\\Name tc11 - Table - Column 11 Cell\n\\Description A table cell item, column 11\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc12\n\\Name tc12 - Table - Column 12 Cell\n\\Description A table cell item, column 12\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n# Center Aligned Table Heads and Columns\n\n\\Marker thc1 \n\\Name thc1 - Table - Column 1 Heading - Center Aligned\n\\Description A table heading, column 1, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc2\n\\Name thc2 - Table - Column 2 Heading - Center Aligned\n\\Description A table heading, column 2, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc3\n\\Name thc3 - Table - Column 3 Heading - Center Aligned\n\\Description A table heading, column 3, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc4\n\\Name thc4 - Table - Column 4 Heading - Center Aligned\n\\Description A table heading, column 4, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc5\n\\Name thc5 - Table - Column 5 Heading - Center Aligned\n\\Description A table heading, column 5, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc6\n\\Name thc6 - Table - Column 6 Heading - Center Aligned\n\\Description A table heading, column 6, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc7\n\\Name thc7 - Table - Column 7 Heading - Center Aligned\n\\Description A table heading, column 7, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc8\n\\Name thc8 - Table - Column 8 Heading - Center Aligned\n\\Description A table heading, column 8, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc9\n\\Name thc9 - Table - Column 9 Heading - Center Aligned\n\\Description A table heading, column 9, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc10\n\\Name thc10 - Table - Column 10 Heading - Center Aligned\n\\Description A table heading, column 10, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc11\n\\Name thc11 - Table - Column 11 Heading - Center Aligned\n\\Description A table heading, column 11, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc12\n\\Name thc12 - Table - Column 12 Heading - Center Aligned\n\\Description A table heading, column 12, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker tcc1\n\\Name tcc1 - Table - Column 1 Cell - Center Aligned\n\\Description A table cell item, column 1, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc2\n\\Name tcc2 - Table - Column 2 Cell - Center Aligned\n\\Description A table cell item, column 2, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc3\n\\Name tcc3 - Table - Column 3 Cell - Center Aligned\n\\Description A table cell item, column 3, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc4\n\\Name tcc4 - Table - Column 4 Cell - Center Aligned\n\\Description A table cell item, column 4, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc5\n\\Name tcc5 - Table - Column 5 Cell - Center Aligned\n\\Description A table cell item, column 5, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc6\n\\Name tcc6 - Table - Column 6 Cell - Center Aligned\n\\Description A table cell item, column 6, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc7\n\\Name tcc7 - Table - Column 7 Cell - Center Aligned\n\\Description A table cell item, column 7, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc8\n\\Name tcc8 - Table - Column 8 Cell - Center Aligned\n\\Description A table cell item, column 8, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc9\n\\Name tcc9 - Table - Column 9 Cell - Center Aligned\n\\Description A table cell item, column 9, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc10\n\\Name tcc10 - Table - Column 10 Cell - Center Aligned\n\\Description A table cell item, column 10, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc11\n\\Name tcc11 - Table - Column 11 Cell - Center Aligned\n\\Description A table cell item, column 11, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc12\n\\Name tcc12 - Table - Column 12 Cell - Center Aligned\n\\Description A table cell item, column 12, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n# Right Aligned Table Heads and Columns\n\n\\Marker thr1 \n\\Name thr1 - Table - Column 1 Heading - Right Aligned\n\\Description A table heading, column 1, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Right\n\n\\Marker thr2\n\\Name thr2 - Table - Column 2 Heading - Right Aligned\n\\Description A table heading, column 2, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Right\n\n\\Marker thr3\n\\Name thr3 - Table - Column 3 Heading - Right Aligned\n\\Description A table heading, column 3, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Right\n\n\\Marker thr4\n\\Name thr4 - Table - Column 4 Heading - Right Aligned\n\\Description A table heading, column 4, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Right\n\n\\Marker thr5\n\\Name thr5 - Table - Column 5 Heading - Right Aligned\n\\Description A table heading, column 5, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Right\n\n\\Marker thr6\n\\Name thr6 - Table - Column 6 Heading - Right Aligned\n\\Description A table heading, column 6, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr7\n\\Name thr7 - Table - Column 7 Heading - Right Aligned\n\\Description A table heading, column 7, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr8\n\\Name thr8 - Table - Column 8 Heading - Right Aligned\n\\Description A table heading, column 8, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr9\n\\Name thr9 - Table - Column 9 Heading - Right Aligned\n\\Description A table heading, column 9, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr10\n\\Name thr10 - Table - Column 10 Heading - Right Aligned\n\\Description A table heading, column 10, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr11\n\\Name thr11 - Table - Column 11 Heading - Right Aligned\n\\Description A table heading, column 11, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr12\n\\Name thr12 - Table - Column 12 Heading - Right Aligned\n\\Description A table heading, column 12, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker tcr1 \n\\Name tcr1 - Table - Column 1 Cell - Right Aligned\n\\Description A table cell item, column 1, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Right\n\n\\Marker tcr2\n\\Name tcr2 - Table - Column 2 Cell - Right Aligned\n\\Description A table cell item, column 2, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Right\n\n\\Marker tcr3\n\\Name tcr3 - Table - Column 3 Cell - Right Aligned\n\\Description A table cell item, column 3, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Right\n\n\\Marker tcr4\n\\Name tcr4 - Table - Column 4 Cell - Right Aligned\n\\Description A table cell item, column 4, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Right\n\n\\Marker tcr5\n\\Name tcr5 - Table - Column 5 Cell - Right Aligned\n\\Description A table cell item, column 5, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Right\n\n\\Marker tcr6\n\\Name tcr6 - Table - Column 6 Cell - Right Aligned\n\\Description A table cell item, column 6, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr7\n\\Name tcr7 - Table - Column 7 Cell - Right Aligned\n\\Description A table cell item, column 7, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr8\n\\Name tcr8 - Table - Column 8 Cell - Right Aligned\n\\Description A table cell item, column 8, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr9\n\\Name tcr9 - Table - Column 9 Cell - Right Aligned\n\\Description A table cell item, column 9, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr10\n\\Name tcr10 - Table - Column 10 Cell - Right Aligned\n\\Description A table cell item, column 10, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr11\n\\Name tcr11 - Table - Column 11 Cell - Right Aligned\n\\Description A table cell item, column 11, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr12\n\\Name tcr12 - Table - Column 12 Cell - Right Aligned\n\\Description A table cell item, column 12, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n# Lists\n\n\\Marker lh\n\\Name lh - List Header\n\\Description List header (introductory remark)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\n\\Marker li\n\\Name li - List Entry - Level 1\n\\Description A list entry, level 1 (if single level)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.375 # 1/8 inch indent, 1/2 inch wrap\n\n\\Marker li1\n\\Name li1 - List Entry - Level 1\n\\Description A list entry, level 1 (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.375 # 1/8 inch indent, 1/2 inch wrap\n\n\\Marker li2\n\\Name li2 - List Entry - Level 2\n\\Description A list entry, level 2\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .75\n\\FirstLineIndent -.375\n\n\\Marker li3\n\\Name li3 - List Entry - Level 3\n\\Description A list entry, level 3\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.375\n\n\\Marker li4\n\\Name li4 - List Entry - Level 4\n\\Description A list entry, level 4\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_4\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1.25\n\\FirstLineIndent -.375\n\n\\Marker lf\n\\Name lf - List Footer\n\\Description List footer (concluding remark)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker lim\n\\Name lim - Embedded List Entry - Level 1\n\\Description An embedded list entry, level 1 (if single level)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .75\n\\FirstLineIndent -.375\n\\RightMargin .25\n\n\\Marker lim1\n\\Name lim1 - Embedded List Entry - Level 1\n\\Description An embedded list entry, level 1 (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .75\n\\FirstLineIndent -.375\n\\RightMargin .25\n\n\\Marker lim2\n\\Name lim2 - Embedded List Entry - Level 2\n\\Description An embedded list entry, level 2\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.375\n\n\\Marker lim3\n\\Name lim3 - Embedded List Item - Level 3\n\\Description An embedded list item, level 3\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1.25\n\\FirstLineIndent -.375\n\n\\Marker lim4\n\\Name lim4 - Embedded List Entry - Level 4\n\\Description An embedded list entry, level 4\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_4\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1.5\n\\FirstLineIndent -.375\n\n\\Marker litl\n\\Endmarker litl*\n\\Name litl...litl* - List Entry - Total\n\\Description List entry total text\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker lik\n\\Endmarker lik*\n\\Name lik...lik* - Structured List Entry - Key\n\\Description Structured list entry key text\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker liv\n\\Endmarker liv*\n\\Name liv...liv* - Structured List Entry - Value 1\n\\Description Structured list entry value 1 content (if single value)\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker liv1\n\\Endmarker liv1*\n\\Name liv1...liv1* - Structured List Entry - Value 1\n\\Description Structured list entry value 1 content (if multiple values)\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker liv2\n\\Endmarker liv2*\n\\Name liv2...liv2* - Structured List Entry - Value 2\n\\Description Structured list entry value 2 content\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker liv3\n\\Endmarker liv3*\n\\Name liv3...liv3* - Structured List Entry - Value 3\n\\Description Structured list entry value 3 content\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker liv4\n\\Endmarker liv4*\n\\Name liv4...liv4* - Structured List Entry - Value 4\n\\Description Structured list entry value 4 content\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker liv5\n\\Endmarker liv5*\n\\Name liv5...liv5* - Structured List Entry - Value 5\n\\Description Structured list entry value 5 content\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n# Footnotes\n\n\\Marker f\n\\Endmarker f*\n\\Name f...f* - Footnote \n\\Description A Footnote text item (basic)\n\\OccursUnder c cp lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 qs sp tc1 tc2 tc3 tc4 mt mt1 mt2 mt3 ms ms1 ms2 ms3 s s1 s2 s3 d ip\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Note\n\\FontSize 12\n\n\\Marker fe\n\\Endmarker fe*\n\\Name fe...fe* - Endnote\n\\Description An Endnote text item\n\\OccursUnder c lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tc1 tc2 tc3 tc4 ms ms1 ms2 ms3 s s1 s2 s3 d ip\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Note\n\\FontSize 12\n\n\\Marker fr\n\\Endmarker fr*\n\\Name fr - Footnote - Reference\n\\Description The origin reference for the footnote (basic)\n\\OccursUnder f fe\n\\TextType NoteText\n\\TextProperties publishable vernacular note\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\n\\Marker ft\n\\Endmarker ft*\n\\Name ft - Footnote - Text\n\\Description Footnote text, Protocanon (basic)\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker fk\n\\Endmarker fk*\n\\Name fk - Footnote - Keyword\n\\Description A footnote keyword (basic)\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\\Italic\n\n\\Marker fq\n\\Endmarker fq*\n\\Name fq - Footnote - Quotation or Alternate Rendering\n\\Description A footnote scripture quote or alternate rendering (basic)\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker fqa\n\\Endmarker fqa*\n\\Name fqa - Footnote - Alternate Translation Rendering\n\\Description A footnote alternate rendering for a portion of scripture text\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker fl\n\\Endmarker fl*\n\\Name fl - Footnote - Label Text\n\\Description A footnote label text item, for marking or \"labelling\" the type or alternate translation being provided in the note.\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Bold\n\n\\Marker fw\n\\Endmarker fw*\n\\Name fw - Footnote - Witness List\n\\Description A footnote witness list, for distinguishing a list of sigla representing witnesses in critical editions.\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker fp\n\\Endmarker fp*\n\\Name fp - Footnote Paragraph Mark\n\\Description A Footnote additional paragraph marker\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker fv\n\\Endmarker fv*\n\\Name fv...fv* - Footnote - Embedded Verse Number\n\\Description A verse number within the footnote text\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\n\\Marker fdc\n\\Endmarker fdc*\n\\Name DEPRECATED fdc...fdc* - Footnote - DC text\n\\Description Footnote text, applies to Deuterocanon only\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker fm\n\\Endmarker fm*\n\\Name fm - Footnote - Additional Caller to Previous Note\n\\Description An additional footnote marker location for a previous footnote \n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tc1 tc2 tc3 tc4 ms ms1 ms2 s s1 s2 s3 d ip\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\n# Cross References\n\n\\Marker x\n\\Endmarker x*\n\\Name x...x* - Cross Reference\n\\Description A list of cross references (basic)\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 qs sp tc1 tc2 tc3 tc4 mt mt1 mt2 mt3 ms ms1 ms2 s s1 s2 s3 d\n\\TextProperties publishable vernacular note crossreference\n\\TextType NoteText\n\\StyleType Note\n\\FontSize 12\n\n\\Marker xo\n\\Endmarker xo*\n\\Name xo - Cross Reference - Origin Reference\n\\Description The cross reference origin reference (basic)\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\n\\Marker xop\n\\Endmarker xop*\n\\Name xop - Cross Reference - Origin Reference Publishing Alternate\n\\Description Published cross reference origin reference (origin reference that should appear in the published text)\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker xt\n\\Endmarker xt*\n\\Name xt - Cross Reference - Target References\n\\Description The cross reference target reference(s), protocanon only (basic)\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x ef ex NEST\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n#!\\Attributes ?link-href\n\n\\Marker xta\n\\Endmarker xta*\n\\Name xta - Cross Reference - Target References Added Text\n\\Description Cross reference target references added text\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker xk\n\\Endmarker xk*\n\\Name xk - Cross Reference - Keyword\n\\Description A cross reference keyword\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker xq\n\\Endmarker xq*\n\\Name xq - Cross Reference - Quotation\n\\Description A cross-reference quotation from the scripture text\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker xot\n\\Endmarker xot*\n\\Name xot...xot* - Cross Reference - OT Target Refs (optional)\n\\Description Cross-reference target reference(s), Old Testament only\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker xnt\n\\Endmarker xnt*\n\\Name xnt...xnt* - Cross Reference - NT Target Refs (optional)\n\\Description Cross-reference target reference(s), New Testament only\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker xdc\n\\Endmarker xdc*\n\\Name DEPRECATED xdc...xdc* - Cross Reference - DC Target Refs\n\\Description Cross-reference target reference(s), Deuterocanon only\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker rq\n\\Endmarker rq*\n\\Name rq...rq* - Cross Reference - Inline Quotation References\n\\Description A cross-reference indicating the source text for the preceding quotation.\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 NEST\n\\TextType Other\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 10\n\\Italic\n\n# Other Special Text\n\n\\Marker qt\n\\Endmarker qt*\n\\Name qt...qt* - Special Text - Quoted Text - OT in NT\n\\Description For Old Testament quoted text appearing in the New Testament (basic)\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker nd\n\\Endmarker nd*\n\\Name nd...nd* - Special Text - Name of Deity\n\\Description For name of deity (basic)\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Underline\n\n\\Marker tl\n\\Endmarker tl*\n\\Name tl...tl* - Special Text - Transliterated Word\n\\Description For transliterated words\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable nonvernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker dc\n\\Endmarker dc*\n\\Name dc...dc* - Special Text - Deuterocanonical/LXX Additions\n\\Description Deuterocanonical/LXX additions or insertions in the Protocanonical text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\Italic\n\n\\Marker bk\n\\Endmarker bk*\n\\Name bk...bk* - Special Text - Quoted book title\n\\Description For the quoted name of a book\n\\OccursUnder imt imt1 imt2 imt3 imt4 imte imte1 imte2 is is1 is2 ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker sig\n\\Endmarker sig*\n\\Name sig...sig* - Special Text - Author's Signature (Epistles)\n\\Description For the signature of the author of an Epistle\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker pn\n\\Endmarker pn*\n\\Name pn...pn* - Special Text - Proper Name\n\\Description For a proper name\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\\Underline\n\n\\Marker png\n\\Endmarker png*\n\\Name png...png* - Special Text - Geographic Proper Name\n\\Description For a geographic proper name\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Underline\n\n\\Marker addpn\n\\Endmarker addpn*\n\\Name DEPRECATED addpn...addpn* - Special Text for Chinese\n\\Description For chinese words to be dot underline & underline\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n#\\Color 2263842\n##!\\ColorName green\n\\Bold\n\\Italic\n\\Underline\n\n\\Marker wj\n\\Endmarker wj*\n\\Name wj...wj* - Special Text - Words of Jesus\n\\Description For marking the words of Jesus\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Color 255\n#!\\ColorName highcon red\n\n\\Marker k\n\\Endmarker k*\n\\Name k...k* - Special Text - Keyword\n\\Description For a keyword\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Bold\n\n\\Marker sls\n\\Endmarker sls*\n\\Name sls...sls* - Special Text - Secondary Language or Text Source\n\\Description To represent where the original text is in a secondary language or from an alternate text source\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker ord\n\\Endmarker ord*\n\\Name ord...ord* - Special Text - Ordinal number text portion\n\\Description For the text portion of an ordinal number\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\n\\Marker add\n\\Endmarker add*\n\\Name add...add* - Special Text - Translational Addition\n\\Description For a translational addition to the text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n#\\Color 2263842\n##!\\ColorName green\n\\Bold\n\\Italic\n\n\\Marker lit\n\\Name lit - Special Text - Liturgical note\n\\Description For a comment or note inserted for liturgical use\n\\OccursUnder c\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\Justification Right\n\\FontSize 12\n\\Bold\n\n# Character Styling\n\n\\Marker no\n\\Endmarker no*\n\\Name no...no* - Character - Normal Text\n\\Description A character style, use normal text\n\\OccursUnder is ip ipi im imi ili ili1 ili2 imq ipq iex iq iot io1 io2 io3 io4 s s1 s2 s3 NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker it\n\\Endmarker it*\n\\Name it...it* - Character - Italic Text\n\\Description A character style, use italic text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker bd\n\\Endmarker bd*\n\\Name bd...bd* - Character - Bold Text\n\\Description A character style, use bold text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\n\\Marker bdit\n\\Endmarker bdit*\n\\Name bdit...bdit* - Character - BoldItalic Text\n\\Description A character style, use bold + italic text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\\Italic\n\n\\Marker em\n\\Endmarker em*\n\\Name em...em* - Character - Emphasized Text\n\\Description A character style, use emphasized text style\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker sc\n\\Endmarker sc*\n\\Name sc...sc* - Character - Small Caps\n\\Description A character style, for small capitalization text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Smallcaps\n\n\\Marker sup\n\\Endmarker sup*\n\\Name sup...sup* - Character - Superscript\n\\Description A character style, for superscript text. Typically for use in critical edition footnotes.\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\n# Breaks\n\n\\Marker pb\n\\Name pb - Break - Page Break\n\\Description Page Break used for new reader portions and children's bibles where content is controlled by the page\n\\OccursUnder c\n\\Rank 4\n\\TextType Other\n\\TextProperties publishable\n\\StyleType Paragraph\n\\FontSize 12\n\n# Special Features\n\n\\Marker fig\n\\Endmarker fig*\n\\Name fig...fig* - Auxiliary - Figure/Illustration/Map\n\\Description Illustration [Columns to span, height, filename, caption text]\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 ms ms1 ms2 s s1 s2 s3 d ip\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n#!\\Attributes src size ref ?alt ?loc ?copy\n\n\\Marker jmp\n\\Endmarker jmp*\n\\Name jmp...jmp* - Link text\n\\Description For associating linking attributes to a span of text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType Other\n\\StyleType Character\n\\Color 16711680\n#!\\ColorName highcon blue\n\\Underline\n#!\\Attributes ?link-href ?link-id ?link-title\n\n\\Marker pro\n\\Endmarker pro*\n\\Name DEPRECATED pro...pro* - Special Text - CJK Pronunciation\n\\Description For indicating pronunciation in CJK texts\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 ms ms1 ms2 s s1 s2 s3 d ip f fe NEST\n\\TextType Other\n\\TextProperties Nonpublishable\n\\StyleType Character\n\\FontSize 10\n\n\\Marker rb\n\\Endmarker rb*\n\\Name rb...rb* - Special Text - Ruby Glossing\n\\Description Most often used to provide a reading / pronunciation guide in ideographic scripts\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 ms ms1 ms2 s s1 s2 s3 d ip f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n#!\\Attributes gloss\n\n# Peripheral References\n\n\\Marker w\n\\Endmarker w*\n\\Name w...w* - Peripheral Ref - Wordlist Entry\n\\Description A wordlist text item\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n#!\\Attributes ?lemma ?strong ?srcloc\n\n\\Marker wh\n\\Endmarker wh*\n\\Name wh...wh* - Peripheral Ref - Hebrew Wordlist Entry\n\\Description A Hebrew wordlist text item\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker wg\n\\Endmarker wg*\n\\Name wg...wg* - Peripheral Ref - Greek Wordlist Entry\n\\Description A Greek Wordlist text item\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker wa\n\\Endmarker wa*\n\\Name wa...wa* - Peripheral Ref - Aramaic Wordlist Entry\n\\Description An Aramaic Wordlist text item\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker ndx\n\\Endmarker ndx*\n\\Name ndx...ndx* - Peripheral Ref - Subject Index Entry \n\\Description A subject index text item\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n# Peripheral Materials\n# Content Division Marker\n\n\\Marker periph\n\\Name periph - Peripherals - Content Division Marker\n\\Description Peripheral content division marker which should be followed by an additional division argument/title.\n\\TextType Section\n\\TextProperties paragraph nonpublishable vernacular\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\SpaceBefore 16\n\\SpaceAfter 4\n\\Color 33023\n#!\\ColorName orange\n\n# Additional peripheral material extensions to existing USFM markup.\n\n\\Marker p1\n\\Name p1 - Periph - Front/Back Matter Paragraph Level 1\n\\Description Front or back matter text paragraph, level 1 (if multiple levels)\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\n\\Marker p2\n\\Name p2 - Periph - Front/Back Matter Paragraph Level 2\n\\Description Front or back matter text paragraph, level 2 (if multiple levels)\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/4 inch first line indent\n\\LeftMargin .125\n\n\\Marker k1\n\\Name k1 - Periph - Concordance Keyword Level 1\n\\Description Concordance main entry text or keyword, level 1\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker k2\n\\Name k2 - Periph - Concordance Keyword Level 2\n\\Description Concordance main entry text or keyword, level 2\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker xtSee\n\\Endmarker xtSee*\n\\Name xtSee - Concordance and Names Index - Alternate Entry Target Reference\n\\Description Concordance and Names Index markup for an alternate entry target reference.\n\\OccursUnder p\n\\TextProperties publishable vernacular\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Color 16711680\n#!\\ColorName highcon blue\n\n\\Marker xtSeeAlso\n\\Endmarker xtSeeAlso*\n\\Name xtSeeAlso - Concordance and Names Index - Additional Entry Target Reference\n\\Description Concordance and Names Index markup for an additional entry target reference.\n\\OccursUnder p\n\\TextProperties publishable vernacular\n\\TextType Other\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Color 16711680\n#!\\ColorName highcon blue\n\n# Milestones - these are not compatible with USFM2, so whole entries are preceded with #!\n\n#!\\Marker qt-s\n#!\\Endmarker qt-e\n#!\\Name Quotation start/end milestone\n#!\\Description Quotation start/end milestone, level 1 (if single level)\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker qt1-s\n#!\\Endmarker qt1-e\n#!\\Name Quotation start/end milestone - Level 1\n#!\\Description Quotation start/end milestone, level 1 (if multiple levels)\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker qt2-s\n#!\\Endmarker qt2-e\n#!\\Name Quotation start/end milestone - Level 2\n#!\\Description Quotation start/end milestone, level 2\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker qt3-s\n#!\\Endmarker qt3-e\n#!\\Name Quotation start/end milestone - Level 3\n#!\\Description Quotation start/end milestone, level 3\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker qt4-s\n#!\\Endmarker qt4-e\n#!\\Name Quotation start/end milestone - Level 4\n#!\\Description Quotation start/end milestone, level 4\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker qt5-s\n#!\\Endmarker qt5-e\n#!\\Name Quotation start/end milestone - Level 5\n#!\\Description Quotation start/end milestone, level 5\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker ts-s\n#!\\Endmarker ts-e\n#!\\Name Translator's section start/end milestone\n#!\\Description Translator's section start/end milestone\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?sid ?eid\n\n# Other special text elements specified in USFM\n#   ~ = fixed (no-break) space\n#   // = discretionary line break\n\n# Obsolete, deprecated, or no longer officially part of USFM.\n# These markers may have existed in earlier resource and stylesheet revisions.\n\n\\Marker ph\n\\Name DEPRECATED ph - Paragraph - Hanging Indent - Level 1\n\\Description Paragraph text, with level 1 hanging indent (if single level)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\LeftMargin .5\n\\FirstLineIndent -.25  # 1/4 inch indent, 1/2 inch wrap\n\\FontSize 12\n\n\\Marker ph1\n\\Name DEPRECATED ph1 - Paragraph - Hanging Indent - Level 1\n\\Description Paragraph text, with level 1 hanging indent (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\LeftMargin .5\n\\FirstLineIndent -.25  # 1/4 inch indent, 1/2 inch wrap\n\\FontSize 12\n\n\\Marker ph2\n\\Name DEPRECATED ph2 - Paragraph - Hanging Indent - Level 2\n\\Description Paragraph text, with level 2 hanging indent\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\LeftMargin .75\n\\FirstLineIndent -.25  # 1/2 inch indent, 3/4 inch wrap\n\\FontSize 12\n\n\\Marker ph3\n\\Name DEPRECATED ph3 - Paragraph - Hanging Indent - Level 3\n\\Description Paragraph text, with level 3 hanging indent\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\LeftMargin 1\n\\FirstLineIndent -.25  # 3/4 inch indent, 1 inch wrap\n\\FontSize 12\n\n\\Marker phi\n\\Name DEPRECATED phi - Paragraph - Indented - Hanging Indent\n\\Description Paragraph text, indented with hanging indent\n\\OccursUnder c \n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\LeftMargin 1\n\n\\Marker tr1\n\\Name DEPRECATED tr1 - Table - Row - Level 1\n\\Description A table Row\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.25  # 6/16 inch\n\n\\Marker tr2\n\\Name DEPRECATED tr2 - Table - Row - Level 2\n\\Description A table Row\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .75\n\\FirstLineIndent -.25  # 6/16 inch\n\n\\Marker ps\n\\Name DEPRECATED ps - Paragraph - No Break with Next Paragraph\n\\Description Paragraph text, no break with next paragraph text at chapter boundary\n\\OccursUnder c \n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\n\\Marker psi\n\\Name DEPRECATED psi - Paragraph - Indented - No Break with Next\n\\Description Paragraph text, indented, with no break with next paragraph text (at chapter boundary)\n\\OccursUnder c \n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .25\n\\RightMargin .25\n\\FontSize 12\n\n\\Marker fs\n\\Endmarker fs*\n\\Name DEPRECATED fs - Footnote - Footnote Summary\n\\Description A summary text for the concept/idea/quotation from the scripture translation for which the note is being provided.\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker wr\n\\Endmarker wr*\n\\Name DEPRECATED wr...wr* - Auxiliary - Wordlist/Glossary Reference \n\\Description A Wordlist text item\n\\OccursUnder ms s lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr po q q1 q2 q3 q4 qc qr qd tc1 tc2 tc3 tc4 f fe NEST\n\\TextProperties publishable vernacular\n\\TextType VerseText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n# 2.0x peripheral markup (replaced with \\periph + Content Division Title/Argument)\n\n\\Marker pub\n\\Name DEPRECATED pub Peripherals - Front Matter Publication Data\n\\Description Front matter publication data\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker toc\n\\Name DEPRECATED toc Peripherals - Front Matter Table of Contents\n\\Description Front matter table of contents\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker pref\n\\Name DEPRECATED pref Peripherals - Front Matter Preface\n\\Description Front matter preface\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker intro\n\\Name DEPRECATED intro Peripherals - Front Matter Introduction\n\\Description Front matter introduction\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker conc\n\\Name DEPRECATED conc Peripherals - Back Matter Concordance\n\\Description Back matter concordance\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker glo\n\\Name DEPRECATED glo Peripherals - Back Matter Glossary\n\\Description Back matter glossary\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker idx\n\\Name DEPRECATED idx Peripherals - Back Matter Index\n\\Description Back matter index\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker maps\n\\Name DEPRECATED maps Peripherals - Back Matter Map Index\n\\Description Back matter map index\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker cov\n\\Name DEPRECATED cov Peripherals - Other - Cover\n\\Description Other peripheral materials - cover\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker spine\n\\Name DEPRECATED spine Peripherals - Other - Spine\n\\Description Other peripheral materials - spine\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker pubinfo\n\\Name DEPRECATED pubinfo - Publication - Information\n\\Description Publication information - Lang,Credit,Version,Copies,Publisher,Id,Logo\n\\OccursUnder id ide\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Color 16711680\n#!\\ColorName highcon blue\n\n# Concordance/Names Index Tools - special sfms for use in Publishing Assistant\n\n\\Marker zpa-xb\n\\Endmarker zpa-xb*\n\\Name zpa-xb - Periph - Book\n\\Description Book Ref\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker zpa-xc\n\\Endmarker zpa-xc*\n\\Name zpa-xc - Periph - Chapter\n\\Description Chapter Ref\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\n\\Marker zpa-xv\n\\Endmarker zpa-xv*\n\\Name zpa-xv - Periph - Verse\n\\Description Verse Ref\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker zpa-d\n\\Endmarker zpa-d*\n\\Name zpa-d - Periph - Description\n\\Description Description\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n";
// Marker Spaces core: a port of MarkerSpacesPlugin\MarkerSpaceScanner.cs, ProjectScan.cs and the
// chapter cutting of tests\TestHost\FolderBookSource.cs. No papi here: the extension build puts this
// file in front of main.js, and the tests load it with vm.runInThisContext.
//
// .NET and JavaScript regexes differ, so the .NET classes are spelled out:
//   \s  = [\f\n\r\t\v\x85\p{Z}]      \d = \p{Nd}      \w = [\p{L}\p{Mn}\p{Nd}\p{Pc}]
//   char.IsWhiteSpace = [\t-\r\x85\p{Z}]   char.IsPunctuation = \p{P}
// String offsets are UTF-16 code units in both, so they match the C# test host exactly.
var MSCore = (function () {
  'use strict';

  var S = '[\\f\\n\\r\\t\\v\\x85\\p{Z}]';
  var SP = '[\\f\\n\\r\\t\\v\\x85\\p{Z}~]';
  var D = '\\p{Nd}';
  var W = '[\\p{L}\\p{Mn}\\p{Nd}\\p{Pc}]';
  var WHITE_RE = /[\t-\r\x85\p{Z}]/u;
  var PUNCT_RE = /\p{P}/u;

  /** The kinds of problem, in the order of the C# enum (issues with the same start sort by it). */
  var KINDS = [
    'MissingSpaceBeforeOpen', // A
    'SpaceBeforeOpen', // B
    'SpaceBeforeClose', // C
    'MissingSpaceAfterClose', // D
    'SpaceBeforePunctuation', // E
    'SpaceAfterClose', // F
    'MissingSpaceBeforeNoClose',
    'SpaceBeforePipe',
    'Unclosed',
    'UnexpectedClose',
  ];
  var CODES = ['A', 'B', 'C', 'D', 'E', 'F', 'NoCloseSpace', 'WPipe', 'Unclosed', 'Unexpected'];
  var K = {};
  KINDS.forEach(function (name, i) {
    K[name] = i;
  });

  var BOOK_ORDER = (
    'GEN EXO LEV NUM DEU JOS JDG RUT 1SA 2SA 1KI 2KI 1CH 2CH EZR NEH EST JOB PSA PRO ECC SNG ISA JER LAM ' +
    'EZK DAN HOS JOL AMO OBA JON MIC NAM HAB ZEP HAG ZEC MAL MAT MRK LUK JHN ACT ROM 1CO 2CO GAL EPH PHP ' +
    'COL 1TH 2TH 1TI 2TI TIT PHM HEB JAS 1PE 2PE 1JN 2JN 3JN JUD REV TOB JDT ESG WIS SIR BAR LJE S3Y SUS ' +
    'BEL 1MA 2MA 3MA 4MA 1ES 2ES MAN PS2 ODA PSS JSA JDB TBS SST DNT BLT XXA XXB XXC XXD XXE XXF XXG FRT ' +
    'BAK OTH 3ES EZA 5EZ 6EZ INT CNC GLO TDX NDX DAG PS3 2BA LBA JUB ENO 1MQ 2MQ 3MQ REP 4BA LAO'
  ).split(' ');

  /** Books that are not Bible text (ScanOptions.OtherBooks): left out unless the user ticks them. */
  var OTHER_BOOKS = 'FRT BAK OTH INT CNC GLO TDX NDX XXA XXB XXC XXD XXE XXF XXG'.split(' ');

  var DEFAULT_OPTIONS = {
    excludeMarkers: '',
    noCloseMarkers: 'v fk fp fq fqa ft fr xk xo xq',
    noCloseInNoteMarkers: 'xt',
    extraSpacingMarkers: 'f x',
    noSpaceBeforeMarkers: 'f x',
    footnotePrecedesText: false,
    crossReferencesPrecedeText: true,
    /** Codes of the books not examined, space separated; null = the default (OTHER_BOOKS). */
    excludedBooks: null,
  };

  function bookCode(num) {
    return BOOK_ORDER[num - 1];
  }

  function bookNumber(code) {
    return BOOK_ORDER.indexOf(String(code).toUpperCase()) + 1;
  }

  function isBibleBook(code) {
    return OTHER_BOOKS.indexOf(String(code).toUpperCase()) < 0;
  }

  function isExcluded(options, code) {
    if (options.excludedBooks === null || options.excludedBooks === undefined) return !isBibleBook(code);
    return splitWhite(options.excludedBooks).some(function (c) {
      return c.toUpperCase() === String(code).toUpperCase();
    });
  }

  function isWhite(c) {
    return WHITE_RE.test(c);
  }

  /** string.Split((char[])null, RemoveEmptyEntries): split on char.IsWhiteSpace. */
  function splitWhite(s) {
    var out = [];
    var cur = '';
    for (var i = 0; i < s.length; i++) {
      if (isWhite(s[i])) {
        if (cur) out.push(cur);
        cur = '';
      } else cur += s[i];
    }
    if (cur) out.push(cur);
    return out;
  }

  /** string.Trim(): char.IsWhiteSpace at both ends (JavaScript's trim also removes U+FEFF). */
  function csTrim(s) {
    var a = 0;
    var b = s.length;
    while (a < b && isWhite(s[a])) a++;
    while (b > a && isWhite(s[b - 1])) b--;
    return s.substring(a, b);
  }

  /** Regex.Escape, limited to what a 'u' regex accepts as an escape. */
  function esc(s) {
    return s.replace(/[\\^$.*+?()[\]{}|\/#]/g, function (c) {
      return c === '#' ? '#' : '\\' + c;
    });
  }

  // ------------------------------------------------------------ stylesheets

  /**
   * StyleSheets.ParseText: a \Marker line opens an entry; any other \Field line sets that field
   * (name lowercased) on it. Returns a Map in file order.
   */
  function parseSty(text) {
    var entries = new Map();
    var current = null;
    text
      .replace(/\r\n/g, '\n')
      .replace(/\r/g, '\n')
      .split('\n')
      .forEach(function (raw) {
        var line = csTrim(raw);
        if (line.length === 0 || line[0] === '#' || line[0] !== '\\') return;
        var rest = line.substring(1);
        var ws = 0;
        while (ws < rest.length && !isWhite(rest[ws])) ws++;
        var field = rest.substring(0, ws);
        if (field.length === 0) return;
        var value = csTrim(rest.substring(ws));
        if (field === 'Marker') {
          current = entries.get(value);
          if (!current) {
            current = new Map();
            entries.set(value, current);
          }
        } else if (current) current.set(field.toLowerCase(), value);
      });
    return entries;
  }

  /** usfm.sty merged field by field with custom.sty (StyleSheets.Load). */
  function mergeSty(usfm, custom) {
    var markers = new Map();
    usfm.forEach(function (fields, key) {
      markers.set(key, new Map(fields));
    });
    custom.forEach(function (fields, key) {
      var target = markers.get(key);
      if (!target) {
        target = new Map();
        markers.set(key, target);
      }
      fields.forEach(function (v, f) {
        target.set(f, v);
      });
    });
    return markers;
  }

  /** The same table from Paratext 10's StyleInfo (merged usfm.sty + custom.sty). */
  function styFromStyleInfo(styleInfo) {
    var markers = new Map();
    var all = (styleInfo && styleInfo.markers) || {};
    Object.keys(all).forEach(function (key) {
      var info = all[key] || {};
      var fields = new Map();
      if (info.styleType) fields.set('styletype', String(info.styleType));
      if (info.endMarker) fields.set('endmarker', String(info.endMarker));
      markers.set(info.marker || key, fields);
    });
    return markers;
  }

  // ------------------------------------------------------------ scanner

  var TPREFIX_KEEP = ['tl', 'ts-s', 'ts-e'];
  var VERSE_RE = new RegExp('\\\\v' + S + '+(' + D + '+(?:[,-]' + D + '+)*)' + S + '*', 'gu');
  var NEXT_CLOSE_RE = /\\\+?[a-zA-Z][a-zA-Z0-9]*\*/y;
  var NOTE_SPAN_RE = new RegExp('\\\\f' + S + '[\\s\\S]*?\\\\f\\*|\\\\x' + S + '[\\s\\S]*?\\\\x\\*', 'gu');
  var MARKER_SPACE_RE = new RegExp(
    '\\\\\\+?[a-zA-Z][a-zA-Z0-9]*\\*?(?:' + SP + '+' + D + '+(?:[,-]' + D + '+)*)?' + SP + '+',
    'gu',
  );
  var CLOSING_PUNCT = ',.;:!?)]}\u2026\u00BB\u201D\u2019\u203A';

  function names(raw) {
    var list = [];
    splitWhite(raw || '').forEach(function (m) {
      var n = m.replace(/^\\+/, '');
      if (n.length > 0 && list.indexOf(n) < 0) list.push(n);
    });
    return list;
  }

  function isIgnoredTMarker(marker) {
    return marker.toLowerCase().indexOf('t') === 0 && TPREFIX_KEEP.indexOf(marker) < 0;
  }

  function resolveEndmarker(marker, fields) {
    var end = splitWhite((fields && fields.get('endmarker')) || '');
    return end.length > 0 ? end[0] : marker + '*';
  }

  function markerPattern(bare, allNames) {
    var lookahead = '';
    if (allNames) {
      var ext = [];
      allNames.forEach(function (m) {
        if (m !== bare && m.indexOf(bare) === 0) ext.push(esc(m.substring(bare.length)));
      });
      if (ext.length > 0) lookahead = '(?!' + ext.join('|') + ')';
    }
    return '\\\\\\+?' + esc(bare) + lookahead;
  }

  function openMarkerRegex(marker, allNames) {
    return new RegExp(markerPattern(marker, allNames) + '(?!\\*)', 'gu');
  }

  function isPunct(c) {
    return c !== '\\' && PUNCT_RE.test(c);
  }

  function isSpace(c) {
    return isWhite(c) || c === '~';
  }

  function isInlineSpace(c) {
    return c === ' ' || c === '\t' || c === '~';
  }

  function isClosingPunct(c) {
    return CLOSING_PUNCT.indexOf(c) >= 0;
  }

  function contentStartsWithClosingPunct(text, contentStart) {
    var n = text.length;
    var k = contentStart;
    while (k < n && isSpace(text[k])) k++;
    return k < n && isClosingPunct(text[k]);
  }

  function spaceRunStart(text, pos, limit) {
    var k = pos;
    while (k > limit && k > 0 && isSpace(text[k - 1])) k--;
    return k;
  }

  function allMatches(re, text) {
    re.lastIndex = 0;
    var out = [];
    var m;
    while ((m = re.exec(text)) !== null) {
      out.push(m);
      if (m[0].length === 0) re.lastIndex++;
    }
    return out;
  }

  /** First match at or after start (Regex.Match(text, start)). */
  function matchFrom(re, text, start) {
    re.lastIndex = start;
    return re.exec(text);
  }

  /** Match exactly at pos (\G). re must be sticky. */
  function matchAt(re, text, pos) {
    re.lastIndex = pos;
    return re.test(text);
  }

  /**
   * new MarkerSpaceScanner(options, sty). sty is a Map marker -> Map(field -> value), in
   * stylesheet order.
   */
  function Scanner(options, sty) {
    var o = Object.assign({}, DEFAULT_OPTIONS, options || {});
    this.exclude = names(o.excludeMarkers);
    this.noClose = names(o.noCloseMarkers);
    this.noteContext = names(o.noCloseInNoteMarkers);
    this.extraSpacing = names(o.extraSpacingMarkers);
    this.noSpaceBefore = names(o.noSpaceBeforeMarkers);
    this.footnotePrecedes = !!o.footnotePrecedesText;
    if (this.footnotePrecedes) remove(this.noSpaceBefore, 'f');
    this.xrefPrecedes = !!o.crossReferencesPrecedeText;
    if (this.xrefPrecedes) remove(this.noSpaceBefore, 'x');

    var self = this;
    var chars = new Map();
    this.charMarkers = []; // [marker, endmarker] in the CMS check's order
    this.noCloseEnd = [];
    function add(marker, endmarker) {
      chars.set(marker, endmarker);
      self.charMarkers.push([marker, endmarker]);
    }
    sty.forEach(function (fields, key) {
      var st = fields.get('styletype');
      if (st === undefined || csTrim(st).toLowerCase() !== 'character') return;
      if (self.exclude.indexOf(key) >= 0 || self.noClose.indexOf(key) >= 0 || isIgnoredTMarker(key)) return;
      add(key, resolveEndmarker(key, fields));
    });
    this.noteContext.forEach(function (m) {
      if (self.exclude.indexOf(m) >= 0 || isIgnoredTMarker(m)) return;
      if (!chars.has(m)) add(m, resolveEndmarker(m, sty.get(m)));
    });
    this.extraSpacing.forEach(function (m) {
      if (self.exclude.indexOf(m) >= 0 || self.noClose.indexOf(m) >= 0 || self.noteContext.indexOf(m) >= 0) return;
      if (isIgnoredTMarker(m)) return;
      if (!chars.has(m)) add(m, resolveEndmarker(m, sty.get(m)));
    });
    this.noClose.forEach(function (m) {
      if (isIgnoredTMarker(m)) return;
      self.noCloseEnd.push([m, resolveEndmarker(m, sty.get(m))]);
    });

    var all = new Set(sty.keys());
    chars.forEach(function (v, k) {
      all.add(k);
    });
    this.noCloseEnd.forEach(function (kv) {
      all.add(kv[0]);
    });
    [this.exclude, this.noClose, this.noteContext, this.extraSpacing, this.noSpaceBefore].forEach(function (list) {
      list.forEach(function (m) {
        all.add(m);
      });
    });

    this.openRes = new Map();
    this.closeRes = new Map();
    this.charMarkers.forEach(function (kv) {
      self.openRes.set(kv[0], openMarkerRegex(kv[0], all));
      self.closeRes.set(kv[0], new RegExp(markerPattern(kv[1], null), 'gu'));
    });
    this.noCloseRes = new Map();
    this.noCloseOpenRes = new Map();
    this.noCloseEnd.forEach(function (kv) {
      self.noCloseRes.set(kv[0], new RegExp(markerPattern(kv[1], null), 'gu'));
      if (self.exclude.indexOf(kv[0]) < 0) self.noCloseOpenRes.set(kv[0], openMarkerRegex(kv[0], all));
    });
    // \b after each name: the next character is not a word character when the name ends in one.
    this.noSpaceBeforeRe =
      this.noSpaceBefore.length > 0
        ? new RegExp(
            '\\\\\\+?(?:' +
              this.noSpaceBefore
                .map(function (m) {
                  var endsWord = new RegExp(W + '$', 'u').test(m);
                  return esc(m) + (endsWord ? '(?!' + W + ')' : '(?=' + W + ')');
                })
                .join('|') +
              ')',
            'yu',
          )
        : null;
  }

  function remove(list, item) {
    var i = list.indexOf(item);
    if (i >= 0) list.splice(i, 1);
  }

  /** The problems in one chapter, in text order. book = {num, code}. */
  Scanner.prototype.scanChapter = function (book, chapter, text) {
    var self = this;
    var issues = [];
    if (!text) return issues;
    var n = text.length;

    var versePos = allMatches(VERSE_RE, text).map(function (vm) {
      return [vm.index + vm[0].length, vm[1]];
    });
    function verseAt(offset) {
      var label = null;
      for (var i = 0; i < versePos.length; i++) {
        if (versePos[i][0] <= offset) label = versePos[i][1];
        else break;
      }
      return label === null ? '-' : label;
    }
    function make(kind, marker, shown, refPos, start, end) {
      var issue = {
        book: book.code,
        bookNum: book.num,
        chapter: chapter,
        verse: verseAt(refPos),
        kind: kind,
        code: CODES[kind],
        marker: marker,
        shown: shown,
        start: start,
        end: end,
        edits: [],
      };
      issues.push(issue);
      return issue;
    }

    var noteSpans = [];
    if (this.noteContext.length > 0)
      allMatches(NOTE_SPAN_RE, text).forEach(function (m) {
        noteSpans.push([m.index, m.index + m[0].length]);
      });
    var markerSpaceEnds = new Set();
    if (this.noSpaceBefore.length > 0)
      allMatches(MARKER_SPACE_RE, text).forEach(function (m) {
        markerSpaceEnds.add(m.index + m[0].length);
      });

    this.charMarkers.forEach(function (kv) {
      var marker = kv[0];
      var endmarker = kv[1];
      var openRe = self.openRes.get(marker);
      var closeRe = self.closeRes.get(marker);
      var skipInNotes = self.noteContext.indexOf(marker) >= 0;

      var opens = allMatches(openRe, text);
      if (opens.length === 0) return;
      var closes = endmarker.indexOf('\\') < 0 ? allMatches(closeRe, text) : null;
      var ci = 0;
      for (var idx = 0; idx < opens.length; idx++) {
        var m = opens[idx];
        var mEnd = m.index + m[0].length;
        var nextOpen = idx + 1 < opens.length ? opens[idx + 1].index : n;
        var close;
        if (closes) {
          while (ci < closes.length && closes[ci].index < mEnd) ci++;
          close = ci < closes.length ? closes[ci] : null;
        } else close = matchFrom(closeRe, text, mEnd);

        if (!close || close.index >= nextOpen) {
          // \xt inside a footnote or cross-reference needs no closing marker.
          var skip = false;
          if (skipInNotes)
            for (var s = 0; s < noteSpans.length; s++)
              if (noteSpans[s][0] <= m.index && m.index < noteSpans[s][1]) {
                skip = true;
                break;
              }
          if (!skip) make(K.Unclosed, marker, marker, m.index, m.index, mEnd);
          continue;
        }

        var os = m.index;
        var oe = mEnd;
        var cs = close.index;
        var ce = close.index + close[0].length;
        var invertOpen = self.noSpaceBefore.indexOf(marker) >= 0;
        var invertClose = (self.footnotePrecedes && marker === 'f') || (self.xrefPrecedes && marker === 'x');
        self.checkPair(text, marker, endmarker, os, oe, cs, ce, invertOpen, invertClose, markerSpaceEnds, make);

        if (marker === 'w') {
          var pipe = cs > oe ? text.substring(0, cs).indexOf('|', oe) : -1;
          if (pipe > oe && isSpace(text[pipe - 1])) {
            var issue = make(K.SpaceBeforePipe, marker, marker, os, pipe - 1, pipe + 1);
            var k = spaceRunStart(text, pipe, oe + 1);
            if (k < pipe) issue.edits.push(edit(k, pipe - k, ''));
          }
        }
      }
    });

    this.noCloseEnd.forEach(function (kv) {
      allMatches(self.noCloseRes.get(kv[0]), text).forEach(function (m) {
        make(K.UnexpectedClose, kv[0], kv[1], m.index, m.index, m.index + m[0].length);
      });
    });

    this.noCloseOpenRes.forEach(function (re, marker) {
      allMatches(re, text).forEach(function (m) {
        var hs = m.index;
        var he = m.index + m[0].length;
        if (hs === 0) return;
        var before = text[hs - 1];
        if (isSpace(before) || isPunct(before) || contentStartsWithClosingPunct(text, he)) return;
        var issue = make(K.MissingSpaceBeforeNoClose, marker, marker, hs, hs, he);
        issue.edits.push(edit(hs, 0, ' '));
      });
    });

    issues.sort(function (a, b) {
      return a.start !== b.start ? a.start - b.start : a.kind - b.kind;
    });
    return issues;
  };

  /** _check_pair: the spacing around one \marker ... \marker* pair, each problem with its fix. */
  Scanner.prototype.checkPair = function (text, marker, endmarker, os, oe, cs, ce, invertOpen, invertClose, markerSpaceEnds, make) {
    var n = text.length;
    var issue;
    var k;

    if (os > 0) {
      var beforeOpen = text[os - 1];
      if (invertOpen) {
        // B: \f or \x attaches to the word before it, except right after another marker's space.
        if (isSpace(beforeOpen) && !markerSpaceEnds.has(os)) {
          issue = make(K.SpaceBeforeOpen, marker, marker, os, os, oe);
          k = spaceRunStart(text, os, 0);
          issue.edits.push(edit(k, os - k, ''));
        }
      } else if (!isSpace(beforeOpen) && !isPunct(beforeOpen) && !contentStartsWithClosingPunct(text, oe)) {
        issue = make(K.MissingSpaceBeforeOpen, marker, marker, os, os, oe); // A
        issue.edits.push(edit(os, 0, ' '));
      }
    }

    if (cs > 0 && isSpace(text[cs - 1])) {
      // C: the space moves outside the closing marker.
      issue = make(K.SpaceBeforeClose, marker, endmarker, os, cs, ce);
      k = spaceRunStart(text, cs, oe + 1);
      if (k < cs) {
        issue.edits.push(edit(k, cs - k, ''));
        if (!invertClose && this.needsSpaceAfter(text, ce)) issue.edits.push(edit(ce, 0, ' '));
      }
    }

    if (ce < n) {
      var afterClose = text[ce];
      if (isInlineSpace(afterClose)) {
        k = ce;
        while (k < n && isInlineSpace(text[k])) k++;
        if (k < n && isClosingPunct(text[k])) {
          issue = make(K.SpaceBeforePunctuation, marker, endmarker, os, cs, ce); // E
          issue.edits.push(edit(ce, k - ce, ''));
        } else if (invertClose && k < n && !isPunct(text[k])) {
          issue = make(K.SpaceAfterClose, marker, endmarker, os, cs, ce); // F
          issue.edits.push(edit(ce, k - ce, ''));
        }
      } else if (!invertClose && this.needsSpaceAfter(text, ce)) {
        issue = make(K.MissingSpaceAfterClose, marker, endmarker, os, cs, ce); // D
        issue.edits.push(edit(ce, 0, ' '));
      }
    }
  };

  /** Check D's test: the closing marker ending at ce is glued to a word or marker. */
  Scanner.prototype.needsSpaceAfter = function (text, ce) {
    if (ce >= text.length) return false;
    var c = text[ce];
    if (isSpace(c) || isPunct(c)) return false;
    if (c === '\\' && ((this.noSpaceBeforeRe && matchAt(this.noSpaceBeforeRe, text, ce)) || matchAt(NEXT_CLOSE_RE, text, ce)))
      return false;
    return true;
  };

  function edit(start, length, insert) {
    return { start: start, length: length, insert: insert || '' };
  }

  // ------------------------------------------------------------ applying fixes

  /**
   * MarkerSpaceScanner.Apply: the same insertion at the same place is made once, overlapping
   * deletions are joined, and an insertion inside a deleted stretch is dropped.
   */
  function apply(text, edits) {
    var deletes = [];
    var inserts = new Map();
    edits.forEach(function (e) {
      if (e.length > 0) deletes.push([e.start, e.start + e.length]);
      if (e.insert.length > 0) {
        var existing = inserts.get(e.start);
        if (existing === undefined || existing !== e.insert)
          inserts.set(e.start, existing === undefined ? e.insert : existing + e.insert);
      }
    });
    deletes.sort(function (a, b) {
      return a[0] - b[0];
    });
    var merged = [];
    deletes.forEach(function (d) {
      var last = merged[merged.length - 1];
      if (last && d[0] <= last[1]) last[1] = Math.max(last[1], d[1]);
      else merged.push([d[0], d[1]]);
    });

    var out = [];
    var pos = 0;
    var di = 0;
    var points = Array.from(inserts.keys()).sort(function (a, b) {
      return a - b;
    });
    points.push(Infinity);
    for (var p = 0; p < points.length; p++) {
      var at = points[p];
      var stop = Math.min(at, text.length);
      while (pos < stop) {
        while (di < merged.length && merged[di][1] <= pos) di++;
        if (di < merged.length && merged[di][0] <= pos) {
          pos = Math.min(merged[di][1], text.length);
          continue;
        }
        var next = di < merged.length ? Math.min(merged[di][0], stop) : stop;
        out.push(text.substring(pos, next));
        pos = next;
      }
      if (at === Infinity) break;
      var insideDelete = merged.some(function (d) {
        return d[0] < at && at < d[1];
      });
      if (!insideDelete && at <= text.length) out.push(inserts.get(at));
    }
    return out.join('');
  }

  // ------------------------------------------------------------ books and chapters

  var CHAPTER_RE = /\\c[ \t]+(\p{Nd}+)/gu;

  function asciiInt(s) {
    return /^[0-9]+$/.test(s) ? parseInt(s, 10) : NaN;
  }

  /**
   * Chapters as Paratext cuts them (FolderBookSource.ChapterSpans): chapter 1 runs from the start
   * of the book (\id) to the second \c; a book without \c is all chapter 1. Map chapter -> [start, end].
   */
  function chapterSpans(text) {
    var starts = [];
    allMatches(CHAPTER_RE, text).forEach(function (m) {
      var c = asciiInt(m[1]);
      if (!isNaN(c)) starts.push([c, m.index]);
    });
    var spans = new Map();
    if (starts.length === 0) {
      spans.set(1, [0, text.length]);
      return spans;
    }
    for (var i = 0; i < starts.length; i++) {
      var start = i === 0 ? 0 : starts[i][1];
      var end = i + 1 < starts.length ? starts[i + 1][1] : text.length;
      if (!spans.has(starts[i][0])) spans.set(starts[i][0], [start, end]);
    }
    return spans;
  }

  /**
   * ProjectScan.Scan for one book: [{chapter, start, text}] in the order the chapters are scanned
   * (\c order, chapter 1 first when the book has no \c 1; then it is the whole book).
   */
  function bookChapters(bookText) {
    var chapters = [];
    allMatches(CHAPTER_RE, bookText).forEach(function (m) {
      var c = asciiInt(m[1]);
      if (!isNaN(c) && chapters.indexOf(c) < 0) chapters.push(c);
    });
    if (chapters.indexOf(1) < 0) chapters.unshift(1);
    var spans = chapterSpans(bookText);
    var out = [];
    chapters.forEach(function (c) {
      var span = spans.get(c);
      if (span) out.push({ chapter: c, start: span[0], text: bookText.substring(span[0], span[1]) });
      else if (c === 1) out.push({ chapter: 1, start: 0, text: bookText, wholeBook: true });
    });
    return out;
  }

  /** Every problem in one book, each with chapterText set (the text its offsets refer to). */
  function scanBook(scanner, book, bookText) {
    var issues = [];
    if (!bookText) return issues;
    bookChapters(bookText).forEach(function (ch) {
      scanner.scanChapter(book, ch.chapter, ch.text).forEach(function (issue) {
        issue.chapterText = ch.text;
        issue.chapterStart = ch.start;
        issue.wholeBook = !!ch.wholeBook;
        issues.push(issue);
      });
    });
    return issues;
  }

  /** The first verse number of a label ("3-4" -> 3, "-" -> 0). */
  function verseNumber(label) {
    var m = /^[0-9]+/.exec(label || '');
    return m ? parseInt(m[0], 10) : 0;
  }

  // ------------------------------------------------------------ preview

  var DOT = '\u00B7';
  var PILCROW = '\u00B6';
  var ELLIPSIS = '\u2026';
  var PLACEHOLDER = '\u0001';
  var CONTEXT = 25;

  function render(c, removed) {
    if (removed) {
      if (c === '\n') return PILCROW;
      if (c === '\r') return '';
      if (c === ' ' || c === '\t') return DOT;
      return c;
    }
    if (c === '\r') return '';
    return c === '\n' || c === '\t' ? ' ' : c;
  }

  /** ProjectScan.Preview: {now, after}; after is '' for a problem fixed by hand. */
  function preview(issue) {
    var text = issue.chapterText;
    var canFix = issue.edits.length > 0;
    var a = issue.start;
    var b = issue.end;
    if (canFix) {
      a = Math.min.apply(null, issue.edits.map(function (e) { return e.start; }));
      b = Math.max.apply(null, issue.edits.map(function (e) { return e.start + e.length; }));
    }
    var ws = Math.max(0, a - CONTEXT);
    var we = Math.min(text.length, b + CONTEXT);
    var slice = text.substring(ws, we);
    var prefix = ws > 0 ? ELLIPSIS : '';
    var suffix = we < text.length ? ELLIPSIS : '';
    var removed = new Array(slice.length).fill(false);
    issue.edits.forEach(function (e) {
      for (var i = Math.max(e.start, ws); i < Math.min(e.start + e.length, we); i++) removed[i - ws] = true;
    });
    var now = '';
    for (var i = 0; i < slice.length; i++) now += render(slice[i], removed[i]);
    now = prefix + csTrim(now) + suffix;
    if (!canFix) return { now: now, after: '' };
    var fixedSlice = apply(
      slice,
      issue.edits.map(function (e) {
        return edit(e.start - ws, e.length, e.insert.length > 0 ? PLACEHOLDER.repeat(e.insert.length) : '');
      }),
    );
    var after = '';
    for (var j = 0; j < fixedSlice.length; j++)
      after += fixedSlice[j] === PLACEHOLDER ? DOT : render(fixedSlice[j], false);
    return { now: now, after: prefix + csTrim(after) + suffix };
  }

  return {
    KINDS: KINDS,
    CODES: CODES,
    BOOK_ORDER: BOOK_ORDER,
    OTHER_BOOKS: OTHER_BOOKS,
    DEFAULT_OPTIONS: DEFAULT_OPTIONS,
    bookCode: bookCode,
    bookNumber: bookNumber,
    isBibleBook: isBibleBook,
    isExcluded: isExcluded,
    parseSty: parseSty,
    mergeSty: mergeSty,
    styFromStyleInfo: styFromStyleInfo,
    Scanner: Scanner,
    apply: apply,
    chapterSpans: chapterSpans,
    bookChapters: bookChapters,
    scanBook: scanBook,
    verseNumber: verseNumber,
    preview: preview,
  };
})();

const MS_VERSION = "0.1.0";
const MS_WEB_VIEW_HTML = "<!doctype html>\n<html>\n  <head>\n    <meta charset=\"utf-8\" />\n    <style>\n      :root {\n        --ms-bg: #ffffff;\n        --ms-fg: #1f2328;\n        --ms-muted: #59636e;\n        --ms-line: #d0d7de;\n        --ms-head: #f3f5f7;\n        --ms-sel: #dbeafe;\n        --ms-accent: #0b6bcb;\n        --ms-warn: #9a3412;\n        --ms-ok: #166534;\n        --ms-mono: Consolas, 'Cascadia Mono', monospace;\n      }\n      @media (prefers-color-scheme: dark) {\n        :root {\n          --ms-bg: #1e1f22;\n          --ms-fg: #e6e6e6;\n          --ms-muted: #a0a6ad;\n          --ms-line: #3a3d42;\n          --ms-head: #2a2c30;\n          --ms-sel: #1e3a5f;\n          --ms-accent: #6cb6ff;\n          --ms-warn: #fdba74;\n          --ms-ok: #86efac;\n        }\n      }\n      html,\n      body {\n        margin: 0;\n        height: 100%;\n        background: var(--ms-bg);\n        color: var(--ms-fg);\n        font: 13px/1.4 'Segoe UI', system-ui, sans-serif;\n      }\n      body {\n        display: flex;\n        flex-direction: column;\n        padding: 8px 12px;\n        box-sizing: border-box;\n        gap: 6px;\n      }\n      .row {\n        display: flex;\n        flex-wrap: wrap;\n        align-items: center;\n        gap: 8px;\n      }\n      .grow {\n        flex: 1;\n      }\n      button {\n        font: inherit;\n        padding: 3px 10px;\n        border: 1px solid var(--ms-line);\n        background: var(--ms-head);\n        color: var(--ms-fg);\n        border-radius: 4px;\n        cursor: pointer;\n      }\n      button.primary {\n        background: var(--ms-accent);\n        border-color: var(--ms-accent);\n        color: #fff;\n        font-weight: 600;\n      }\n      button:disabled {\n        opacity: 0.5;\n        cursor: default;\n      }\n      select,\n      input[type='text'] {\n        font: inherit;\n        background: var(--ms-bg);\n        color: var(--ms-fg);\n        border: 1px solid var(--ms-line);\n        border-radius: 3px;\n        padding: 2px 4px;\n      }\n      #intro,\n      #status,\n      .hint {\n        color: var(--ms-muted);\n      }\n      #status.busy {\n        color: var(--ms-warn);\n        font-weight: 600;\n      }\n      #tableWrap {\n        flex: 1;\n        overflow: auto;\n        border: 1px solid var(--ms-line);\n        min-height: 120px;\n      }\n      table {\n        border-collapse: collapse;\n        width: 100%;\n      }\n      th,\n      td {\n        border-bottom: 1px solid var(--ms-line);\n        padding: 3px 6px;\n        text-align: left;\n        vertical-align: top;\n      }\n      th {\n        position: sticky;\n        top: 0;\n        background: var(--ms-head);\n        font-weight: 600;\n        z-index: 1;\n      }\n      td.text {\n        font-family: var(--ms-mono);\n        white-space: pre-wrap;\n        word-break: break-word;\n      }\n      td.ref {\n        white-space: nowrap;\n      }\n      tr:hover td {\n        background: var(--ms-sel);\n      }\n      .byhand {\n        color: var(--ms-muted);\n        font-style: italic;\n      }\n      #results {\n        max-height: 110px;\n        overflow: auto;\n        white-space: pre-wrap;\n        border: 1px solid var(--ms-line);\n        padding: 4px 6px;\n        font-size: 12px;\n      }\n      #results.ok {\n        color: var(--ms-ok);\n      }\n      .panel {\n        border: 1px solid var(--ms-line);\n        background: var(--ms-head);\n        padding: 8px;\n        border-radius: 4px;\n      }\n      .panel label.field {\n        display: grid;\n        grid-template-columns: minmax(200px, 45%) 1fr;\n        gap: 8px;\n        align-items: center;\n        margin: 3px 0;\n      }\n      .overlay {\n        position: fixed;\n        inset: 0;\n        background: rgba(0, 0, 0, 0.35);\n        display: none;\n        align-items: center;\n        justify-content: center;\n        z-index: 10;\n      }\n      .overlay.show {\n        display: flex;\n      }\n      .dialog {\n        background: var(--ms-bg);\n        border: 1px solid var(--ms-line);\n        border-radius: 6px;\n        padding: 14px;\n        max-width: 640px;\n        width: calc(100% - 40px);\n        max-height: calc(100% - 40px);\n        overflow: auto;\n        box-shadow: 0 6px 24px rgba(0, 0, 0, 0.3);\n      }\n      .dialog h3 {\n        margin: 0 0 8px;\n      }\n      #bookGrid {\n        display: grid;\n        grid-template-columns: repeat(auto-fill, minmax(70px, 1fr));\n        gap: 2px 8px;\n        margin: 8px 0;\n        font-family: var(--ms-mono);\n      }\n      .hidden {\n        display: none !important;\n      }\n    </style>\n  </head>\n  <body>\n    <div class=\"row\">\n      <strong id=\"project\"></strong>\n      <span class=\"grow\"></span>\n      <button id=\"booksBtn\" type=\"button\"></button>\n      <button id=\"optionsBtn\" type=\"button\"></button>\n      <button id=\"rescanBtn\" type=\"button\"></button>\n    </div>\n    <div id=\"intro\"></div>\n\n    <div id=\"optionsPanel\" class=\"panel hidden\">\n      <label class=\"field\"><span id=\"lExclude\"></span><input type=\"text\" id=\"oExclude\" /></label>\n      <label class=\"field\"><span id=\"lNoClose\"></span><input type=\"text\" id=\"oNoClose\" /></label>\n      <label class=\"field\"><span id=\"lNoCloseInNote\"></span><input type=\"text\" id=\"oNoCloseInNote\" /></label>\n      <label class=\"field\"><span id=\"lExtra\"></span><input type=\"text\" id=\"oExtra\" /></label>\n      <label class=\"field\"><span id=\"lNoSpaceBefore\"></span><input type=\"text\" id=\"oNoSpaceBefore\" /></label>\n      <div class=\"row\">\n        <label><input type=\"checkbox\" id=\"oFootnote\" /> <span id=\"lFootnote\"></span></label>\n        <label><input type=\"checkbox\" id=\"oXref\" /> <span id=\"lXref\"></span></label>\n      </div>\n      <div class=\"hint\" id=\"optionsHint\"></div>\n      <div class=\"row\" style=\"margin-top: 6px\">\n        <button id=\"saveOptionsBtn\" type=\"button\" class=\"primary\"></button>\n        <button id=\"defaultsBtn\" type=\"button\"></button>\n      </div>\n    </div>\n\n    <div class=\"row\">\n      <label><span id=\"lKind\"></span> <select id=\"kindFilter\"></select></label>\n      <label><span id=\"lMarker\"></span> <select id=\"markerFilter\"></select></label>\n      <label><input type=\"checkbox\" id=\"showByHand\" /> <span id=\"lShowByHand\"></span></label>\n    </div>\n    <div id=\"status\"></div>\n    <div id=\"tableWrap\">\n      <table>\n        <thead>\n          <tr>\n            <th style=\"width: 3em\" id=\"hFix\"></th>\n            <th id=\"hRef\"></th>\n            <th id=\"hProblem\"></th>\n            <th id=\"hNow\"></th>\n            <th id=\"hAfter\"></th>\n          </tr>\n        </thead>\n        <tbody id=\"rows\"></tbody>\n      </table>\n    </div>\n    <div class=\"row\">\n      <button id=\"tickBtn\" type=\"button\"></button>\n      <button id=\"untickBtn\" type=\"button\"></button>\n      <span class=\"grow hint\" id=\"goToHint\"></span>\n      <button id=\"fixBtn\" type=\"button\" class=\"primary\"></button>\n    </div>\n    <div id=\"results\"></div>\n\n    <div class=\"overlay\" id=\"confirmOverlay\">\n      <div class=\"dialog\">\n        <h3 id=\"confirmTitle\"></h3>\n        <div id=\"confirmText\" style=\"white-space: pre-wrap\"></div>\n        <div class=\"row\" style=\"margin-top: 12px; justify-content: flex-end\">\n          <button id=\"confirmYes\" type=\"button\" class=\"primary\"></button>\n          <button id=\"confirmNo\" type=\"button\"></button>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"overlay\" id=\"booksOverlay\">\n      <div class=\"dialog\">\n        <h3 id=\"booksTitle\"></h3>\n        <div class=\"hint\" id=\"booksIntro\"></div>\n        <div class=\"row\" style=\"margin-top: 6px\" id=\"bookQuick\"></div>\n        <div id=\"bookGrid\"></div>\n        <div class=\"hint\" id=\"booksError\"></div>\n        <div class=\"row\" style=\"justify-content: flex-end\">\n          <button id=\"booksOk\" type=\"button\" class=\"primary\"></button>\n          <button id=\"booksCancel\" type=\"button\"></button>\n        </div>\n      </div>\n    </div>\n\n    <script>\n      const BOOT = __MS_BOOT__;\n      const papi = require('@papi/frontend');\n      const { logger } = require('@papi/frontend');\n\n      const DOT = '\u00b7';\n      const MAX_ROWS = 3000;\n\n      const T = {\n        en: {\n          intro:\n            'These are the spacing problems found around markers. Tick the ones to fix, then click Fix. The \"After fix\" column shows the change; a dot (' +\n            DOT +\n            ') marks a space that is removed or added. Double-click a row to go to the verse.',\n          project: 'Project: {0}',\n          scanning: 'Scanning...',\n          fixing: 'Fixing...',\n          optionsShow: 'Options...',\n          optionsHide: 'Hide options',\n          optExclude: 'Marker codes to exclude',\n          optNoClose: 'Markers that do not require a closing marker',\n          optNoCloseInNote: 'Markers that do not require a closing marker only inside a footnote/cross-reference',\n          optExtra: 'Extra markers to check for spacing',\n          optNoSpaceBefore: 'Markers that should have NO space before them',\n          optFootnote: 'Footnote precedes text',\n          optXref: 'Cross-references occur before word',\n          optionsHint:\n            'Marker codes are separated by spaces, without backslashes (for example: w rq). The options are saved for this project.',\n          saveRescan: 'Save options and scan again',\n          defaults: 'Restore defaults',\n          kind: 'Problem:',\n          marker: 'Marker:',\n          all: '(all)',\n          showByHand: 'Also show problems that must be fixed by hand (unclosed or unexpected closing markers)',\n          counts: '{0} problem(s) shown, {1} can be fixed, {2} ticked in all.',\n          tooMany: 'Only the first {0} are listed; use the filters to see the others.',\n          noProblems: 'No marker spacing problems were found.',\n          colFix: 'Fix',\n          colRef: 'Reference',\n          colProblem: 'Problem',\n          colNow: 'Now',\n          colAfter: 'After fix',\n          byHand: '(fix by hand)',\n          goToHint: 'Double-click a row to go to the verse.',\n          tickShown: 'Tick all shown',\n          untickShown: 'Untick all shown',\n          fix: 'Fix ticked problems ({0})',\n          rescan: 'Scan again',\n          nothingTicked: 'Tick at least one problem to fix.',\n          confirmTitle: 'Fix marker spaces',\n          confirm:\n            'Fix {0} problem(s) in {1} book(s)?\\n\\nA copy of each book is kept before it is changed (in the extension\\'s own storage).',\n          yes: 'Fix',\n          cancel: 'Cancel',\n          ok: 'OK',\n          resFixed: '{0}: {1} problem(s) fixed',\n          resTotal: 'Fixed: {0} problem(s) in {1} book(s).',\n          resNothing: 'Nothing was changed.',\n          resNoPermission: 'Not changed, because you do not have permission to edit this project.',\n          resChanged: 'Not changed, because the text changed after the scan (scan again, then try again): {0}',\n          resFailed: 'Could not change: {0}',\n          resBackups: '{0} backup(s) kept.',\n          noPermissionProject: 'You do not have permission to edit this project, so these problems cannot be fixed here.',\n          readFailed: 'Could not read: {0}',\n          error: 'Marker Spaces could not finish: {0}',\n          booksButton: 'Books: {0} of {1}...',\n          booksTitle: 'Books to examine',\n          booksIntro: 'Tick the books to examine. Unticked books are not read at all. The choice is saved for this project.',\n          booksAll: 'All',\n          booksNone: 'None',\n          booksBible: 'Bible books',\n          booksOT: 'Old Testament',\n          booksNT: 'New Testament',\n          booksDC: 'Deuterocanon',\n          booksOther: 'Other books',\n          booksNoneChosen: 'Tick at least one book.',\n          kinds: [\n            'Missing space before an opening marker',\n            'Space before \\\\f or \\\\x',\n            'Space before a closing marker',\n            'Missing space after a closing marker',\n            'Space before punctuation after a closing marker',\n            'Space after a closing marker (note precedes text)',\n            'Missing space before \\\\v, \\\\ft, \\\\fr, ...',\n            'Space before | in \\\\w',\n            'Unclosed marker',\n            'Unexpected closing marker',\n          ],\n          messages: [\n            'Missing space before \\\\{0}',\n            'Unwanted space before \\\\{0}',\n            'Unwanted space before \\\\{0}',\n            'Missing space after \\\\{0}',\n            'Unwanted space before punctuation after \\\\{0}',\n            'Unwanted space after \\\\{0} (precedes text)',\n            'Missing space before \\\\{0}',\n            'Unwanted space before | in \\\\w...\\\\w* (produces a double space)',\n            'Unclosed \\\\{0} (no matching \\\\{0}* found)',\n            'Unexpected \\\\{0} (\\\\{1} is not normally closed)',\n          ],\n        },\n        es: {\n          intro:\n            'Estos son los problemas de espaciado encontrados alrededor de los marcadores. Marque los que desea corregir y haga clic en Corregir. La columna \"Despu\u00e9s\" muestra el cambio; un punto (' +\n            DOT +\n            ') indica un espacio que se quita o se agrega. Haga doble clic en una fila para ir al vers\u00edculo.',\n          project: 'Proyecto: {0}',\n          scanning: 'Revisando...',\n          fixing: 'Corrigiendo...',\n          optionsShow: 'Opciones...',\n          optionsHide: 'Ocultar opciones',\n          optExclude: 'C\u00f3digos de marcador a excluir',\n          optNoClose: 'Marcadores que no requieren un marcador de cierre',\n          optNoCloseInNote:\n            'Marcadores que no requieren un marcador de cierre solo dentro de una nota al pie/referencia cruzada',\n          optExtra: 'Marcadores adicionales para verificar el espaciado',\n          optNoSpaceBefore: 'Marcadores que NO deben tener espacio antes',\n          optFootnote: 'La nota precede al texto',\n          optXref: 'Las referencias cruzadas ocurren antes de la palabra',\n          optionsHint:\n            'Los c\u00f3digos de marcador se separan con espacios, sin barra invertida (por ejemplo: w rq). Las opciones se guardan para este proyecto.',\n          saveRescan: 'Guardar opciones y revisar de nuevo',\n          defaults: 'Restaurar valores predeterminados',\n          kind: 'Problema:',\n          marker: 'Marcador:',\n          all: '(todos)',\n          showByHand:\n            'Mostrar tambi\u00e9n los problemas que hay que corregir a mano (marcadores sin cerrar o cierres inesperados)',\n          counts: '{0} problema(s) mostrado(s), {1} se pueden corregir, {2} marcado(s) en total.',\n          tooMany: 'Solo se muestran los primeros {0}; use los filtros para ver los dem\u00e1s.',\n          noProblems: 'No se encontraron problemas de espaciado en los marcadores.',\n          colFix: 'Corregir',\n          colRef: 'Referencia',\n          colProblem: 'Problema',\n          colNow: 'Ahora',\n          colAfter: 'Despu\u00e9s',\n          byHand: '(corregir a mano)',\n          goToHint: 'Haga doble clic en una fila para ir al vers\u00edculo.',\n          tickShown: 'Marcar todos los mostrados',\n          untickShown: 'Desmarcar todos los mostrados',\n          fix: 'Corregir los problemas marcados ({0})',\n          rescan: 'Revisar de nuevo',\n          nothingTicked: 'Marque al menos un problema para corregir.',\n          confirmTitle: 'Corregir espacios de marcadores',\n          confirm:\n            '\u00bfCorregir {0} problema(s) en {1} libro(s)?\\n\\nAntes de cambiar cada libro se guarda una copia (en el almacenamiento propio de la extensi\u00f3n).',\n          yes: 'Corregir',\n          cancel: 'Cancelar',\n          ok: 'Aceptar',\n          resFixed: '{0}: {1} problema(s) corregido(s)',\n          resTotal: 'Corregido: {0} problema(s) en {1} libro(s).',\n          resNothing: 'No se cambi\u00f3 nada.',\n          resNoPermission: 'No se cambiaron, porque usted no tiene permiso para editar este proyecto.',\n          resChanged:\n            'No se cambiaron, porque el texto cambi\u00f3 despu\u00e9s de la revisi\u00f3n (revise de nuevo y vuelva a intentarlo): {0}',\n          resFailed: 'No se pudo cambiar: {0}',\n          resBackups: 'Se guardaron {0} copia(s) de seguridad.',\n          noPermissionProject:\n            'Usted no tiene permiso para editar este proyecto, as\u00ed que estos problemas no se pueden corregir aqu\u00ed.',\n          readFailed: 'No se pudo leer: {0}',\n          error: 'Espacios de marcadores no pudo terminar: {0}',\n          booksButton: 'Libros: {0} de {1}...',\n          booksTitle: 'Libros a revisar',\n          booksIntro:\n            'Marque los libros que desea revisar. Los libros sin marcar no se leen. La selecci\u00f3n se guarda para este proyecto.',\n          booksAll: 'Todos',\n          booksNone: 'Ninguno',\n          booksBible: 'Libros de la Biblia',\n          booksOT: 'Antiguo Testamento',\n          booksNT: 'Nuevo Testamento',\n          booksDC: 'Deuterocan\u00f3nicos',\n          booksOther: 'Otros libros',\n          booksNoneChosen: 'Marque al menos un libro.',\n          kinds: [\n            'Falta espacio antes de un marcador de apertura',\n            'Espacio antes de \\\\f o \\\\x',\n            'Espacio antes de un marcador de cierre',\n            'Falta espacio despu\u00e9s de un marcador de cierre',\n            'Espacio antes de puntuaci\u00f3n despu\u00e9s de un marcador de cierre',\n            'Espacio despu\u00e9s de un marcador de cierre (la nota precede al texto)',\n            'Falta espacio antes de \\\\v, \\\\ft, \\\\fr, ...',\n            'Espacio antes de | en \\\\w',\n            'Marcador sin cerrar',\n            'Marcador de cierre inesperado',\n          ],\n          messages: [\n            'Falta espacio antes de \\\\{0}',\n            'Espacio no deseado antes de \\\\{0}',\n            'Espacio no deseado antes de \\\\{0}',\n            'Falta espacio despu\u00e9s de \\\\{0}',\n            'Espacio no deseado antes de la puntuaci\u00f3n despu\u00e9s de \\\\{0}',\n            'Espacio no deseado despu\u00e9s de \\\\{0} (precede al texto)',\n            'Falta espacio antes de \\\\{0}',\n            'Espacio no deseado antes de | en \\\\w...\\\\w* (produce un espacio doble)',\n            '\\\\{0} sin cerrar (no se encontr\u00f3 \\\\{0}*)',\n            '\\\\{0} inesperado (\\\\{1} normalmente no se cierra)',\n          ],\n        },\n        fr: {\n          intro:\n            'Voici les probl\u00e8mes d\u2019espacement trouv\u00e9s autour des marqueurs. Cochez ceux \u00e0 corriger, puis cliquez sur Corriger. La colonne \u00ab Apr\u00e8s correction \u00bb montre le changement ; un point (' +\n            DOT +\n            ') indique une espace supprim\u00e9e ou ajout\u00e9e. Double-cliquez sur une ligne pour aller au verset.',\n          project: 'Projet : {0}',\n          scanning: 'Analyse...',\n          fixing: 'Correction...',\n          optionsShow: 'Options...',\n          optionsHide: 'Masquer les options',\n          optExclude: 'Codes de marqueurs \u00e0 exclure',\n          optNoClose: 'Marqueurs qui n\u2019exigent pas de marqueur de fermeture',\n          optNoCloseInNote:\n            'Marqueurs qui n\u2019exigent pas de marqueur de fermeture seulement dans une note de bas de page/r\u00e9f\u00e9rence crois\u00e9e',\n          optExtra: 'Autres marqueurs dont l\u2019espacement est \u00e0 v\u00e9rifier',\n          optNoSpaceBefore: 'Marqueurs qui ne doivent PAS \u00eatre pr\u00e9c\u00e9d\u00e9s d\u2019une espace',\n          optFootnote: 'La note pr\u00e9c\u00e8de le texte',\n          optXref: 'Les r\u00e9f\u00e9rences crois\u00e9es se trouvent avant le mot',\n          optionsHint:\n            'Les codes de marqueurs sont s\u00e9par\u00e9s par des espaces, sans barre oblique inverse (par exemple : w rq). Les options sont enregistr\u00e9es pour ce projet.',\n          saveRescan: 'Enregistrer les options et analyser de nouveau',\n          defaults: 'R\u00e9tablir les valeurs par d\u00e9faut',\n          kind: 'Probl\u00e8me :',\n          marker: 'Marqueur :',\n          all: '(tous)',\n          showByHand:\n            'Afficher aussi les probl\u00e8mes \u00e0 corriger \u00e0 la main (marqueurs non ferm\u00e9s ou fermetures inattendues)',\n          counts: '{0} probl\u00e8me(s) affich\u00e9(s), {1} corrigeable(s), {2} coch\u00e9(s) au total.',\n          tooMany: 'Seuls les {0} premiers sont list\u00e9s ; utilisez les filtres pour voir les autres.',\n          noProblems: 'Aucun probl\u00e8me d\u2019espacement autour des marqueurs n\u2019a \u00e9t\u00e9 trouv\u00e9.',\n          colFix: 'Corriger',\n          colRef: 'R\u00e9f\u00e9rence',\n          colProblem: 'Probl\u00e8me',\n          colNow: 'Actuel',\n          colAfter: 'Apr\u00e8s correction',\n          byHand: '(\u00e0 corriger \u00e0 la main)',\n          goToHint: 'Double-cliquez sur une ligne pour aller au verset.',\n          tickShown: 'Cocher toutes les lignes affich\u00e9es',\n          untickShown: 'D\u00e9cocher toutes les lignes affich\u00e9es',\n          fix: 'Corriger les probl\u00e8mes coch\u00e9s ({0})',\n          rescan: 'Analyser de nouveau',\n          nothingTicked: 'Cochez au moins un probl\u00e8me \u00e0 corriger.',\n          confirmTitle: 'Corriger les espaces autour des marqueurs',\n          confirm:\n            'Corriger {0} probl\u00e8me(s) dans {1} livre(s) ?\\n\\nUne copie de chaque livre est conserv\u00e9e avant sa modification (dans le stockage propre de l\u2019extension).',\n          yes: 'Corriger',\n          cancel: 'Annuler',\n          ok: 'OK',\n          resFixed: '{0} : {1} probl\u00e8me(s) corrig\u00e9(s)',\n          resTotal: 'Corrig\u00e9 : {0} probl\u00e8me(s) dans {1} livre(s).',\n          resNothing: 'Rien n\u2019a \u00e9t\u00e9 chang\u00e9.',\n          resNoPermission: 'Non chang\u00e9, car vous n\u2019avez pas l\u2019autorisation de modifier ce projet.',\n          resChanged:\n            'Non chang\u00e9, car le texte a chang\u00e9 apr\u00e8s l\u2019analyse (analysez de nouveau, puis r\u00e9essayez) : {0}',\n          resFailed: 'Impossible de changer : {0}',\n          resBackups: '{0} copie(s) de sauvegarde conserv\u00e9e(s).',\n          noPermissionProject:\n            'Vous n\u2019avez pas l\u2019autorisation de modifier ce projet, donc ces probl\u00e8mes ne peuvent pas \u00eatre corrig\u00e9s ici.',\n          readFailed: 'Impossible de lire : {0}',\n          error: 'Espaces autour des marqueurs n\u2019a pas pu terminer : {0}',\n          booksButton: 'Livres : {0} sur {1}...',\n          booksTitle: 'Livres \u00e0 analyser',\n          booksIntro:\n            'Cochez les livres \u00e0 analyser. Les livres non coch\u00e9s ne sont pas lus du tout. Le choix est enregistr\u00e9 pour ce projet.',\n          booksAll: 'Tous',\n          booksNone: 'Aucun',\n          booksBible: 'Livres de la Bible',\n          booksOT: 'Ancien Testament',\n          booksNT: 'Nouveau Testament',\n          booksDC: 'Deut\u00e9rocanoniques',\n          booksOther: 'Autres livres',\n          booksNoneChosen: 'Cochez au moins un livre.',\n          kinds: [\n            'Espace manquante avant un marqueur d\u2019ouverture',\n            'Espace avant \\\\f ou \\\\x',\n            'Espace avant un marqueur de fermeture',\n            'Espace manquante apr\u00e8s un marqueur de fermeture',\n            'Espace avant la ponctuation apr\u00e8s un marqueur de fermeture',\n            'Espace apr\u00e8s un marqueur de fermeture (la note pr\u00e9c\u00e8de le texte)',\n            'Espace manquante avant \\\\v, \\\\ft, \\\\fr, ...',\n            'Espace avant | dans \\\\w',\n            'Marqueur non ferm\u00e9',\n            'Marqueur de fermeture inattendu',\n          ],\n          messages: [\n            'Espace manquante avant \\\\{0}',\n            'Espace superflue avant \\\\{0}',\n            'Espace superflue avant \\\\{0}',\n            'Espace manquante apr\u00e8s \\\\{0}',\n            'Espace superflue avant la ponctuation apr\u00e8s \\\\{0}',\n            'Espace superflue apr\u00e8s \\\\{0} (pr\u00e9c\u00e8de le texte)',\n            'Espace manquante avant \\\\{0}',\n            'Espace superflue avant | dans \\\\w...\\\\w* (produit une double espace)',\n            '\\\\{0} non ferm\u00e9 (aucun \\\\{0}* correspondant)',\n            '\\\\{0} inattendu (\\\\{1} n\u2019est normalement pas ferm\u00e9)',\n          ],\n        },\n      };\n      const S = T[BOOT.lang] || T.en;\n      const REPORT_ONLY = [8, 9];\n      const OT_END = 39;\n      const NT_END = 66;\n\n      function fmt(s, ...args) {\n        return s.replace(/\\{(\\d+)\\}/g, (m, i) => (args[+i] !== undefined ? String(args[+i]) : m));\n      }\n      const $ = (id) => document.getElementById(id);\n\n      let state = null; // last scan result\n      const ticked = new Set();\n      let optionsOpen = false;\n      let busy = false;\n\n      function setText() {\n        $('intro').textContent = S.intro;\n        $('lExclude').textContent = S.optExclude;\n        $('lNoClose').textContent = S.optNoClose;\n        $('lNoCloseInNote').textContent = S.optNoCloseInNote;\n        $('lExtra').textContent = S.optExtra;\n        $('lNoSpaceBefore').textContent = S.optNoSpaceBefore;\n        $('lFootnote').textContent = S.optFootnote;\n        $('lXref').textContent = S.optXref;\n        $('optionsHint').textContent = S.optionsHint;\n        $('saveOptionsBtn').textContent = S.saveRescan;\n        $('defaultsBtn').textContent = S.defaults;\n        $('lKind').textContent = S.kind;\n        $('lMarker').textContent = S.marker;\n        $('lShowByHand').textContent = S.showByHand;\n        $('hFix').textContent = S.colFix;\n        $('hRef').textContent = S.colRef;\n        $('hProblem').textContent = S.colProblem;\n        $('hNow').textContent = S.colNow;\n        $('hAfter').textContent = S.colAfter;\n        $('tickBtn').textContent = S.tickShown;\n        $('untickBtn').textContent = S.untickShown;\n        $('goToHint').textContent = S.goToHint;\n        $('rescanBtn').textContent = S.rescan;\n        $('optionsBtn').textContent = S.optionsShow;\n        $('confirmTitle').textContent = S.confirmTitle;\n        $('confirmYes').textContent = S.yes;\n        $('confirmNo').textContent = S.cancel;\n        $('booksTitle').textContent = S.booksTitle;\n        $('booksIntro').textContent = S.booksIntro;\n        $('booksOk').textContent = S.ok;\n        $('booksCancel').textContent = S.cancel;\n        $('project').textContent = fmt(S.project, BOOT.projectId);\n        updateFixButton();\n      }\n\n      function setBusy(on, text) {\n        busy = on;\n        $('status').className = on ? 'busy' : '';\n        if (text !== undefined) $('status').textContent = text;\n        ['rescanBtn', 'booksBtn', 'saveOptionsBtn', 'defaultsBtn', 'tickBtn', 'untickBtn'].forEach((id) => {\n          $(id).disabled = on;\n        });\n        updateFixButton();\n      }\n\n      function canFixRow(r) {\n        return r.canFix && state && state.canEdit;\n      }\n\n      function shownRows() {\n        if (!state) return [];\n        const kind = $('kindFilter').value;\n        const marker = $('markerFilter').value;\n        const byHand = $('showByHand').checked;\n        return state.rows.filter(\n          (r) =>\n            (byHand || REPORT_ONLY.indexOf(r.kind) < 0) &&\n            (kind === '' || String(r.kind) === kind) &&\n            (marker === '' || r.marker === marker),\n        );\n      }\n\n      function fillFilters() {\n        const kindSel = $('kindFilter');\n        const markerSel = $('markerFilter');\n        const keepKind = kindSel.value;\n        const keepMarker = markerSel.value;\n        const byHand = $('showByHand').checked;\n        const kinds = new Map();\n        const markers = new Map();\n        state.rows.forEach((r) => {\n          if (!byHand && REPORT_ONLY.indexOf(r.kind) >= 0) return;\n          kinds.set(r.kind, (kinds.get(r.kind) || 0) + 1);\n          markers.set(r.marker, (markers.get(r.marker) || 0) + 1);\n        });\n        kindSel.innerHTML = '';\n        markerSel.innerHTML = '';\n        kindSel.add(new Option(S.all, ''));\n        markerSel.add(new Option(S.all, ''));\n        Array.from(kinds.keys())\n          .sort((a, b) => a - b)\n          .forEach((k) => kindSel.add(new Option(`${S.kinds[k]} (${kinds.get(k)})`, String(k))));\n        Array.from(markers.keys())\n          .sort()\n          .forEach((m) => markerSel.add(new Option(`\\\\${m} (${markers.get(m)})`, m)));\n        kindSel.value = Array.from(kindSel.options).some((o) => o.value === keepKind) ? keepKind : '';\n        markerSel.value = Array.from(markerSel.options).some((o) => o.value === keepMarker) ? keepMarker : '';\n      }\n\n      function message(r) {\n        return fmt(S.messages[r.kind], r.shown, r.marker);\n      }\n\n      function renderRows() {\n        const body = $('rows');\n        body.innerHTML = '';\n        if (!state) return;\n        const rows = shownRows();\n        const frag = document.createDocumentFragment();\n        rows.slice(0, MAX_ROWS).forEach((r) => {\n          const tr = document.createElement('tr');\n          tr.dataset.id = r.id;\n          const tdBox = document.createElement('td');\n          if (canFixRow(r)) {\n            const box = document.createElement('input');\n            box.type = 'checkbox';\n            box.checked = ticked.has(r.id);\n            box.addEventListener('change', () => {\n              if (box.checked) ticked.add(r.id);\n              else ticked.delete(r.id);\n              updateCounts();\n            });\n            tdBox.appendChild(box);\n          }\n          tr.appendChild(tdBox);\n          const cells = [\n            [`${r.book} ${r.chapter}:${r.verse}`, 'ref'],\n            [message(r), ''],\n            [r.now, 'text'],\n            [r.canFix ? r.after : S.byHand, r.canFix ? 'text' : 'byhand'],\n          ];\n          cells.forEach(([text, cls]) => {\n            const td = document.createElement('td');\n            if (cls) td.className = cls;\n            td.textContent = text;\n            tr.appendChild(td);\n          });\n          tr.addEventListener('dblclick', () => {\n            papi.commands\n              .sendCommand('markerSpaces.goTo', BOOT.projectId, r.book, r.chapter, r.verse)\n              .catch((e) => logger.warn(`Marker Spaces go to failed: ${e}`));\n          });\n          frag.appendChild(tr);\n        });\n        body.appendChild(frag);\n        updateCounts();\n      }\n\n      function updateCounts() {\n        if (!state) return;\n        const rows = shownRows();\n        let text;\n        if (state.rows.length === 0) text = S.noProblems;\n        else {\n          text = fmt(S.counts, rows.length, rows.filter(canFixRow).length, ticked.size);\n          if (rows.length > MAX_ROWS) text += ' ' + fmt(S.tooMany, MAX_ROWS);\n          if (!state.canEdit) text += ' ' + S.noPermissionProject;\n        }\n        if (state.failed && state.failed.length) text += ' ' + fmt(S.readFailed, state.failed.join('; '));\n        $('status').textContent = text;\n        updateFixButton();\n      }\n\n      function updateFixButton() {\n        $('fixBtn').textContent = fmt(S.fix, ticked.size);\n        $('fixBtn').disabled = busy || ticked.size === 0;\n      }\n\n      function fillOptions(o) {\n        $('oExclude').value = o.excludeMarkers || '';\n        $('oNoClose').value = o.noCloseMarkers || '';\n        $('oNoCloseInNote').value = o.noCloseInNoteMarkers || '';\n        $('oExtra').value = o.extraSpacingMarkers || '';\n        $('oNoSpaceBefore').value = o.noSpaceBeforeMarkers || '';\n        $('oFootnote').checked = !!o.footnotePrecedesText;\n        $('oXref').checked = !!o.crossReferencesPrecedeText;\n      }\n\n      function readOptions() {\n        return Object.assign({}, state.options, {\n          excludeMarkers: $('oExclude').value.trim(),\n          noCloseMarkers: $('oNoClose').value.trim(),\n          noCloseInNoteMarkers: $('oNoCloseInNote').value.trim(),\n          extraSpacingMarkers: $('oExtra').value.trim(),\n          noSpaceBeforeMarkers: $('oNoSpaceBefore').value.trim(),\n          footnotePrecedesText: $('oFootnote').checked,\n          crossReferencesPrecedeText: $('oXref').checked,\n        });\n      }\n\n      async function scan() {\n        setBusy(true, S.scanning);\n        $('rows').innerHTML = '';\n        try {\n          state = await papi.commands.sendCommand('markerSpaces.scan', BOOT.projectId);\n          ticked.clear();\n          $('project').textContent = fmt(S.project, state.projectName);\n          const chosen = state.books.filter((b) => b.chosen).length;\n          $('booksBtn').textContent = fmt(S.booksButton, chosen, state.books.length);\n          fillOptions(state.options);\n          fillFilters();\n          setBusy(false);\n          renderRows();\n        } catch (e) {\n          setBusy(false, fmt(S.error, e && e.message ? e.message : e));\n        }\n      }\n\n      async function saveOptions(options) {\n        setBusy(true, S.scanning);\n        try {\n          await papi.commands.sendCommand('markerSpaces.saveOptions', BOOT.projectId, options);\n        } catch (e) {\n          setBusy(false, fmt(S.error, e && e.message ? e.message : e));\n          return;\n        }\n        await scan();\n      }\n\n      // ---------------------------------------------------------------- fixing\n\n      function askFix() {\n        if (ticked.size === 0) {\n          $('results').textContent = S.nothingTicked;\n          return;\n        }\n        const books = new Set(state.rows.filter((r) => ticked.has(r.id)).map((r) => r.book));\n        $('confirmText').textContent = fmt(S.confirm, ticked.size, books.size);\n        $('confirmOverlay').classList.add('show');\n        $('confirmYes').focus();\n      }\n\n      async function doFix() {\n        $('confirmOverlay').classList.remove('show');\n        setBusy(true, S.fixing);\n        let report;\n        try {\n          report = await papi.commands.sendCommand('markerSpaces.fix', BOOT.projectId, Array.from(ticked));\n        } catch (e) {\n          setBusy(false);\n          $('results').className = '';\n          $('results').textContent = fmt(S.error, e && e.message ? e.message : e);\n          return;\n        }\n        const lines = [];\n        if (report.noPermission) lines.push(S.resNoPermission);\n        report.fixed.forEach((f) => lines.push(fmt(S.resFixed, f.book, f.count)));\n        if (report.total > 0) lines.push(fmt(S.resTotal, report.total, report.booksChanged));\n        else if (!report.noPermission) lines.push(S.resNothing);\n        if (report.changed.length) lines.push(fmt(S.resChanged, report.changed.join(', ')));\n        if (report.failed.length) lines.push(fmt(S.resFailed, report.failed.join('; ')));\n        if (report.backups.length) lines.push(fmt(S.resBackups, report.backups.length));\n        $('results').className = report.total > 0 && !report.failed.length ? 'ok' : '';\n        $('results').textContent = lines.join('\\n');\n        await scan();\n      }\n\n      // ---------------------------------------------------------------- books\n\n      let bookChoice = null;\n      function openBooks() {\n        bookChoice = new Map(state.books.map((b) => [b.code, b.chosen]));\n        const quick = $('bookQuick');\n        quick.innerHTML = '';\n        const groups = [\n          [S.booksAll, () => true],\n          [S.booksNone, () => false],\n          [S.booksBible, (b) => !isOther(b.code)],\n          [S.booksOT, (b) => b.num <= OT_END],\n          [S.booksNT, (b) => b.num > OT_END && b.num <= NT_END],\n          [S.booksDC, (b) => b.num > NT_END && !isOther(b.code)],\n          [S.booksOther, (b) => isOther(b.code)],\n        ];\n        groups.forEach(([label, test]) => {\n          const btn = document.createElement('button');\n          btn.type = 'button';\n          btn.textContent = label;\n          btn.addEventListener('click', () => {\n            state.books.forEach((b) => bookChoice.set(b.code, test(b)));\n            drawBooks();\n          });\n          quick.appendChild(btn);\n        });\n        drawBooks();\n        $('booksError').textContent = '';\n        $('booksOverlay').classList.add('show');\n      }\n\n      const OTHER = 'FRT BAK OTH INT CNC GLO TDX NDX XXA XXB XXC XXD XXE XXF XXG'.split(' ');\n      function isOther(code) {\n        return OTHER.indexOf(code) >= 0;\n      }\n\n      function drawBooks() {\n        const grid = $('bookGrid');\n        grid.innerHTML = '';\n        state.books.forEach((b) => {\n          const label = document.createElement('label');\n          const box = document.createElement('input');\n          box.type = 'checkbox';\n          box.checked = !!bookChoice.get(b.code);\n          box.addEventListener('change', () => bookChoice.set(b.code, box.checked));\n          label.appendChild(box);\n          label.appendChild(document.createTextNode(' ' + b.code));\n          grid.appendChild(label);\n        });\n      }\n\n      async function booksOk() {\n        const chosen = state.books.filter((b) => bookChoice.get(b.code));\n        if (chosen.length === 0) {\n          $('booksError').textContent = S.booksNoneChosen;\n          return;\n        }\n        $('booksOverlay').classList.remove('show');\n        const excluded = state.books.filter((b) => !bookChoice.get(b.code)).map((b) => b.code);\n        await saveOptions(Object.assign({}, state.options, { excludedBooks: excluded.join(' ') }));\n      }\n\n      // ---------------------------------------------------------------- events\n\n      $('rescanBtn').addEventListener('click', scan);\n      $('optionsBtn').addEventListener('click', () => {\n        optionsOpen = !optionsOpen;\n        $('optionsPanel').classList.toggle('hidden', !optionsOpen);\n        $('optionsBtn').textContent = optionsOpen ? S.optionsHide : S.optionsShow;\n      });\n      $('saveOptionsBtn').addEventListener('click', () => saveOptions(readOptions()));\n      $('defaultsBtn').addEventListener('click', () => saveOptions({ excludedBooks: null }));\n      $('kindFilter').addEventListener('change', renderRows);\n      $('markerFilter').addEventListener('change', renderRows);\n      $('showByHand').addEventListener('change', () => {\n        fillFilters();\n        renderRows();\n      });\n      $('tickBtn').addEventListener('click', () => {\n        shownRows()\n          .slice(0, MAX_ROWS)\n          .filter(canFixRow)\n          .forEach((r) => ticked.add(r.id));\n        renderRows();\n      });\n      $('untickBtn').addEventListener('click', () => {\n        shownRows().forEach((r) => ticked.delete(r.id));\n        renderRows();\n      });\n      $('fixBtn').addEventListener('click', askFix);\n      $('confirmYes').addEventListener('click', doFix);\n      $('confirmNo').addEventListener('click', () => $('confirmOverlay').classList.remove('show'));\n      $('booksBtn').addEventListener('click', openBooks);\n      $('booksOk').addEventListener('click', booksOk);\n      $('booksCancel').addEventListener('click', () => $('booksOverlay').classList.remove('show'));\n\n      setText();\n      $('booksBtn').textContent = fmt(S.booksButton, '-', '-');\n      scan();\n    </script>\n  </body>\n</html>\n";
const MS_USFM_STY = "# Version=3.0.11\n# ********************************************************************\n# * usfm.sty is the default stylesheet for Paratext projects         *\n# *   using USFM markup.                                             *\n# * Latest documentation and stylesheets are maintained at:          *\n# *   http://markups.paratext.org/usfm                               *\n# ********************************************************************\n\n# File Identification\n\n\\Marker id\n\\Name id - File - Identification\n\\Description File identification information (BOOKID, FILENAME, EDITOR, MODIFICATION DATE)\n\\StyleType Paragraph\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular book\n\\FontSize 12\n\n\\Marker usfm\n\\Name usfm - File - USFM Version ID\n\\Description File markup version information\n\\OccursUnder id\n\\Rank 1\n\\StyleType Paragraph\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\FontSize 12\n\n\\Marker ide\n\\Name ide - File - Encoding\n\\Description File encoding information\n\\OccursUnder id\n\\Rank 1\n\\StyleType Paragraph\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\FontSize 12\n\n# Headers\n\n\\Marker h\n\\Name h - File - Header\n\\Description Running header text for a book (basic)\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker h1\n\\Name DEPRECATED h1 - File - Header\n\\Description Running header text\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker h2\n\\Name DEPRECATED h2 - File - Left Header\n\\Description Running header text, left side of page\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker h3\n\\Name DEPRECATED h3 - File - Right Header\n\\Description Running header text, right side of page\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker toc1\n\\Name toc1 - File - Long Table of Contents Text\n\\Description Long table of contents text\n\\OccursUnder h h1 h2 h3 id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Bold\n\\Color 16384\n#!\\ColorName highcon green\n\n\\Marker toc2\n\\Name toc2 - File - Short Table of Contents Text\n\\Description Short table of contents text\n\\OccursUnder h h1 h2 h3 id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Color 16384\n#!\\ColorName highcon green\n\n\\Marker toc3\n\\Name toc3 - File - Book Abbreviation\n\\Description Book Abbreviation\n\\OccursUnder h h1 h2 h3 id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Italic\n\\Color 128\n#!\\ColorName lowcon red\n\n\\Marker toca1\n\\Name toca1 - File - Alternative Language Long Table of Contents Text\n\\Description Alternative language long table of contents text\n\\OccursUnder h h1 h2 h3\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 10\n\\Italic\n\\Color 8421504\n#!\\ColorName gray\n\n\\Marker toca2\n\\Name toca2 - File - Alternative Language Short Table of Contents Text\n\\Description Alternative language short table of contents text\n\\OccursUnder h h1 h2 h3\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 10\n\\Italic\n\\Color 8421504\n#!\\ColorName gray\n\n\\Marker toca3\n\\Name toca3 - File - Alternative Language Book Abbreviation\n\\Description Alternative language book Abbreviation\n\\OccursUnder h h1 h2 h3\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 10\n\\Italic\n\\Color 8421504\n#!\\ColorName gray\n\n# Remarks and Comments\n\n\\Marker rem\n\\Name rem - File - Remark\n\\Description Comments and remarks\n\\OccursUnder id ide c\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Color 16711680\n#!\\ColorName highcon blue\n\n\\Marker sts\n\\Name sts - File - Status\n\\Description Status of this file\n\\OccursUnder id ide c\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Color 16711680\n#!\\ColorName highcon blue\n\n\\Marker restore\n\\Name restore - File - Restore Information\n\\Description Project restore information\n\\OccursUnder id\n\\Rank 99\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Color 16711680\n#!\\ColorName highcon blue\n\n# Introduction\n\n\\Marker imt\n\\Name imt - Introduction - Major Title Level 1\n\\Description Introduction major title, level 1 (if single level) (basic)\n\\OccursUnder id\n\\Rank 5\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Other\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker imt1\n\\Name imt1 - Introduction - Major Title Level 1\n\\Description Introduction major title, level 1 (if multiple levels)\n\\OccursUnder id\n\\Rank 5\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Other\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker imt2\n\\Name imt2 - Introduction - Major Title Level 2\n\\Description Introduction major title, level 2\n\\OccursUnder id\n\\Rank 5\n\\TextProperties paragraph publishable vernacular level_2\n\\TextType other\n\\StyleType Paragraph\n\\FontSize 13\n\\Italic\n\\Justification Center\n\\SpaceBefore 6\n\\SpaceAfter 3\n\n\\Marker imt3\n\\Name imt3 - Introduction - Major Title Level 3\n\\Description Introduction major title, level 3\n\\OccursUnder id\n\\Rank 5\n\\TextProperties paragraph publishable vernacular level_3\n\\TextType Other\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceBefore 2\n\\SpaceAfter 2\n\n\\Marker imt4\n\\Name imt4 - Introduction - Major Title Level 4\n\\Description Introduction major title, level 4 (usually within parenthesis)\n\\OccursUnder id\n\\Rank 5\n\\TextProperties paragraph publishable vernacular level_4\n\\TextType Other\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Center\n\\SpaceBefore 2\n\\SpaceAfter 2\n \n\\Marker imte\n\\Name imte - Introduction - [Uncommon] Major Title at Introduction End Level 1\n\\Description Introduction major title at introduction end, level 1 (if single level)\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Other\n\\OccursUnder id\n\\Rank 7\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker imte1\n\\Name imte1 - Introduction - [Uncommon] Major Title at Introduction End Level 1\n\\Description Introduction major title at introduction end, level 1 (if multiple levels)\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Other\n\\OccursUnder id\n\\Rank 7\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker imte2\n\\Name imte2 - Introduction - [Uncommon] Major Title at Introduction End Level 2\n\\Description Introduction major title at introduction end, level 2\n\\TextProperties paragraph publishable vernacular level_2\n\\TextType Other\n\\OccursUnder id\n\\Rank 7\n\\StyleType Paragraph\n\\FontSize 16\n\\Italic\n\\Justification Center\n\\SpaceAfter 2 \n\n\\Marker is\n\\Name is - Introduction - Section Heading Level 1\n\\Description Introduction section heading, level 1 (if single level) (basic)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker is1 \n\\Name is1 - Introduction - Section Heading Level 1\n\\Description Introduction section heading, level 1 (if multiple levels)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker is2\n\\Name is2 - Introduction - Section Heading Level 2\n\\Description Introduction section heading, level 2 \n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker iot \n\\Name iot - Introduction - Outline Title\n\\Description Introduction outline title (basic)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker io\n\\Name io - Introduction - Outline Level 1\n\\Description Introduction outline text, level 1 (if single level)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\n\\Marker io1\n\\Name io1 - Introduction - Outline Level 1\n\\Description Introduction outline text, level 1 (if multiple levels) (basic)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\n\\Marker io2\n\\Name io2 - Introduction - Outline Level 2\n\\Description Introduction outline text, level 2 \n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .75\n\n\\Marker io3\n\\Name io3 - Introduction - Outline Level 3\n\\Description Introduction outline text, level 3 \n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1\n\n\\Marker io4\n\\Name io4 - Introduction - Outline Level 4\n\\Description Introduction outline text, level 4 \n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_4\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1.25\n\n\\Marker ior\n\\Endmarker ior*\n\\Name ior...ior* - Introduction - Outline References Range\n\\Description Introduction references range for outline entry; for marking references separately\n\\OccursUnder id io io1 io2 io3 io4 NEST\n\\TextType Other\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker ip\n\\Name ip - Introduction - Paragraph\n\\Description Introduction prose paragraph (basic)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\n\\Marker im\n\\Name im - Introduction - Paragraph - no first line indent\n\\Description Introduction prose paragraph, with no first line indent (may occur after poetry)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker ipi\n\\Name ipi - Introduction - Indented Para - first line indent\n\\Description Introduction prose paragraph, indented, with first line indent\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker imi\n\\Name imi - Introduction - Indented Para - no first line indent\n\\Description Introduction prose paragraph text, indented, with no first line indent\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker ili\n\\Name ili - Introduction - List Entry - Level 1\n\\Description A list entry, level 1 (if single level)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.375 # 1/8 inch indent, 1/2 inch wrap\n\n\\Marker ili1\n\\Name ili1 - Introduction - List Entry - Level 1\n\\Description A list entry, level 1 (if multiple levels)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.375 # 1/8 inch indent, 1/2 inch wrap\n\n\\Marker ili2\n\\Name ili2 - Introduction - List Entry - Level 2\n\\Description A list entry, level 2\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .75\n\\FirstLineIndent -.375\n\n\\Marker ipq\n\\Name ipq - Introduction - Paragraph - quote from text\n\\Description Introduction prose paragraph, quote from the body text\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\Italic\n\n\\Marker imq\n\\Name imq - Introduction - Paragraph - quote from text - no first line indent\n\\Description Introduction prose paragraph, quote from the body text, with no first line indent\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\\Italic\n\n\\Marker ipr\n\\Name ipr - Introduction - Paragraph - right aligned\n\\Description Introduction prose paragraph, right aligned\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\\Justification Right\n\\Italic\n\n\\Marker ib\n\\Name ib - Introduction - Blank Line\n\\Description Introduction blank line\n\\OccursUnder id\n\\Rank 6\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType Other\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker iq\n\\Name iq - Introduction - Poetry Level 1\n\\Description Introduction poetry text, level 1 (if single level)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular poetic level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.75  # 1/4 inch indent, 1 inch wrap\n\\Italic\n\n\\Marker iq1\n\\Name iq1 - Introduction - Poetry Level 1\n\\Description Introduction poetry text, level 1 (if multiple levels)\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular poetic level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.75  # 1/4 inch indent, 1 inch wrap\n\\Italic\n\n\\Marker iq2\n\\Name iq2 - Introduction - Poetry Level 2\n\\Description Introduction poetry text, level 2 \n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular poetic level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.5  # 1/2 inch indent, 1 inch wrap\n\\Italic\n\n\\Marker iq3\n\\Name iq3 - Introduction - Poetry Level 3\n\\Description Introduction poetry text, level 3\n\\OccursUnder id\n\\Rank 6\n\\TextType Other\n\\TextProperties paragraph publishable vernacular poetic level_3\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.25 # 3/4 inch indent, 1 inch wrap\n\\Italic\n\n\\Marker iex\n\\Name iex - Introduction - Explanatory or Bridge Text\n\\Description Introduction explanatory or bridge text (e.g. explanation of missing book in Short Old Testament)\n\\OccursUnder id c\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\SpaceBefore 4\n\\SpaceAfter 4\n\n\\Marker iqt\n\\Endmarker iqt*\n\\Name iqt...iqt* - Special Text - Quoted Scripture Text in Introduction\n\\Description For quoted scripture text appearing in the introduction\n\\OccursUnder imt imt1 imt2 imt3 imt4 ib ie ili ili1 ili2 im imi imq io io1 io2 io3 io4 iot ip ipi ipq ipr iq iq1 iq2 iq3 is is1 is2 imte imte1 imte2 iex\n\\TextType Other\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker ie\n\\Name ie - Introduction - End Marker\n\\Description Introduction ending marker\n\\OccursUnder id\n\\Rank 6\n\\TextProperties paragraph publishable vernacular\n\\TextType Other\n\\FontSize 10\n\\StyleType paragraph\n\n# Chapters and Verses\n\n\\Marker c\n\\Name c - Chapter Number\n\\Description Chapter number (necessary for normal Paratext operation)\n\\OccursUnder id\n\\Rank 8\n\\TextType ChapterNumber\n\\TextProperties chapter\n\\StyleType Paragraph\n\\Bold\n\\FontSize 18\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker ca\n\\Endmarker ca*\n\\Name ca...ca* - Chapter Number - Alternate\n\\Description Second (alternate) chapter number (for coding dual versification; useful for places where different traditions of chapter breaks need to be supported in the same translation)\n\\OccursUnder c \n\\TextType Other\n\\StyleType Character\n\\Italic\n\\FontSize 16\n\\Color 2263842\n#!\\ColorName green\n\n\\Marker cp\n\\Name cp - Chapter Number - Publishing Alternate\n\\Description Published chapter number (chapter string that should appear in the published text)\n\\OccursUnder c \n\\Rank 4\n\\TextType Other\n\\TextProperties paragraph\n\\StyleType Paragraph\n\\Bold\n\\FontSize 18\n\\SpaceBefore 8\n\\SpaceAfter 4\n\\Color 16711680\n#!\\ColorName highcon blue\n\n\\Marker cl\n\\Name cl - Chapter - Publishing Label\n\\Description Chapter label used for translations that add a word such as \"Chapter\" before chapter numbers (e.g. Psalms). The subsequent text is the chapter label.\n\\OccursUnder id c ms ms1 ms2 ms3 mr\n\\TextType Other\n\\TextProperties paragraph\n\\StyleType Paragraph\n\\Bold\n\\FontSize 18\n\\SpaceBefore 8\n\\SpaceAfter 4\n\\Justification Center\n\n\\Marker cd\n\\Name cd - Chapter - Description\n\\Description Chapter Description (Publishing option D, e.g. in Russian Bibles)\n\\OccursUnder c\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 11\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker v\n\\Name v - Verse Number\n\\Description A verse number (Necessary for normal paratext operation) (basic)\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 s3 d sp\n\\TextType VerseNumber\n\\TextProperties verse\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\n\\Marker va\n\\Endmarker va*\n\\Name va...va* - Verse Number - Alternate\n\\Description Second (alternate) verse number (for coding dual numeration in Psalms; see also NRSV Exo 22.1-4)\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 s3 d sp\n\\TextType Other\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\\Color 2263842\n#!\\ColorName green\n\n\\Marker vp\n\\Endmarker vp*\n\\Name vp...vp* - Verse Number - Publishing Alternate\n\\Description Published verse marker (verse string that should appear in the published text)\n\\OccursUnder cd lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 s3 d sp\n\\TextType Other\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\\Color 16711680\n#!\\ColorName highcon blue\n\n# Paragraphs\n\n\\Marker p\n\\Name p - Paragraph - Normal - First Line Indent\n\\Description Paragraph text, with first line indent (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\n\\Marker m\n\\Name m - Paragraph - Margin - No First Line Indent\n\\Description Paragraph text, with no first line indent (may occur after poetry) (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker po\n\\Name po - Paragraph - Letter Opening\n\\Description Letter opening\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\SpaceBefore 4\n\\SpaceAfter 4\n\n\\Marker pr\n\\Name pr - Paragraph - Text Refrain (right aligned)\n\\Description Text refrain (paragraph text, right aligned)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\Justification Right\n\\FontSize 12\n\n\\Marker cls\n\\Name cls - Paragraph - Letter Closing\n\\Description Letter Closing\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Justification Right\n\n\\Marker pmo\n\\Name pmo - Paragraph - Embedded Text Opening\n\\Description Embedded text opening\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr po q q1 q2 q3 q4 qc qr b s1 s2 s3 s4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pm\n\\Name pm - Paragraph - Embedded Text\n\\Description Embedded text paragraph\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr po psi q q1 q2 q3 q4 qc qr b s1 s2 s3 s4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pmc\n\\Name pmc - Paragraph - Embedded Text Closing\n\\Description Embedded text closing\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr po q q1 q2 q3 q4 qc qr b s1 s2 s3 s4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pmr\n\\Name pmr - Paragraph - Embedded Text Refrain\n\\Description Embedded text refrain (e.g. Then all the people shall say, \"Amen!\")\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr po q q1 q2 q3 q4 qc qr b s1 s2 s3 s4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Justification Right\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pi\n\\Name pi - Paragraph - Indented - Level 1 - First Line Indent\n\\Description Paragraph text, level 1 indent (if single level), with first line indent; often used for discourse (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pi1\n\\Name pi1 - Paragraph - Indented - Level 1 - First Line Indent\n\\Description Paragraph text, level 1 indent (if multiple levels), with first line indent; often used for discourse\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker pi2\n\\Name pi2 - Paragraph - Indented - Level 2 - First Line Indent\n\\Description Paragraph text, level 2 indent, with first line indent; often used for discourse\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .5\n\\RightMargin .25\n\n\\Marker pi3\n\\Name pi3 - Paragraph - Indented - Level 3 - First Line Indent\n\\Description Paragraph text, level 3 indent, with first line indent; often used for discourse\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .75\n\\RightMargin .25\n\n\\Marker pc\n\\Name pc - Paragraph - Centered (for Inscription)\n\\Description Paragraph text, centered (for Inscription)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\Justification Center\n\\FontSize 12\n\n\\Marker mi\n\\Name mi - Paragraph - Indented - No First Line Indent\n\\Description Paragraph text, indented, with no first line indent; often used for discourse\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .25\n\\RightMargin .25\n\n\\Marker nb\n\\Name nb - Paragraph - No Break with Previous Paragraph\n\\Description Paragraph text, with no break from previous paragraph text (at chapter boundary) (basic)\n\\OccursUnder c \n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n# Poetry\n\n\\Marker q\n\\Name q - Poetry - Indent Level 1 - Single Level Only\n\\Description Poetry text, level 1 indent (if single level)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 0.75\n\\FirstLineIndent -0.5  # 1/8 inch indent, 3/4 inch wrap\n\n\\Marker q1\n\\Name q1 - Poetry - Indent Level 1\n\\Description Poetry text, level 1 indent (if multiple levels) (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 0.75\n\\FirstLineIndent -0.5  # 1/8 inch indent, 3/4 inch wrap\n\n\\Marker q2\n\\Name q2 - Poetry - Indent Level 2\n\\Description Poetry text, level 2 indent (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 0.75\n\\FirstLineIndent -0.375  # 1/4 inch indent, 3/4 inch wrap\n\n\\Marker q3\n\\Name q3 - Poetry - Indent Level 3\n\\Description Poetry text, level 3 indent\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_3\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 0.75\n\\FirstLineIndent -0.25 # 3/8 inch indent, 3/4 inch wrap\n\n\\Marker q4\n\\Name q4 - Poetry - Indent Level 4\n\\Description Poetry text, level 4 indent\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_4\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 0.75\n\\FirstLineIndent -0.125 # 1/2 inch indent, 3/4 inch wrap\n\n\\Marker qc\n\\Name qc - Poetry - Centered\n\\Description Poetry text, centered\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic\n\\StyleType Paragraph\n\\FontSize 12\n\\Justification Center\n\n\\Marker qr\n\\Name qr - Poetry - Right Aligned\n\\Description Poetry text, Right Aligned\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic\n\\StyleType Paragraph\n\\FontSize 12\n\\Justification Right\n\n\\Marker qs\n\\Endmarker qs*\n\\Name qs...qs* - Poetry Text - Selah\n\\Description Poetry text, Selah\n\\OccursUnder q q1 q2 q3 q4 qc qr qd NEST\n\\Rank 4\n\\TextType VerseText\n\\TextProperties publishable vernacular poetic\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker qa\n\\Name qa - Poetry - Acrostic Heading/Marker\n\\Description Poetry text, Acrostic marker/heading\n\\OccursUnder c\n\\Rank 4\n\\TextType Other\n\\TextProperties paragraph publishable vernacular poetic\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\n\\Marker qac\n\\Endmarker qac*\n\\Name qac...qac* - Poetry Text - Acrostic Letter\n\\Description Poetry text, Acrostic markup of the first character of a line of acrostic poetry\n\\OccursUnder q q1 q2 q3 q4 qc qr  NEST\n\\Rank 4\n\\TextType Other\n\\TextProperties publishable vernacular poetic\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker qm\n\\Name qm - Poetry - Embedded Text - Indent Level 1 - Single Level Only\n\\Description Poetry text, embedded, level 1 indent (if single level)\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr q q1 q2 q3 q4 qc qr b\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.75  # 1/4 inch indent, 1 inch wrap\n\n\\Marker qm1\n\\Name qm1 - Poetry - Embedded Text - Indent Level 1\n\\Description Poetry text, embedded, level 1 indent (if multiple levels)\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr q q1 q2 q3 q4 qc qr b\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.75  # 1/4 inch indent, 1 inch wrap\n\n\\Marker qm2\n\\Name qm2 - Poetry - Embedded Text - Indent Level 2\n\\Description Poetry text, embedded, level 2 indent\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr q q1 q2 q3 q4 qc qr b\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.5  # 1/2 inch indent, 1 inch wrap\n\n\\Marker qm3\n\\Name qm3 - Poetry - Embedded Text - Indent Level 3\n\\Description Poetry text, embedded, level 3 indent\n\\OccursUnder m mi nb p pc ph phi pi pi1 pi2 pi3 pr q q1 q2 q3 q4 qc qr b\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic level_3\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.25 # 3/4 inch indent, 1 inch wrap\n\n\\Marker qd\n\\Name qd - Poetry - Hebrew Note\n\\Description A Hebrew musical performance annotation, similar in content to Hebrew descriptive title.\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular poetic\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\LeftMargin .25\n\n\\Marker b\n\\Name b - Poetry - Stanza Break (Blank Line)\n\\Description Poetry text stanza break (e.g. stanza break) (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n# Titles & Headings\n\n\\Marker mt\n\\Name mt - Title - Major Title Level 1\n\\Description The main title of the book (if single level)\n\\OccursUnder id\n\\Rank 3\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Title\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker mt1\n\\Name mt1 - Title - Major Title Level 1\n\\Description The main title of the book (if multiple levels) (basic)\n\\OccursUnder id\n\\Rank 3\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Title\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 2\n\\SpaceAfter 4\n\n\\Marker mt2\n\\Name mt2 - Title - Major Title Level 2\n\\Description A secondary title usually occurring before the main title (basic)\n\\OccursUnder id\n\\Rank 3\n\\TextProperties paragraph publishable vernacular level_2\n\\TextType Title\n\\StyleType Paragraph\n\\FontSize 16\n\\Italic\n\\Justification Center\n\\SpaceAfter 2\n\n\\Marker mt3\n\\Name mt3 - Title - Major Title Level 3\n\\Description A secondary title occurring after the main title\n\\OccursUnder id\n\\Rank 3\n\\TextProperties paragraph publishable vernacular level_3\n\\TextType Title\n\\StyleType Paragraph\n\\FontSize 16\n\\Bold\n\\Justification Center\n\\SpaceBefore 2\n\\SpaceAfter 2\n\n\\Marker mt4\n\\Name mt4 - Title - Major Title level 4\n\\Description A small secondary title sometimes occurring within parentheses\n\\OccursUnder id\n\\Rank 3\n\\TextProperties paragraph publishable vernacular level_4\n\\TextType Title\n\\StyleType Paragraph\n\\FontSize 12\n\\Justification Center\n\\SpaceBefore 2\n\\SpaceAfter 2\n\n\\Marker mte\n\\Name mte - Title - [Uncommon] Major Title Ending Level 1\n\\Description The main title of the book repeated at the end of the book, level 1 (if single level)\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Title\n\\OccursUnder c\n\\Rank 2\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker mte1\n\\Name mte1 - Title - [Uncommon] Major Title Ending Level 1\n\\Description The main title of the book repeated at the end of the book, level 1 (if multiple levels)\n\\TextProperties paragraph publishable vernacular level_1\n\\TextType Title\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tc1 tc2 tc3 tc4 s3 d\n\\Rank 2\n\\StyleType Paragraph\n\\FontSize 20\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n \n\\Marker mte2\n\\Name mte2 - Title - [Uncommon] Major Title Ending Level 2\n\\Description A secondary title occurring before or after the 'ending' main title\n\\TextProperties paragraph publishable vernacular level_2\n\\TextType Title\n\\OccursUnder mte1\n\\Rank 2\n\\StyleType Paragraph\n\\FontSize 16\n\\Italic\n\\Justification Center\n\\SpaceAfter 2\n\n\\Marker ms\n\\Name ms - Heading - Major Section Level 1\n\\Description A major section division heading, level 1 (if single level) (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 16\n\\SpaceAfter 4\n\n\\Marker ms1\n\\Name ms1 - Heading - Major Section Level 1\n\\Description A major section division heading, level 1 (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 16\n\\SpaceAfter 4\n\n\\Marker ms2\n\\Name ms2 - Heading - Major Section Level 2\n\\Description A major section division heading, level 2\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\Justification Center\n\\SpaceBefore 16\n\\SpaceAfter 4\n\n\\Marker ms3\n\\Name ms3 - Heading - Major Section Level 3\n\\Description A major section division heading, level 3\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 14\n\\Italic\n\\Justification Center\n\\SpaceBefore 16\n\\SpaceAfter 4\n\n\\Marker mr\n\\Name mr - Heading - Major Section Range References\n\\Description A major section division references range heading (basic)\n\\OccursUnder ms ms1 ms2 ms3\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Center\n\\SpaceAfter 4\n\n\\Marker s\n\\Name s - Heading - Section Level 1\n\\Description A section heading, level 1 (if single level) (basic)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker s1\n\\Name s1 - Heading - Section Level 1\n\\Description A section heading, level 1 (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker s2\n\\Name s2 - Heading - Section Level 2\n\\Description A section heading, level 2 (e.g. Proverbs 22-24)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Center\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker s3\n\\Name s3 - Heading - Section Level 3\n\\Description A section heading, level 3 (e.g. Genesis \"The First Day\")\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Left\n\\SpaceBefore 6\n\\SpaceAfter 3\n\n\\Marker s4\n\\Name s4 - Heading - Section Level 4\n\\Description A section heading, level 4\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_4\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Left\n\\SpaceBefore 6\n\\SpaceAfter 3\n\n\\Marker sr\n\\Name sr - Heading - Section Range References\n\\Description A section division references range heading\n\\OccursUnder s s1 s2 s3 s4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Bold\n\\Justification Center\n\\SpaceAfter 4\n\n\\Marker r\n\\Name r - Heading - Parallel References\n\\Description Parallel reference(s) (basic)\n\\OccursUnder c s s1 s2 s3 s4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Center\n\\SpaceAfter 4\n\n\\Marker sp\n\\Name sp - Label - Speaker\n\\Description A heading, to identify the speaker (e.g. Job)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Left\n\\SpaceBefore 8\n\\SpaceAfter 4\n\n\\Marker d\n\\Name d - Label - Descriptive Title - Hebrew Subtitle\n\\Description A Hebrew text heading, to provide description (e.g. Psalms)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\FontSize 12\n\\Italic\n\\Justification Center\n\\SpaceBefore 4\n\\SpaceAfter 4\n\n\\Marker sd\n\\Name sd - Label - Semantic Division Location - Level 1\n\\Description Vertical space used to divide the text into sections, level 1 (if single level)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\SpaceBefore 24\n\\SpaceAfter 24\n\n\\Marker sd1\n\\Name sd1 - Label - Semantic Division Location - Level 1\n\\Description Vertical space used to divide the text into sections, level 1 (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType Paragraph\n\\SpaceBefore 24\n\\SpaceAfter 24\n\n\\Marker sd2\n\\Name sd2 - Label - Semantic Division Location - Level 2\n\\Description Vertical space used to divide the text into sections, level 2\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType Paragraph\n\\SpaceBefore 18\n\\SpaceAfter 18\n\n\\Marker sd3\n\\Name sd3 - Label - Semantic Division Location - Level 3\n\\Description Vertical space used to divide the text into sections, level 3\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType Paragraph\n\\SpaceBefore 12\n\\SpaceAfter 12\n\n\\Marker sd4\n\\Name sd4 - Label - Semantic Division Location - Level 4\n\\Description Vertical space used to divide the text into sections, level 4\n\\OccursUnder c\n\\Rank 4\n\\TextType Section\n\\TextProperties paragraph publishable vernacular level_4\n\\StyleType Paragraph\n\\SpaceBefore 8\n\\SpaceAfter 8\n\n# Tables\n\n\\Marker tr\n\\Name tr - Table - Row\n\\Description A new table row\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.25  # 6/16 inch\n\n\\Marker th1 \n\\Name th1 - Table - Column 1 Heading\n\\Description A table heading, column 1\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th2\n\\Name th2 - Table - Column 2 Heading\n\\Description A table heading, column 2\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th3\n\\Name th3 - Table - Column 3 Heading\n\\Description A table heading, column 3\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th4\n\\Name th4 - Table - Column 4 Heading\n\\Description A table heading, column 4\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th5\n\\Name th5 - Table - Column 5 Heading\n\\Description A table heading, column 5\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th6\n\\Name th6 - Table - Column 6 Heading\n\\Description A table heading, column 6\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th7\n\\Name th7 - Table - Column 7 Heading\n\\Description A table heading, column 7\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th8\n\\Name th8 - Table - Column 8 Heading\n\\Description A table heading, column 8\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th9\n\\Name th9 - Table - Column 9 Heading\n\\Description A table heading, column 9\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th10\n\\Name th10 - Table - Column 10 Heading\n\\Description A table heading, column 10\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th11\n\\Name th11 - Table - Column 11 Heading\n\\Description A table heading, column 11\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker th12\n\\Name th12 - Table - Column 12 Heading\n\\Description A table heading, column 12\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker tc1\n\\Name tc1 - Table - Column 1 Cell\n\\Description A table cell item, column 1\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc2\n\\Name tc2 - Table - Column 2 Cell\n\\Description A table cell item, column 2\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc3\n\\Name tc3 - Table - Column 3 Cell\n\\Description A table cell item, column 3\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc4\n\\Name tc4 - Table - Column 4 Cell\n\\Description A table cell item, column 4\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc5\n\\Name tc5 - Table - Column 5 Cell\n\\Description A table cell item, column 5\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc6\n\\Name tc6 - Table - Column 6 Cell\n\\Description A table cell item, column 6\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc7\n\\Name tc7 - Table - Column 7 Cell\n\\Description A table cell item, column 7\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc8\n\\Name tc8 - Table - Column 8 Cell\n\\Description A table cell item, column 8\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc9\n\\Name tc9 - Table - Column 9 Cell\n\\Description A table cell item, column 9\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc10\n\\Name tc10 - Table - Column 10 Cell\n\\Description A table cell item, column 10\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc11\n\\Name tc11 - Table - Column 11 Cell\n\\Description A table cell item, column 11\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker tc12\n\\Name tc12 - Table - Column 12 Cell\n\\Description A table cell item, column 12\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n# Center Aligned Table Heads and Columns\n\n\\Marker thc1 \n\\Name thc1 - Table - Column 1 Heading - Center Aligned\n\\Description A table heading, column 1, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc2\n\\Name thc2 - Table - Column 2 Heading - Center Aligned\n\\Description A table heading, column 2, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc3\n\\Name thc3 - Table - Column 3 Heading - Center Aligned\n\\Description A table heading, column 3, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc4\n\\Name thc4 - Table - Column 4 Heading - Center Aligned\n\\Description A table heading, column 4, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc5\n\\Name thc5 - Table - Column 5 Heading - Center Aligned\n\\Description A table heading, column 5, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc6\n\\Name thc6 - Table - Column 6 Heading - Center Aligned\n\\Description A table heading, column 6, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc7\n\\Name thc7 - Table - Column 7 Heading - Center Aligned\n\\Description A table heading, column 7, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc8\n\\Name thc8 - Table - Column 8 Heading - Center Aligned\n\\Description A table heading, column 8, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc9\n\\Name thc9 - Table - Column 9 Heading - Center Aligned\n\\Description A table heading, column 9, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc10\n\\Name thc10 - Table - Column 10 Heading - Center Aligned\n\\Description A table heading, column 10, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc11\n\\Name thc11 - Table - Column 11 Heading - Center Aligned\n\\Description A table heading, column 11, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker thc12\n\\Name thc12 - Table - Column 12 Heading - Center Aligned\n\\Description A table heading, column 12, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Center\n\n\\Marker tcc1\n\\Name tcc1 - Table - Column 1 Cell - Center Aligned\n\\Description A table cell item, column 1, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc2\n\\Name tcc2 - Table - Column 2 Cell - Center Aligned\n\\Description A table cell item, column 2, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc3\n\\Name tcc3 - Table - Column 3 Cell - Center Aligned\n\\Description A table cell item, column 3, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc4\n\\Name tcc4 - Table - Column 4 Cell - Center Aligned\n\\Description A table cell item, column 4, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc5\n\\Name tcc5 - Table - Column 5 Cell - Center Aligned\n\\Description A table cell item, column 5, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc6\n\\Name tcc6 - Table - Column 6 Cell - Center Aligned\n\\Description A table cell item, column 6, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc7\n\\Name tcc7 - Table - Column 7 Cell - Center Aligned\n\\Description A table cell item, column 7, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc8\n\\Name tcc8 - Table - Column 8 Cell - Center Aligned\n\\Description A table cell item, column 8, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc9\n\\Name tcc9 - Table - Column 9 Cell - Center Aligned\n\\Description A table cell item, column 9, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc10\n\\Name tcc10 - Table - Column 10 Cell - Center Aligned\n\\Description A table cell item, column 10, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc11\n\\Name tcc11 - Table - Column 11 Cell - Center Aligned\n\\Description A table cell item, column 11, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n\\Marker tcc12\n\\Name tcc12 - Table - Column 12 Cell - Center Aligned\n\\Description A table cell item, column 12, center aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Center\n\n# Right Aligned Table Heads and Columns\n\n\\Marker thr1 \n\\Name thr1 - Table - Column 1 Heading - Right Aligned\n\\Description A table heading, column 1, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Right\n\n\\Marker thr2\n\\Name thr2 - Table - Column 2 Heading - Right Aligned\n\\Description A table heading, column 2, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Right\n\n\\Marker thr3\n\\Name thr3 - Table - Column 3 Heading - Right Aligned\n\\Description A table heading, column 3, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Right\n\n\\Marker thr4\n\\Name thr4 - Table - Column 4 Heading - Right Aligned\n\\Description A table heading, column 4, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Right\n\n\\Marker thr5\n\\Name thr5 - Table - Column 5 Heading - Right Aligned\n\\Description A table heading, column 5, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification Right\n\n\\Marker thr6\n\\Name thr6 - Table - Column 6 Heading - Right Aligned\n\\Description A table heading, column 6, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr7\n\\Name thr7 - Table - Column 7 Heading - Right Aligned\n\\Description A table heading, column 7, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr8\n\\Name thr8 - Table - Column 8 Heading - Right Aligned\n\\Description A table heading, column 8, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr9\n\\Name thr9 - Table - Column 9 Heading - Right Aligned\n\\Description A table heading, column 9, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr10\n\\Name thr10 - Table - Column 10 Heading - Right Aligned\n\\Description A table heading, column 10, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr11\n\\Name thr11 - Table - Column 11 Heading - Right Aligned\n\\Description A table heading, column 11, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker thr12\n\\Name thr12 - Table - Column 12 Heading - Right Aligned\n\\Description A table heading, column 12, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Justification right\n\n\\Marker tcr1 \n\\Name tcr1 - Table - Column 1 Cell - Right Aligned\n\\Description A table cell item, column 1, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Right\n\n\\Marker tcr2\n\\Name tcr2 - Table - Column 2 Cell - Right Aligned\n\\Description A table cell item, column 2, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Right\n\n\\Marker tcr3\n\\Name tcr3 - Table - Column 3 Cell - Right Aligned\n\\Description A table cell item, column 3, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Right\n\n\\Marker tcr4\n\\Name tcr4 - Table - Column 4 Cell - Right Aligned\n\\Description A table cell item, column 4, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Right\n\n\\Marker tcr5\n\\Name tcr5 - Table - Column 5 Cell - Right Aligned\n\\Description A table cell item, column 5, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification Right\n\n\\Marker tcr6\n\\Name tcr6 - Table - Column 6 Cell - Right Aligned\n\\Description A table cell item, column 6, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr7\n\\Name tcr7 - Table - Column 7 Cell - Right Aligned\n\\Description A table cell item, column 7, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr8\n\\Name tcr8 - Table - Column 8 Cell - Right Aligned\n\\Description A table cell item, column 8, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr9\n\\Name tcr9 - Table - Column 9 Cell - Right Aligned\n\\Description A table cell item, column 9, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr10\n\\Name tcr10 - Table - Column 10 Cell - Right Aligned\n\\Description A table cell item, column 10, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr11\n\\Name tcr11 - Table - Column 11 Cell - Right Aligned\n\\Description A table cell item, column 11, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n\\Marker tcr12\n\\Name tcr12 - Table - Column 12 Cell - Right Aligned\n\\Description A table cell item, column 12, right aligned\n\\OccursUnder tr\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Justification right\n\n# Lists\n\n\\Marker lh\n\\Name lh - List Header\n\\Description List header (introductory remark)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\n\\Marker li\n\\Name li - List Entry - Level 1\n\\Description A list entry, level 1 (if single level)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.375 # 1/8 inch indent, 1/2 inch wrap\n\n\\Marker li1\n\\Name li1 - List Entry - Level 1\n\\Description A list entry, level 1 (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.375 # 1/8 inch indent, 1/2 inch wrap\n\n\\Marker li2\n\\Name li2 - List Entry - Level 2\n\\Description A list entry, level 2\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .75\n\\FirstLineIndent -.375\n\n\\Marker li3\n\\Name li3 - List Entry - Level 3\n\\Description A list entry, level 3\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.375\n\n\\Marker li4\n\\Name li4 - List Entry - Level 4\n\\Description A list entry, level 4\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_4\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1.25\n\\FirstLineIndent -.375\n\n\\Marker lf\n\\Name lf - List Footer\n\\Description List footer (concluding remark)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker lim\n\\Name lim - Embedded List Entry - Level 1\n\\Description An embedded list entry, level 1 (if single level)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .75\n\\FirstLineIndent -.375\n\\RightMargin .25\n\n\\Marker lim1\n\\Name lim1 - Embedded List Entry - Level 1\n\\Description An embedded list entry, level 1 (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_1\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin .75\n\\FirstLineIndent -.375\n\\RightMargin .25\n\n\\Marker lim2\n\\Name lim2 - Embedded List Entry - Level 2\n\\Description An embedded list entry, level 2\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_2\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1\n\\FirstLineIndent -.375\n\n\\Marker lim3\n\\Name lim3 - Embedded List Item - Level 3\n\\Description An embedded list item, level 3\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_3\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1.25\n\\FirstLineIndent -.375\n\n\\Marker lim4\n\\Name lim4 - Embedded List Entry - Level 4\n\\Description An embedded list entry, level 4\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular level_4\n\\StyleType paragraph\n\\FontSize 12\n\\LeftMargin 1.5\n\\FirstLineIndent -.375\n\n\\Marker litl\n\\Endmarker litl*\n\\Name litl...litl* - List Entry - Total\n\\Description List entry total text\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker lik\n\\Endmarker lik*\n\\Name lik...lik* - Structured List Entry - Key\n\\Description Structured list entry key text\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker liv\n\\Endmarker liv*\n\\Name liv...liv* - Structured List Entry - Value 1\n\\Description Structured list entry value 1 content (if single value)\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker liv1\n\\Endmarker liv1*\n\\Name liv1...liv1* - Structured List Entry - Value 1\n\\Description Structured list entry value 1 content (if multiple values)\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker liv2\n\\Endmarker liv2*\n\\Name liv2...liv2* - Structured List Entry - Value 2\n\\Description Structured list entry value 2 content\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker liv3\n\\Endmarker liv3*\n\\Name liv3...liv3* - Structured List Entry - Value 3\n\\Description Structured list entry value 3 content\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker liv4\n\\Endmarker liv4*\n\\Name liv4...liv4* - Structured List Entry - Value 4\n\\Description Structured list entry value 4 content\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker liv5\n\\Endmarker liv5*\n\\Name liv5...liv5* - Structured List Entry - Value 5\n\\Description Structured list entry value 5 content\n\\OccursUnder li li1 li2 li3 li4 lim lim1 lim2 lim3 lim4 NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n# Footnotes\n\n\\Marker f\n\\Endmarker f*\n\\Name f...f* - Footnote \n\\Description A Footnote text item (basic)\n\\OccursUnder c cp lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 qs sp tc1 tc2 tc3 tc4 mt mt1 mt2 mt3 ms ms1 ms2 ms3 s s1 s2 s3 d ip\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Note\n\\FontSize 12\n\n\\Marker fe\n\\Endmarker fe*\n\\Name fe...fe* - Endnote\n\\Description An Endnote text item\n\\OccursUnder c lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tc1 tc2 tc3 tc4 ms ms1 ms2 ms3 s s1 s2 s3 d ip\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Note\n\\FontSize 12\n\n\\Marker fr\n\\Endmarker fr*\n\\Name fr - Footnote - Reference\n\\Description The origin reference for the footnote (basic)\n\\OccursUnder f fe\n\\TextType NoteText\n\\TextProperties publishable vernacular note\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\n\\Marker ft\n\\Endmarker ft*\n\\Name ft - Footnote - Text\n\\Description Footnote text, Protocanon (basic)\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker fk\n\\Endmarker fk*\n\\Name fk - Footnote - Keyword\n\\Description A footnote keyword (basic)\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\\Italic\n\n\\Marker fq\n\\Endmarker fq*\n\\Name fq - Footnote - Quotation or Alternate Rendering\n\\Description A footnote scripture quote or alternate rendering (basic)\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker fqa\n\\Endmarker fqa*\n\\Name fqa - Footnote - Alternate Translation Rendering\n\\Description A footnote alternate rendering for a portion of scripture text\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker fl\n\\Endmarker fl*\n\\Name fl - Footnote - Label Text\n\\Description A footnote label text item, for marking or \"labelling\" the type or alternate translation being provided in the note.\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Bold\n\n\\Marker fw\n\\Endmarker fw*\n\\Name fw - Footnote - Witness List\n\\Description A footnote witness list, for distinguishing a list of sigla representing witnesses in critical editions.\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker fp\n\\Endmarker fp*\n\\Name fp - Footnote Paragraph Mark\n\\Description A Footnote additional paragraph marker\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker fv\n\\Endmarker fv*\n\\Name fv...fv* - Footnote - Embedded Verse Number\n\\Description A verse number within the footnote text\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\n\\Marker fdc\n\\Endmarker fdc*\n\\Name DEPRECATED fdc...fdc* - Footnote - DC text\n\\Description Footnote text, applies to Deuterocanon only\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker fm\n\\Endmarker fm*\n\\Name fm - Footnote - Additional Caller to Previous Note\n\\Description An additional footnote marker location for a previous footnote \n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tc1 tc2 tc3 tc4 ms ms1 ms2 s s1 s2 s3 d ip\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\n# Cross References\n\n\\Marker x\n\\Endmarker x*\n\\Name x...x* - Cross Reference\n\\Description A list of cross references (basic)\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 qs sp tc1 tc2 tc3 tc4 mt mt1 mt2 mt3 ms ms1 ms2 s s1 s2 s3 d\n\\TextProperties publishable vernacular note crossreference\n\\TextType NoteText\n\\StyleType Note\n\\FontSize 12\n\n\\Marker xo\n\\Endmarker xo*\n\\Name xo - Cross Reference - Origin Reference\n\\Description The cross reference origin reference (basic)\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\n\\Marker xop\n\\Endmarker xop*\n\\Name xop - Cross Reference - Origin Reference Publishing Alternate\n\\Description Published cross reference origin reference (origin reference that should appear in the published text)\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker xt\n\\Endmarker xt*\n\\Name xt - Cross Reference - Target References\n\\Description The cross reference target reference(s), protocanon only (basic)\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x ef ex NEST\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n#!\\Attributes ?link-href\n\n\\Marker xta\n\\Endmarker xta*\n\\Name xta - Cross Reference - Target References Added Text\n\\Description Cross reference target references added text\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker xk\n\\Endmarker xk*\n\\Name xk - Cross Reference - Keyword\n\\Description A cross reference keyword\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker xq\n\\Endmarker xq*\n\\Name xq - Cross Reference - Quotation\n\\Description A cross-reference quotation from the scripture text\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker xot\n\\Endmarker xot*\n\\Name xot...xot* - Cross Reference - OT Target Refs (optional)\n\\Description Cross-reference target reference(s), Old Testament only\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker xnt\n\\Endmarker xnt*\n\\Name xnt...xnt* - Cross Reference - NT Target Refs (optional)\n\\Description Cross-reference target reference(s), New Testament only\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker xdc\n\\Endmarker xdc*\n\\Name DEPRECATED xdc...xdc* - Cross Reference - DC Target Refs\n\\Description Cross-reference target reference(s), Deuterocanon only\n\\OccursUnder x\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\n\\Marker rq\n\\Endmarker rq*\n\\Name rq...rq* - Cross Reference - Inline Quotation References\n\\Description A cross-reference indicating the source text for the preceding quotation.\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 NEST\n\\TextType Other\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 10\n\\Italic\n\n# Other Special Text\n\n\\Marker qt\n\\Endmarker qt*\n\\Name qt...qt* - Special Text - Quoted Text - OT in NT\n\\Description For Old Testament quoted text appearing in the New Testament (basic)\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker nd\n\\Endmarker nd*\n\\Name nd...nd* - Special Text - Name of Deity\n\\Description For name of deity (basic)\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Underline\n\n\\Marker tl\n\\Endmarker tl*\n\\Name tl...tl* - Special Text - Transliterated Word\n\\Description For transliterated words\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable nonvernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker dc\n\\Endmarker dc*\n\\Name dc...dc* - Special Text - Deuterocanonical/LXX Additions\n\\Description Deuterocanonical/LXX additions or insertions in the Protocanonical text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\Italic\n\n\\Marker bk\n\\Endmarker bk*\n\\Name bk...bk* - Special Text - Quoted book title\n\\Description For the quoted name of a book\n\\OccursUnder imt imt1 imt2 imt3 imt4 imte imte1 imte2 is is1 is2 ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker sig\n\\Endmarker sig*\n\\Name sig...sig* - Special Text - Author's Signature (Epistles)\n\\Description For the signature of the author of an Epistle\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker pn\n\\Endmarker pn*\n\\Name pn...pn* - Special Text - Proper Name\n\\Description For a proper name\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\\Underline\n\n\\Marker png\n\\Endmarker png*\n\\Name png...png* - Special Text - Geographic Proper Name\n\\Description For a geographic proper name\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Underline\n\n\\Marker addpn\n\\Endmarker addpn*\n\\Name DEPRECATED addpn...addpn* - Special Text for Chinese\n\\Description For chinese words to be dot underline & underline\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n#\\Color 2263842\n##!\\ColorName green\n\\Bold\n\\Italic\n\\Underline\n\n\\Marker wj\n\\Endmarker wj*\n\\Name wj...wj* - Special Text - Words of Jesus\n\\Description For marking the words of Jesus\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Color 255\n#!\\ColorName highcon red\n\n\\Marker k\n\\Endmarker k*\n\\Name k...k* - Special Text - Keyword\n\\Description For a keyword\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Bold\n\n\\Marker sls\n\\Endmarker sls*\n\\Name sls...sls* - Special Text - Secondary Language or Text Source\n\\Description To represent where the original text is in a secondary language or from an alternate text source\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker ord\n\\Endmarker ord*\n\\Name ord...ord* - Special Text - Ordinal number text portion\n\\Description For the text portion of an ordinal number\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\n\\Marker add\n\\Endmarker add*\n\\Name add...add* - Special Text - Translational Addition\n\\Description For a translational addition to the text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 cls tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n#\\Color 2263842\n##!\\ColorName green\n\\Bold\n\\Italic\n\n\\Marker lit\n\\Name lit - Special Text - Liturgical note\n\\Description For a comment or note inserted for liturgical use\n\\OccursUnder c\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\Justification Right\n\\FontSize 12\n\\Bold\n\n# Character Styling\n\n\\Marker no\n\\Endmarker no*\n\\Name no...no* - Character - Normal Text\n\\Description A character style, use normal text\n\\OccursUnder is ip ipi im imi ili ili1 ili2 imq ipq iex iq iot io1 io2 io3 io4 s s1 s2 s3 NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker it\n\\Endmarker it*\n\\Name it...it* - Character - Italic Text\n\\Description A character style, use italic text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker bd\n\\Endmarker bd*\n\\Name bd...bd* - Character - Bold Text\n\\Description A character style, use bold text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\n\\Marker bdit\n\\Endmarker bdit*\n\\Name bdit...bdit* - Character - BoldItalic Text\n\\Description A character style, use bold + italic text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\\Italic\n\n\\Marker em\n\\Endmarker em*\n\\Name em...em* - Character - Emphasized Text\n\\Description A character style, use emphasized text style\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker sc\n\\Endmarker sc*\n\\Name sc...sc* - Character - Small Caps\n\\Description A character style, for small capitalization text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Smallcaps\n\n\\Marker sup\n\\Endmarker sup*\n\\Name sup...sup* - Character - Superscript\n\\Description A character style, for superscript text. Typically for use in critical edition footnotes.\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Superscript\n\n# Breaks\n\n\\Marker pb\n\\Name pb - Break - Page Break\n\\Description Page Break used for new reader portions and children's bibles where content is controlled by the page\n\\OccursUnder c\n\\Rank 4\n\\TextType Other\n\\TextProperties publishable\n\\StyleType Paragraph\n\\FontSize 12\n\n# Special Features\n\n\\Marker fig\n\\Endmarker fig*\n\\Name fig...fig* - Auxiliary - Figure/Illustration/Map\n\\Description Illustration [Columns to span, height, filename, caption text]\n\\OccursUnder lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 ms ms1 ms2 s s1 s2 s3 d ip\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n#!\\Attributes src size ref ?alt ?loc ?copy\n\n\\Marker jmp\n\\Endmarker jmp*\n\\Name jmp...jmp* - Link text\n\\Description For associating linking attributes to a span of text\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType Other\n\\StyleType Character\n\\Color 16711680\n#!\\ColorName highcon blue\n\\Underline\n#!\\Attributes ?link-href ?link-id ?link-title\n\n\\Marker pro\n\\Endmarker pro*\n\\Name DEPRECATED pro...pro* - Special Text - CJK Pronunciation\n\\Description For indicating pronunciation in CJK texts\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 ms ms1 ms2 s s1 s2 s3 d ip f fe NEST\n\\TextType Other\n\\TextProperties Nonpublishable\n\\StyleType Character\n\\FontSize 10\n\n\\Marker rb\n\\Endmarker rb*\n\\Name rb...rb* - Special Text - Ruby Glossing\n\\Description Most often used to provide a reading / pronunciation guide in ideographic scripts\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 sp tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 ms ms1 ms2 s s1 s2 s3 d ip f fe NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n#!\\Attributes gloss\n\n# Peripheral References\n\n\\Marker w\n\\Endmarker w*\n\\Name w...w* - Peripheral Ref - Wordlist Entry\n\\Description A wordlist text item\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n#!\\Attributes ?lemma ?strong ?srcloc\n\n\\Marker wh\n\\Endmarker wh*\n\\Name wh...wh* - Peripheral Ref - Hebrew Wordlist Entry\n\\Description A Hebrew wordlist text item\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker wg\n\\Endmarker wg*\n\\Name wg...wg* - Peripheral Ref - Greek Wordlist Entry\n\\Description A Greek Wordlist text item\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker wa\n\\Endmarker wa*\n\\Name wa...wa* - Peripheral Ref - Aramaic Wordlist Entry\n\\Description An Aramaic Wordlist text item\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker ndx\n\\Endmarker ndx*\n\\Name ndx...ndx* - Peripheral Ref - Subject Index Entry \n\\Description A subject index text item\n\\OccursUnder ip im ipi imi ipq imq ipr iq iq1 iq2 iq3 ili ili1 ili2 io io1 io2 io3 io4 ms ms1 ms2 s s1 s2 s3 s4 cd sp d lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr pmo pm pmc pmr po q q1 q2 q3 q4 qc qr qd qm qm1 qm2 qm3 tr th1 th2 th3 th4 thr1 thr2 thr3 thr4 tc1 tc2 tc3 tc4 tcr1 tcr2 tcr3 tcr4 f fe x NEST\n\\TextType VerseText\n\\TextProperties publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n# Peripheral Materials\n# Content Division Marker\n\n\\Marker periph\n\\Name periph - Peripherals - Content Division Marker\n\\Description Peripheral content division marker which should be followed by an additional division argument/title.\n\\TextType Section\n\\TextProperties paragraph nonpublishable vernacular\n\\StyleType Paragraph\n\\FontSize 14\n\\Bold\n\\SpaceBefore 16\n\\SpaceAfter 4\n\\Color 33023\n#!\\ColorName orange\n\n# Additional peripheral material extensions to existing USFM markup.\n\n\\Marker p1\n\\Name p1 - Periph - Front/Back Matter Paragraph Level 1\n\\Description Front or back matter text paragraph, level 1 (if multiple levels)\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\n\\Marker p2\n\\Name p2 - Periph - Front/Back Matter Paragraph Level 2\n\\Description Front or back matter text paragraph, level 2 (if multiple levels)\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/4 inch first line indent\n\\LeftMargin .125\n\n\\Marker k1\n\\Name k1 - Periph - Concordance Keyword Level 1\n\\Description Concordance main entry text or keyword, level 1\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker k2\n\\Name k2 - Periph - Concordance Keyword Level 2\n\\Description Concordance main entry text or keyword, level 2\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\n\\Marker xtSee\n\\Endmarker xtSee*\n\\Name xtSee - Concordance and Names Index - Alternate Entry Target Reference\n\\Description Concordance and Names Index markup for an alternate entry target reference.\n\\OccursUnder p\n\\TextProperties publishable vernacular\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Color 16711680\n#!\\ColorName highcon blue\n\n\\Marker xtSeeAlso\n\\Endmarker xtSeeAlso*\n\\Name xtSeeAlso - Concordance and Names Index - Additional Entry Target Reference\n\\Description Concordance and Names Index markup for an additional entry target reference.\n\\OccursUnder p\n\\TextProperties publishable vernacular\n\\TextType Other\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\\Color 16711680\n#!\\ColorName highcon blue\n\n# Milestones - these are not compatible with USFM2, so whole entries are preceded with #!\n\n#!\\Marker qt-s\n#!\\Endmarker qt-e\n#!\\Name Quotation start/end milestone\n#!\\Description Quotation start/end milestone, level 1 (if single level)\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker qt1-s\n#!\\Endmarker qt1-e\n#!\\Name Quotation start/end milestone - Level 1\n#!\\Description Quotation start/end milestone, level 1 (if multiple levels)\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker qt2-s\n#!\\Endmarker qt2-e\n#!\\Name Quotation start/end milestone - Level 2\n#!\\Description Quotation start/end milestone, level 2\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker qt3-s\n#!\\Endmarker qt3-e\n#!\\Name Quotation start/end milestone - Level 3\n#!\\Description Quotation start/end milestone, level 3\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker qt4-s\n#!\\Endmarker qt4-e\n#!\\Name Quotation start/end milestone - Level 4\n#!\\Description Quotation start/end milestone, level 4\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker qt5-s\n#!\\Endmarker qt5-e\n#!\\Name Quotation start/end milestone - Level 5\n#!\\Description Quotation start/end milestone, level 5\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?who ?sid ?eid\n\n#!\\Marker ts-s\n#!\\Endmarker ts-e\n#!\\Name Translator's section start/end milestone\n#!\\Description Translator's section start/end milestone\n#!\\OccursUnder id\n#!\\StyleType Milestone\n#!\\Attributes ?sid ?eid\n\n# Other special text elements specified in USFM\n#   ~ = fixed (no-break) space\n#   // = discretionary line break\n\n# Obsolete, deprecated, or no longer officially part of USFM.\n# These markers may have existed in earlier resource and stylesheet revisions.\n\n\\Marker ph\n\\Name DEPRECATED ph - Paragraph - Hanging Indent - Level 1\n\\Description Paragraph text, with level 1 hanging indent (if single level)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\LeftMargin .5\n\\FirstLineIndent -.25  # 1/4 inch indent, 1/2 inch wrap\n\\FontSize 12\n\n\\Marker ph1\n\\Name DEPRECATED ph1 - Paragraph - Hanging Indent - Level 1\n\\Description Paragraph text, with level 1 hanging indent (if multiple levels)\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\LeftMargin .5\n\\FirstLineIndent -.25  # 1/4 inch indent, 1/2 inch wrap\n\\FontSize 12\n\n\\Marker ph2\n\\Name DEPRECATED ph2 - Paragraph - Hanging Indent - Level 2\n\\Description Paragraph text, with level 2 hanging indent\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\LeftMargin .75\n\\FirstLineIndent -.25  # 1/2 inch indent, 3/4 inch wrap\n\\FontSize 12\n\n\\Marker ph3\n\\Name DEPRECATED ph3 - Paragraph - Hanging Indent - Level 3\n\\Description Paragraph text, with level 3 hanging indent\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\LeftMargin 1\n\\FirstLineIndent -.25  # 3/4 inch indent, 1 inch wrap\n\\FontSize 12\n\n\\Marker phi\n\\Name DEPRECATED phi - Paragraph - Indented - Hanging Indent\n\\Description Paragraph text, indented with hanging indent\n\\OccursUnder c \n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\LeftMargin 1\n\n\\Marker tr1\n\\Name DEPRECATED tr1 - Table - Row - Level 1\n\\Description A table Row\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .5\n\\FirstLineIndent -.25  # 6/16 inch\n\n\\Marker tr2\n\\Name DEPRECATED tr2 - Table - Row - Level 2\n\\Description A table Row\n\\OccursUnder c\n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\LeftMargin .75\n\\FirstLineIndent -.25  # 6/16 inch\n\n\\Marker ps\n\\Name DEPRECATED ps - Paragraph - No Break with Next Paragraph\n\\Description Paragraph text, no break with next paragraph text at chapter boundary\n\\OccursUnder c \n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\n\\Marker psi\n\\Name DEPRECATED psi - Paragraph - Indented - No Break with Next\n\\Description Paragraph text, indented, with no break with next paragraph text (at chapter boundary)\n\\OccursUnder c \n\\Rank 4\n\\TextType VerseText\n\\TextProperties paragraph publishable vernacular\n\\StyleType Paragraph\n\\FirstLineIndent .125   # 1/8 inch first line indent\n\\LeftMargin .25\n\\RightMargin .25\n\\FontSize 12\n\n\\Marker fs\n\\Endmarker fs*\n\\Name DEPRECATED fs - Footnote - Footnote Summary\n\\Description A summary text for the concept/idea/quotation from the scripture translation for which the note is being provided.\n\\OccursUnder f fe\n\\TextProperties publishable vernacular note\n\\TextType NoteText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n\\Marker wr\n\\Endmarker wr*\n\\Name DEPRECATED wr...wr* - Auxiliary - Wordlist/Glossary Reference \n\\Description A Wordlist text item\n\\OccursUnder ms s lh li li1 li2 li3 li4 lf lim lim1 lim2 lim3 lim4 m mi nb p pc ph phi pi pi1 pi2 pi3 pr po q q1 q2 q3 q4 qc qr qd tc1 tc2 tc3 tc4 f fe NEST\n\\TextProperties publishable vernacular\n\\TextType VerseText\n\\StyleType Character\n\\FontSize 12\n\\Italic\n\n# 2.0x peripheral markup (replaced with \\periph + Content Division Title/Argument)\n\n\\Marker pub\n\\Name DEPRECATED pub Peripherals - Front Matter Publication Data\n\\Description Front matter publication data\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker toc\n\\Name DEPRECATED toc Peripherals - Front Matter Table of Contents\n\\Description Front matter table of contents\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker pref\n\\Name DEPRECATED pref Peripherals - Front Matter Preface\n\\Description Front matter preface\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker intro\n\\Name DEPRECATED intro Peripherals - Front Matter Introduction\n\\Description Front matter introduction\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker conc\n\\Name DEPRECATED conc Peripherals - Back Matter Concordance\n\\Description Back matter concordance\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker glo\n\\Name DEPRECATED glo Peripherals - Back Matter Glossary\n\\Description Back matter glossary\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker idx\n\\Name DEPRECATED idx Peripherals - Back Matter Index\n\\Description Back matter index\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker maps\n\\Name DEPRECATED maps Peripherals - Back Matter Map Index\n\\Description Back matter map index\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker cov\n\\Name DEPRECATED cov Peripherals - Other - Cover\n\\Description Other peripheral materials - cover\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker spine\n\\Name DEPRECATED spine Peripherals - Other - Spine\n\\Description Other peripheral materials - spine\n\\OccursUnder id\n\\Rank 4\n\\TextProperties paragraph publishable vernacular poetic\n\\TextType VerseText\n\\FontSize 10\n\\StyleType paragraph\n\n\\Marker pubinfo\n\\Name DEPRECATED pubinfo - Publication - Information\n\\Description Publication information - Lang,Credit,Version,Copies,Publisher,Id,Logo\n\\OccursUnder id ide\n\\TextType Other\n\\TextProperties paragraph nonpublishable nonvernacular\n\\StyleType Paragraph\n\\FontSize 12\n\\Color 16711680\n#!\\ColorName highcon blue\n\n# Concordance/Names Index Tools - special sfms for use in Publishing Assistant\n\n\\Marker zpa-xb\n\\Endmarker zpa-xb*\n\\Name zpa-xb - Periph - Book\n\\Description Book Ref\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker zpa-xc\n\\Endmarker zpa-xc*\n\\Name zpa-xc - Periph - Chapter\n\\Description Chapter Ref\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\\Bold\n\n\\Marker zpa-xv\n\\Endmarker zpa-xv*\n\\Name zpa-xv - Periph - Verse\n\\Description Verse Ref\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n\n\\Marker zpa-d\n\\Endmarker zpa-d*\n\\Name zpa-d - Periph - Description\n\\Description Description\n\\OccursUnder id\n\\Rank 1\n\\TextType Other\n\\TextProperties paragraph publishable vernacular\n\\StyleType Character\n\\FontSize 12\n";
// Marker Spaces backend (Marker_Spaces/extension/src/main.js), in its own scope.
const MarkerSpaces = (function () {
// Marker Spaces for Paratext 10: the backend (runs in the extension host).
//
// tools/build.js makes dist/markerSpaces/src/main.js from: src/core.js (the scanner, MSCore), then
// the web view HTML and the built-in usfm.sty as string constants, then this file. Extensions may
// only require papi modules (no relative files, no fs, no eval), hence the single file.
//
// It adds:
//  - a check "Marker spaces" to Paratext 10's Checks panel (platformScripture.registerCheck);
//  - Tools > Marker Spaces... in the Scripture editor, which opens a window listing the problems,
//    where the ticked ones are fixed (book USFM read and written through platformScripture.USFM_Book).
/* global MSCore, MS_WEB_VIEW_HTML, MS_USFM_STY, MS_VERSION */
const papi = require('@papi/backend');

const { logger } = papi;
const WEB_VIEW_TYPE = 'markerSpaces.window';
const CHECK_ID_HINT = 'markerSpaces';

let executionToken;
/** The last scan of each project: issues (with their chapter text) and the book texts read. */
const sessions = new Map();
let builtInSty;

// ------------------------------------------------------------ helpers

function docs(summary) {
  return { method: { summary, params: [], result: { name: 'return value', schema: {} } } };
}

function verseRef(code, chapter, verse) {
  return { book: code, chapterNum: chapter, verseNum: verse };
}

async function interfaceLanguage() {
  try {
    const langs = await papi.settings.get('platform.interfaceLanguage');
    const first = Array.isArray(langs) && langs.length > 0 ? String(langs[0]).toLowerCase() : 'en';
    if (first.startsWith('es')) return 'es';
    if (first.startsWith('fr')) return 'fr';
  } catch (e) {
    logger.warn(`Marker Spaces: could not read the interface language: ${e}`);
  }
  return 'en';
}

async function projectName(projectId) {
  try {
    const base = await papi.projectDataProviders.get('platform.base', projectId);
    return (await base.getSetting('platform.name')) || projectId;
  } catch (e) {
    return projectId;
  }
}

/** Book numbers present in the project (setting platformScripture.booksPresent, "0101..."). */
async function booksPresent(projectId) {
  const base = await papi.projectDataProviders.get('platform.base', projectId);
  const present = String((await base.getSetting('platformScripture.booksPresent')) || '');
  const books = [];
  for (let i = 0; i < present.length && i < MSCore.BOOK_ORDER.length; i++)
    if (present[i] === '1') books.push({ num: i + 1, code: MSCore.bookCode(i + 1) });
  return books;
}

/** The stylesheet table for a book: Paratext's merged StyleInfo, or the built-in usfm.sty. */
async function styleTable(projectId, bookNum, cache) {
  if (cache && cache.has(bookNum)) return cache.get(bookNum);
  let sty;
  try {
    const pdp = await papi.projectDataProviders.get('platformScripture.StyleInfo', projectId);
    const info = await pdp.getStyleInfo(bookNum);
    if (info && info.markers && Object.keys(info.markers).length > 0) sty = MSCore.styFromStyleInfo(info);
  } catch (e) {
    logger.warn(`Marker Spaces: StyleInfo not available (${e}); using the built-in usfm.sty`);
  }
  if (!sty) {
    if (!builtInSty) builtInSty = MSCore.parseSty(MS_USFM_STY);
    sty = builtInSty;
  }
  if (cache) cache.set(bookNum, sty);
  return sty;
}

async function readBook(projectId, code) {
  const pdp = await papi.projectDataProviders.get('platformScripture.USFM_Book', projectId);
  return pdp.getBookUSFM(verseRef(code, 1, 1));
}

// ------------------------------------------------------------ options (per project, user storage)

async function loadOptions(projectId) {
  const o = Object.assign({}, MSCore.DEFAULT_OPTIONS);
  try {
    const saved = JSON.parse(await papi.storage.readUserData(executionToken, `options:${projectId}`));
    Object.keys(o).forEach((k) => {
      if (saved && saved[k] !== undefined) o[k] = saved[k];
    });
  } catch (e) {
    // nothing saved yet
  }
  return o;
}

async function saveOptions(projectId, options) {
  const o = {};
  Object.keys(MSCore.DEFAULT_OPTIONS).forEach((k) => {
    o[k] = options && options[k] !== undefined ? options[k] : MSCore.DEFAULT_OPTIONS[k];
  });
  await papi.storage.writeUserData(executionToken, `options:${projectId}`, JSON.stringify(o));
  return o;
}

// ------------------------------------------------------------ scanning

/** Scans the chosen books; keeps the session for fixing; returns rows for the window. */
async function scanProject(projectId) {
  const options = await loadOptions(projectId);
  const books = await booksPresent(projectId);
  const chosen = books.filter((b) => !MSCore.isExcluded(options, b.code));
  const styCache = new Map();
  const issues = [];
  const texts = new Map();
  const failed = [];
  let scanner;
  let scannerSty;
  for (const book of chosen) {
    let text;
    try {
      text = await readBook(projectId, book.code);
    } catch (e) {
      failed.push(`${book.code}: ${e}`);
      continue;
    }
    if (!text) continue;
    texts.set(book.num, text);
    const sty = await styleTable(projectId, book.num, styCache);
    if (sty !== scannerSty) {
      scanner = new MSCore.Scanner(options, sty);
      scannerSty = sty;
    }
    issues.push(...MSCore.scanBook(scanner, book, text));
  }
  issues.forEach((issue, i) => {
    issue.id = i;
  });
  sessions.set(projectId, { issues, texts });

  let canEdit = true;
  try {
    const perm = await papi.projectDataProviders.get('platformScripture.scriptureEditPermissions', projectId);
    canEdit = await perm.canUserEditScripture();
  } catch (e) {
    logger.warn(`Marker Spaces: could not read edit permission: ${e}`);
  }

  return {
    projectId,
    projectName: await projectName(projectId),
    canEdit,
    options,
    books: books.map((b) => ({ num: b.num, code: b.code, chosen: !MSCore.isExcluded(options, b.code) })),
    booksRead: chosen.length,
    failed,
    rows: issues.map((issue) => {
      const p = MSCore.preview(issue);
      return {
        id: issue.id,
        book: issue.book,
        chapter: issue.chapter,
        verse: issue.verse,
        kind: issue.kind,
        code: issue.code,
        marker: issue.marker,
        shown: issue.shown,
        canFix: issue.edits.length > 0,
        now: p.now,
        after: p.after,
      };
    }),
  };
}

// ------------------------------------------------------------ fixing

/**
 * Fixes the issues with these ids from the last scan. Each book is read again; a chapter whose text
 * differs from the scanned one is skipped ("changed since scan"). The book's text before the fix is
 * kept in the extension's user storage, then the whole book is written once.
 */
async function fixIssues(projectId, ids) {
  const report = { fixed: [], total: 0, booksChanged: 0, changed: [], failed: [], noPermission: false, backups: [] };
  const session = sessions.get(projectId);
  if (!session) throw new Error('Scan the project first.');
  const wanted = new Set(ids || []);
  const chosen = session.issues.filter((i) => wanted.has(i.id) && i.edits.length > 0);
  if (chosen.length === 0) return report;

  try {
    const perm = await papi.projectDataProviders.get('platformScripture.scriptureEditPermissions', projectId);
    if (!(await perm.canUserEditScripture())) {
      report.noPermission = true;
      return report;
    }
  } catch (e) {
    logger.warn(`Marker Spaces: could not read edit permission, trying anyway: ${e}`);
  }

  const byBook = new Map();
  chosen.forEach((i) => {
    if (!byBook.has(i.bookNum)) byBook.set(i.bookNum, []);
    byBook.get(i.bookNum).push(i);
  });
  const pdp = await papi.projectDataProviders.get('platformScripture.USFM_Book', projectId);
  const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\..*$/, '');

  for (const [bookNum, list] of byBook) {
    const code = MSCore.bookCode(bookNum);
    let current;
    try {
      current = await pdp.getBookUSFM(verseRef(code, 1, 1));
    } catch (e) {
      report.failed.push(`${code}: ${e}`);
      continue;
    }
    if (!current) {
      report.failed.push(`${code}: no text`);
      continue;
    }
    // Chapters as scanned; keep only those whose text is still the same.
    const now = new Map(MSCore.bookChapters(current).map((ch) => [ch.chapter, ch]));
    const byChapter = new Map();
    list.forEach((i) => {
      if (!byChapter.has(i.chapter)) byChapter.set(i.chapter, []);
      byChapter.get(i.chapter).push(i);
    });
    const pieces = [];
    let pos = 0;
    let count = 0;
    const order = Array.from(byChapter.keys())
      .map((c) => ({ c, ch: now.get(c) }))
      .sort((a, b) => (a.ch ? a.ch.start : 0) - (b.ch ? b.ch.start : 0));
    for (const { c, ch } of order) {
      const issues = byChapter.get(c);
      if (!ch || ch.text !== issues[0].chapterText) {
        report.changed.push(`${code} ${c}`);
        continue;
      }
      pieces.push(current.substring(pos, ch.start));
      pieces.push(MSCore.apply(ch.text, issues.flatMap((i) => i.edits)));
      pos = ch.start + ch.text.length;
      count += issues.length;
    }
    if (count === 0) continue;
    pieces.push(current.substring(pos));
    const fixed = pieces.join('');
    if (fixed === current) continue;

    const backupKey = `backup:${projectId}:${code}:${stamp}`;
    try {
      await papi.storage.writeUserData(executionToken, backupKey, current);
    } catch (e) {
      report.failed.push(`${code}: the backup could not be written, so the book was not changed (${e})`);
      continue;
    }
    try {
      await pdp.setBookUSFM(verseRef(code, 1, 1), fixed);
    } catch (e) {
      report.failed.push(`${code}: ${e}`);
      continue;
    }
    // Read it back: Paratext may normalize or refuse silently.
    let after;
    try {
      after = await pdp.getBookUSFM(verseRef(code, 1, 1));
    } catch (e) {
      after = undefined;
    }
    if (after === current) {
      report.failed.push(`${code}: Paratext did not save the change`);
      continue;
    }
    report.fixed.push({ book: code, count });
    report.backups.push(backupKey);
    report.total += count;
    report.booksChanged += 1;
  }
  return report;
}

// ------------------------------------------------------------ the check in the Checks panel

const checkDetails = Object.freeze({
  checkName: '%markerSpaces_checkName%',
  checkDescription: '%markerSpaces_checkDescription%',
});

/** Offset of pos within its verse's text (after "\v N "), as hello-rock3's check counts it. */
function verseOffset(chapterText, pos) {
  const before = chapterText.substring(0, pos);
  const m = /\\v\s+\S+\s?/g;
  let last = null;
  let found;
  while ((found = m.exec(before)) !== null) last = found;
  if (!last) return 0;
  return Math.max(0, pos - (last.index + last[0].length));
}

function messageArgs(issue) {
  const close = issue.shown.endsWith('*') ? issue.shown : `${issue.marker}*`;
  return { marker: `\\${issue.shown}`, base: `\\${issue.marker}`, close: `\\${close}` };
}

class MarkerSpacesCheck {
  constructor() {
    this.projectId = undefined;
    this.pdp = undefined;
    this.cache = new Map(); // bookNum -> { text, issues }
  }

  async initialize(projectId) {
    this.projectId = projectId;
    this.cache.clear();
    try {
      this.pdp = await papi.projectDataProviders.get('platformScripture.USFM_Book', projectId);
      this.options = await loadOptions(projectId);
    } catch (e) {
      return [String(e)];
    }
    return [];
  }

  async dispose() {
    this.projectId = undefined;
    this.pdp = undefined;
    this.cache.clear();
    return true;
  }

  getCheckDetails() {
    return checkDetails;
  }

  async getCheckResults(range) {
    if (!this.pdp) throw new Error('Check not initialized');
    const first = MSCore.bookNumber(range.start.book);
    const last = range.end ? MSCore.bookNumber(range.end.book) : first;
    const results = [];
    for (let bookNum = first; bookNum <= last && bookNum > 0; bookNum++) {
      const code = MSCore.bookCode(bookNum);
      let text;
      try {
        text = await this.pdp.getBookUSFM(verseRef(code, 1, 1));
      } catch (e) {
        continue;
      }
      if (!text) continue;
      let cached = this.cache.get(bookNum);
      if (!cached || cached.text !== text) {
        const sty = await styleTable(this.projectId, bookNum);
        const scanner = new MSCore.Scanner(this.options, sty);
        cached = { text, issues: MSCore.scanBook(scanner, { num: bookNum, code }, text) };
        this.cache.set(bookNum, cached);
      }
      const seen = new Map();
      for (const issue of cached.issues) {
        const v = MSCore.verseNumber(issue.verse);
        if (!inRange(range, bookNum, issue.chapter, v)) continue;
        const ref = verseRef(code, issue.chapter, v);
        const key = `${issue.chapter}:${v}:${issue.code}:${issue.shown}`;
        const n = (seen.get(key) || 0) + 1;
        seen.set(key, n);
        const offStart = verseOffset(issue.chapterText, issue.start);
        const offEnd = verseOffset(issue.chapterText, issue.end);
        results.push({
          checkResultType: issue.code,
          checkResultUniqueId: `${issue.shown}#${n}`,
          projectId: this.projectId,
          verseText: MSCore.preview(issue).now,
          itemText: `\\${issue.shown}`,
          messageFormatString: `%markerSpaces_message_${issue.code}%`,
          formatStringArguments: messageArgs(issue),
          isDenied: false,
          verseRef: ref,
          start: { verseRef: ref, offset: offStart },
          end: { verseRef: ref, offset: Math.max(offStart, offEnd) },
        });
      }
    }
    return results;
  }
}

function refNumber(book, chapter, verse) {
  return book * 1000000 + chapter * 1000 + verse;
}

function inRange(range, bookNum, chapter, verse) {
  const s = range.start;
  const e = range.end || range.start;
  const n = refNumber(bookNum, chapter, verse);
  const lo = refNumber(MSCore.bookNumber(s.book), s.chapterNum, s.verseNum);
  const hi = refNumber(MSCore.bookNumber(e.book), e.chapterNum, range.end ? e.verseNum : s.verseNum);
  // Verse 0 at the start takes in the chapter's heading and everything before verse 1.
  return n >= lo && n <= hi;
}

/** platform-scripture may activate after us: try for a while, in the background. */
function registerCheckWhenReady(context) {
  let tries = 0;
  const attempt = async () => {
    tries += 1;
    try {
      const unsubscribe = await papi.commands.sendCommand(
        'platformScripture.registerCheck',
        checkDetails,
        async () => new MarkerSpacesCheck(),
      );
      context.registrations.add(unsubscribe);
      logger.info('Marker Spaces: check registered');
    } catch (e) {
      if (tries < 30) setTimeout(attempt, 2000);
      else logger.error(`Marker Spaces: could not register the check: ${e}`);
    }
  };
  attempt();
}

// ------------------------------------------------------------ the window

async function webViewHtml(projectId) {
  const boot = { projectId, lang: await interfaceLanguage(), version: MS_VERSION };
  // JSON inside a <script>: keep "</script>" and U+2028/9 from ending or breaking it.
  const json = JSON.stringify(boot).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
  return MS_WEB_VIEW_HTML.replace('__MS_BOOT__', json);
}

const webViewProvider = {
  async getWebView(savedWebView, options) {
    if (savedWebView.webViewType !== WEB_VIEW_TYPE)
      throw new Error(`${WEB_VIEW_TYPE} provider received a request for ${savedWebView.webViewType}`);
    const projectId = (options && options.projectId) || savedWebView.projectId;
    if (!projectId) return undefined;
    const lang = await interfaceLanguage();
    const title = { en: 'Marker Spaces', es: 'Espacios de marcadores', fr: 'Espaces autour des marqueurs' }[lang];
    return {
      ...savedWebView,
      title: `${title} - ${await projectName(projectId)}`,
      projectId,
      contentType: 'html',
      content: await webViewHtml(projectId),
    };
  },
};

/** Opens the window for the editor's project, or for projectId when given (from Phils Checks). */
async function openWindow(editorWebViewId, givenProjectId) {
  let projectId = typeof givenProjectId === 'string' && givenProjectId ? givenProjectId : undefined;
  if (!projectId && typeof editorWebViewId === 'string' && editorWebViewId) {
    try {
      const def = await papi.webViews.getOpenWebViewDefinition(editorWebViewId);
      projectId = def && def.projectId;
    } catch (e) {
      logger.warn(`Marker Spaces: could not read the editor's project: ${e}`);
    }
  }
  if (!projectId) {
    try {
      projectId = await papi.dialogs.selectProject({
        title: 'Marker Spaces',
        prompt: 'Choose the project to check for marker spacing problems',
        includeProjectInterfaces: ['platformScripture.USFM_Book'],
      });
    } catch (e) {
      logger.warn(`Marker Spaces: project chooser failed: ${e}`);
    }
  }
  if (!projectId) return undefined;
  return papi.webViews.openWebView(
    WEB_VIEW_TYPE,
    { type: 'float', floatSize: { width: 1000, height: 640 } },
    { existingId: '?', existingProjectId: projectId, projectId },
  );
}

async function goTo(projectId, code, chapter, verse) {
  await papi.scrollGroups.setScrRef(undefined, verseRef(code, chapter, MSCore.verseNumber(String(verse))), projectId);
  return true;
}

// ------------------------------------------------------------ activation

async function activate(context) {
  logger.info(`Marker Spaces ${MS_VERSION} is activating`);
  executionToken = context.executionToken;

  const register = papi.webViewProviders.registerWebViewProvider || papi.webViewProviders.register;
  const registrations = await Promise.all([
    register.call(papi.webViewProviders, WEB_VIEW_TYPE, webViewProvider),
    papi.commands.registerCommand('markerSpaces.open', openWindow, docs('Open the Marker Spaces window')),
    papi.commands.registerCommand('markerSpaces.scan', scanProject, docs('Scan a project for marker spacing problems')),
    papi.commands.registerCommand('markerSpaces.fix', fixIssues, docs('Fix marker spacing problems from the last scan')),
    papi.commands.registerCommand('markerSpaces.saveOptions', saveOptions, docs('Save Marker Spaces options for a project')),
    papi.commands.registerCommand('markerSpaces.goTo', goTo, docs('Go to a verse')),
  ]);
  registrations.forEach((r) => context.registrations.add(r));
  registerCheckWhenReady(context);
  logger.info(`Marker Spaces is finished activating (${CHECK_ID_HINT})`);
}

async function deactivate() {
  sessions.clear();
  return true;
}

return { activate, deactivate, openWindow };

})();
// Phils Custom (cms) Checks for Paratext 10: the backend (runs in the extension host).
//
// tools/build.py makes dist/philsChecks/src/main.js from the files in src/order.json (the checks,
// global PC), then the web view HTML, the built-in usfm.sty and the version as string constants,
// then this file. Extensions may only require papi modules (no relative files, no fs), hence the
// single file. Read-only: nothing is written to the project.
//
// It adds:
//  - each check to Paratext 10's Checks panel (platformScripture.registerCheck), with the options
//    last used in the window;
//  - Tools > Phils Custom (cms) Checks... in the Scripture editor: a window that lists the checks,
//    sets their options, runs one and shows its report, whose references go to the verse;
//  - Marker Spaces (built in from Marker_Spaces/extension, see tools/build.py): its check, and its
//    fix window, opened from the list.
/* global PC, PCX_WEB_VIEW_HTML, PCX_USFM_STY, PCX_VERSION, MarkerSpaces */
const papi = require('@papi/backend');

const { logger } = papi;
const WEB_VIEW_TYPE = 'philsChecks.window';

let executionToken;
let builtInSty;
/**
 * Progress of the runs in progress, {projectId, runId, phase, done, total, book}: the window asks
 * for it with philsChecks.progress while it waits (HTML web views get commands reliably; network
 * events are also sent, for anyone listening).
 */
const runs = new Map();
let progressEmitter;
const PROGRESS_EVENT = 'philsChecks.onProgress';

function progress(data) {
  if (data.runId) runs.set(`${data.projectId}|${data.runId}`, data);
  try {
    if (progressEmitter) progressEmitter.emit(data);
  } catch (e) {
    // the window asks for it anyway
  }
}

async function getProgress(projectId, runId) {
  return runs.get(`${projectId}|${runId}`) || null;
}

/** Marker Spaces in the window's list: it opens its own window. */
const MARKER_SPACES_ITEM = {
  en: {
    name: 'Marker Spaces',
    description:
      'Finds spacing problems around character markers, footnotes and cross-references (for example "\nd Dios \nd*" or "word\nd") and fixes the ones you tick. It opens its own window.',
  },
  es: {
    name: 'Espacios de marcadores',
    description:
      'Encuentra problemas de espaciado alrededor de los marcadores de caracteres, las notas al pie y las referencias cruzadas (por ejemplo "\nd Dios \nd*" o "palabra\nd") y corrige los que usted marque. Se abre en su propia ventana.',
  },
  fr: {
    name: 'Espaces autour des marqueurs',
    description:
      'Trouve les probl\u00E8mes d\u2019espacement autour des marqueurs de caract\u00E8res, des notes et des r\u00E9f\u00E9rences crois\u00E9es (par exemple \u00AB \nd Dios \nd* \u00BB ou \u00AB mot\nd \u00BB) et corrige ceux que vous cochez. Il s\u2019ouvre dans sa propre fen\u00EAtre.',
  },
};

// ------------------------------------------------------------ helpers

function docs(summary) {
  return { method: { summary, params: [], result: { name: 'return value', schema: {} } } };
}

function verseRef(code, chapter, verse) {
  return { book: code, chapterNum: chapter, verseNum: verse };
}

async function interfaceLanguage() {
  try {
    const langs = await papi.settings.get('platform.interfaceLanguage');
    const first = Array.isArray(langs) && langs.length > 0 ? String(langs[0]).toLowerCase() : 'en';
    if (first.startsWith('es')) return 'es';
    if (first.startsWith('fr')) return 'fr';
  } catch (e) {
    logger.warn(`Phils Checks: could not read the interface language: ${e}`);
  }
  return 'en';
}

async function projectName(projectId) {
  try {
    const base = await papi.projectDataProviders.get('platform.base', projectId);
    return (await base.getSetting('platform.name')) || projectId;
  } catch (e) {
    return projectId;
  }
}

/** Books in the project (setting platformScripture.booksPresent, "0101..."), in book order. */
async function booksPresent(projectId) {
  const base = await papi.projectDataProviders.get('platform.base', projectId);
  const present = String((await base.getSetting('platformScripture.booksPresent')) || '');
  const books = [];
  for (let i = 0; i < present.length && i < PC.usfm.BOOKS.length; i++)
    if (present[i] === '1') books.push({ num: i + 1, code: PC.usfm.bookCode(i + 1) });
  return books;
}

/** The project's stylesheet from Paratext's StyleInfo; the built-in usfm.sty if it gives none. */
async function styleTable(projectId, bookNum) {
  try {
    const pdp = await papi.projectDataProviders.get('platformScripture.StyleInfo', projectId);
    const info = await pdp.getStyleInfo(bookNum || 1);
    if (info && info.markers && Object.keys(info.markers).length > 0) return PC.sty.fromStyleInfo(info);
  } catch (e) {
    logger.warn(`Phils Checks: StyleInfo not available (${e}); using the built-in usfm.sty`);
  }
  if (!builtInSty) builtInSty = PC.sty.parse(PCX_USFM_STY);
  return builtInSty;
}

function definition(checkId) {
  const def = PC.checks.get(checkId);
  if (!def) throw new Error(`Unknown check: ${checkId}`);
  return def;
}

// ------------------------------------------------------------ options (per project and check)

async function loadOptions(projectId, checkId) {
  const def = definition(checkId);
  const o = {};
  let saved = {};
  try {
    saved = JSON.parse(await papi.storage.readUserData(executionToken, `options:${projectId}:${checkId}`)) || {};
  } catch (e) {
    // nothing saved yet
  }
  def.options.forEach((d) => {
    o[d.name] = saved[d.name] !== undefined && saved[d.name] !== null ? String(saved[d.name]) : d.def;
  });
  return o;
}

async function saveOptions(projectId, checkId, options) {
  const def = definition(checkId);
  const o = {};
  def.options.forEach((d) => {
    o[d.name] = options && options[d.name] !== undefined ? String(options[d.name]) : d.def;
  });
  await papi.storage.writeUserData(executionToken, `options:${projectId}:${checkId}`, JSON.stringify(o));
  return o;
}

/** Books that are not Bible text: read only when the window's tick box says so. */
const OTHER_BOOKS = new Set('FRT BAK OTH INT CNC GLO TDX NDX XXA XXB XXC XXD XXE XXF XXG'.split(' '));

async function loadOtherBooks(projectId) {
  try {
    return JSON.parse(await papi.storage.readUserData(executionToken, `otherBooks:${projectId}`)) === true;
  } catch (e) {
    return false;
  }
}

// ------------------------------------------------------------ the window's commands

/** The checks, in the window's language, sorted by name. */
async function listChecks(lang) {
  const L = PC.report.lang(lang || (await interfaceLanguage()));
  const list = Array.from(PC.checks.values()).map((def) => ({
    id: def.id,
    name: L.str(`Check_${def.id}_Name`),
    description: L.str(`Check_${def.id}_Desc`),
    kind: def.kind,
    options: def.options.map((d) => ({
      name: d.name,
      type: d.type,
      def: d.def,
      label: L.str(`Opt_${def.id}_${d.name}_Label`).startsWith('Opt_') ? d.name : L.str(`Opt_${def.id}_${d.name}_Label`),
      tip: L.str(`Opt_${def.id}_${d.name}_Tip`).startsWith('Opt_') ? '' : L.str(`Opt_${def.id}_${d.name}_Tip`),
    })),
  }));
  const ms = MARKER_SPACES_ITEM[L.code] || MARKER_SPACES_ITEM.en;
  list.push({ id: 'markerSpaces', name: ms.name, description: ms.description, kind: 'changes', opens: 'markerSpaces.open', options: [] });
  const collator = new Intl.Collator(L.code, { sensitivity: 'base' });
  list.sort((a, b) => collator.compare(a.name, b.name));
  return list;
}

/**
 * Runs a check on the project's books (non-Bible books only when run.otherBooks, which is
 * remembered); returns its report section, and its rows when run.withRows (for the tests).
 */
async function runFromWindow(projectId, checkId, options, lang, run) {
  const def = definition(checkId);
  const used = await saveOptions(projectId, checkId, options);
  const otherBooks = !!(run && run.otherBooks);
  await papi.storage.writeUserData(executionToken, `otherBooks:${projectId}`, JSON.stringify(otherBooks));
  const present = (await booksPresent(projectId)).filter((b) => otherBooks || !OTHER_BOOKS.has(b.code));
  const runId = run && run.runId;
  progress({ projectId, runId, phase: 'open', done: 0, total: present.length });
  const pdp = await papi.projectDataProviders.get('platformScripture.USFM_Book', projectId);
  const books = [];
  const failed = [];
  for (let i = 0; i < present.length; i++) {
    const b = present[i];
    progress({ projectId, runId, phase: 'read', done: i, total: present.length, book: b.code });
    try {
      const text = await pdp.getBookUSFM(verseRef(b.code, 1, 1));
      if (text !== undefined && text !== null) books.push({ num: b.num, code: b.code, text });
    } catch (e) {
      failed.push(`${b.code}: ${e}`);
    }
  }
  const sty = await styleTable(projectId, books.length > 0 ? books[0].num : 1);
  progress({ projectId, runId, phase: 'check', done: present.length, total: present.length });
  const result = PC.runCheck(def, { books, options: used, sty });
  progress({ projectId, runId, phase: 'report', done: present.length, total: present.length });
  if (runId) setTimeout(() => runs.delete(`${projectId}|${runId}`), 5000);
  const language = lang || (await interfaceLanguage());
  return {
    checkId,
    options: used,
    booksRead: result.booksRead,
    failed,
    count: result.findings.length,
    css: PC.report.css(def),
    html: PC.report.section(def, result, language),
    rows: run && run.withRows ? PC.findingRows(result, language) : undefined,
  };
}

/** Goes to "BOOK C:V" (a bare "BOOK" goes to its start) in the project's scroll group. */
async function goTo(projectId, ref) {
  const m = /^(\S+)(?:\s+(\d+)(?::(\S+))?)?$/.exec(String(ref || '').trim());
  if (!m) return false;
  const chapter = m[2] ? parseInt(m[2], 10) : 1;
  const verse = m[3] ? PC.usfm.verseNumber(m[3]) : 1;
  await papi.scrollGroups.setScrRef(undefined, verseRef(m[1], Math.max(1, chapter), verse), projectId);
  return true;
}

// ------------------------------------------------------------ the checks in the Checks panel

const VERSE_START_RE = /\\v\s+\S+\s?/g;

/** Offset of pos within its verse's text (after "\v N "); 0 at the \v itself. */
function verseOffset(chapterText, pos) {
  let last = null;
  VERSE_START_RE.lastIndex = 0;
  let m;
  while ((m = VERSE_START_RE.exec(chapterText)) !== null && m.index <= pos) last = m;
  VERSE_START_RE.lastIndex = 0;
  if (!last) return 0;
  return Math.max(0, pos - (last.index + last[0].length));
}

function refNumber(book, chapter, verse) {
  return book * 1000000 + chapter * 1000 + verse;
}

function inRange(range, bookNum, chapter, verse) {
  const s = range.start;
  const e = range.end || range.start;
  const n = refNumber(bookNum, chapter, verse);
  const lo = refNumber(PC.usfm.bookNumber(s.book), s.chapterNum, s.verseNum);
  const hi = refNumber(PC.usfm.bookNumber(e.book), e.chapterNum, range.end ? e.verseNum : s.verseNum);
  return n >= lo && n <= hi;
}

function checkDetailsOf(def) {
  return Object.freeze({
    checkName: `%philsChecks_check_${def.id}_name%`,
    checkDescription: `%philsChecks_check_${def.id}_description%`,
  });
}

/** One P10 check object for one of our checks; each book is checked on its own and cached. */
class PanelCheck {
  constructor(def) {
    this.def = def;
    this.details = checkDetailsOf(def);
    this.projectId = undefined;
    this.cache = new Map(); // bookNum -> { text, findings }
  }

  async initialize(projectId) {
    this.projectId = projectId;
    this.cache.clear();
    try {
      this.pdp = await papi.projectDataProviders.get('platformScripture.USFM_Book', projectId);
      this.options = await loadOptions(projectId, this.def.id);
      this.lang = await interfaceLanguage();
      this.sty = undefined;
    } catch (e) {
      return [String(e)];
    }
    return [];
  }

  async dispose() {
    this.projectId = undefined;
    this.pdp = undefined;
    this.cache.clear();
    return true;
  }

  getCheckDetails() {
    return this.details;
  }

  async getCheckResults(range) {
    if (!this.pdp) throw new Error('Check not initialized');
    const first = PC.usfm.bookNumber(range.start.book);
    const last = range.end ? PC.usfm.bookNumber(range.end.book) : first;
    const L = PC.report.lang(this.lang);
    const results = [];
    for (let bookNum = first; bookNum <= last && bookNum > 0; bookNum++) {
      const code = PC.usfm.bookCode(bookNum);
      let text;
      try {
        text = await this.pdp.getBookUSFM(verseRef(code, 1, 1));
      } catch (e) {
        continue;
      }
      if (!text) continue;
      let cached = this.cache.get(bookNum);
      if (!cached || cached.text !== text) {
        if (!this.sty) this.sty = await styleTable(this.projectId, bookNum);
        const result = PC.runCheck(this.def, { books: [{ num: bookNum, code, text }], options: this.options, sty: this.sty });
        cached = { text, findings: result.findings.filter((f) => f.inList) };
        this.cache.set(bookNum, cached);
      }
      const seen = new Map();
      for (const f of cached.findings) {
        const v = PC.usfm.verseNumber(f.verse);
        if (!inRange(range, bookNum, f.chapter, v)) continue;
        const ref = verseRef(code, f.chapter, v);
        const key = `${f.chapter}:${v}:${f.category}`;
        const n = (seen.get(key) || 0) + 1;
        seen.set(key, n);
        const offStart = verseOffset(f.chapterText, f.begin);
        const offEnd = verseOffset(f.chapterText, f.end);
        const message = f.localize ? f.localize(L) : f.message;
        results.push({
          checkResultType: `${this.def.id}.${f.category}`,
          checkResultUniqueId: `${f.category}#${n}`,
          projectId: this.projectId,
          verseText: f.context || '',
          itemText: f.context || message,
          messageFormatString: '%philsChecks_message%',
          formatStringArguments: { message },
          isDenied: false,
          verseRef: ref,
          start: { verseRef: ref, offset: offStart },
          end: { verseRef: ref, offset: Math.max(offStart, offEnd) },
        });
      }
    }
    return results;
  }
}

/** platform-scripture may activate after us: try for a while, in the background. */
function registerChecksWhenReady(context) {
  PC.checks.forEach((def) => {
    let tries = 0;
    const attempt = async () => {
      tries += 1;
      try {
        const unsubscribe = await papi.commands.sendCommand(
          'platformScripture.registerCheck',
          checkDetailsOf(def),
          async () => new PanelCheck(def),
        );
        context.registrations.add(unsubscribe);
        logger.info(`Phils Checks: check ${def.id} registered`);
      } catch (e) {
        if (tries < 30) setTimeout(attempt, 2000);
        else logger.error(`Phils Checks: could not register the check ${def.id}: ${e}`);
      }
    };
    attempt();
  });
}

// ------------------------------------------------------------ the window

const TITLES = {
  en: 'Phils Custom (cms) Checks',
  es: 'Verificaciones personalizadas (cms) de Phil',
  fr: 'V\u00E9rifications personnalis\u00E9es (cms) de Phil',
};

const projectNames = new Map();

/** The project's name, waiting at most 0.3 s (opening a project can take long); cached. */
async function quickProjectName(projectId) {
  if (projectNames.has(projectId)) return projectNames.get(projectId);
  const name = projectName(projectId).then((n) => {
    projectNames.set(projectId, n);
    return n;
  });
  return Promise.race([name, new Promise((resolve) => setTimeout(() => resolve(''), 300))]);
}

async function webViewHtml(projectId) {
  const lang = await interfaceLanguage();
  const boot = { projectId, lang, version: PCX_VERSION, projectName: await quickProjectName(projectId), otherBooks: await loadOtherBooks(projectId) };
  // JSON inside a <script>: keep "</script>" and U+2028/9 from ending or breaking it.
  const json = JSON.stringify(boot).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
  return PCX_WEB_VIEW_HTML.replace('__PCX_BOOT__', json);
}

const webViewProvider = {
  async getWebView(savedWebView, options) {
    if (savedWebView.webViewType !== WEB_VIEW_TYPE)
      throw new Error(`${WEB_VIEW_TYPE} provider received a request for ${savedWebView.webViewType}`);
    const projectId = (options && options.projectId) || savedWebView.projectId;
    if (!projectId) return undefined;
    const lang = await interfaceLanguage();
    const name = await quickProjectName(projectId);
    return {
      ...savedWebView,
      title: name ? `${TITLES[lang]} - ${name}` : TITLES[lang],
      projectId,
      contentType: 'html',
      content: await webViewHtml(projectId),
    };
  },
};

async function openWindow(editorWebViewId) {
  let projectId;
  if (typeof editorWebViewId === 'string' && editorWebViewId) {
    try {
      const def = await papi.webViews.getOpenWebViewDefinition(editorWebViewId);
      projectId = def && def.projectId;
    } catch (e) {
      logger.warn(`Phils Checks: could not read the editor's project: ${e}`);
    }
  }
  if (!projectId) {
    try {
      projectId = await papi.dialogs.selectProject({
        title: TITLES.en,
        prompt: 'Choose the project to check',
        includeProjectInterfaces: ['platformScripture.USFM_Book'],
      });
    } catch (e) {
      logger.warn(`Phils Checks: project chooser failed: ${e}`);
    }
  }
  if (!projectId) return undefined;
  return papi.webViews.openWebView(
    WEB_VIEW_TYPE,
    { type: 'float', floatSize: { width: 1100, height: 720 } },
    { existingId: '?', existingProjectId: projectId, projectId },
  );
}

// ------------------------------------------------------------ activation

async function activate(context) {
  logger.info(`Phils Checks ${PCX_VERSION} is activating`);
  executionToken = context.executionToken;

  const register = papi.webViewProviders.registerWebViewProvider || papi.webViewProviders.register;
  const registrations = await Promise.all([
    register.call(papi.webViewProviders, WEB_VIEW_TYPE, webViewProvider),
    papi.commands.registerCommand('philsChecks.open', openWindow, docs('Open the Phils Custom (cms) Checks window')),
    papi.commands.registerCommand('philsChecks.list', listChecks, docs('List the checks')),
    papi.commands.registerCommand('philsChecks.run', runFromWindow, docs('Run a check on a project')),
    papi.commands.registerCommand('philsChecks.loadOptions', loadOptions, docs('Read the options of a check for a project')),
    papi.commands.registerCommand('philsChecks.saveOptions', saveOptions, docs('Save the options of a check for a project')),
    papi.commands.registerCommand('philsChecks.goTo', goTo, docs('Go to a verse')),
    papi.commands.registerCommand('philsChecks.progress', getProgress, docs('Progress of a run started from the window')),
    papi.commands.registerCommand('philsChecks.projectName', projectName, docs("A project's name")),
  ]);
  registrations.forEach((r) => context.registrations.add(r));
  try {
    const create = papi.network.createNetworkEventEmitterAsync || papi.network.createNetworkEventEmitter;
    progressEmitter = await create.call(papi.network, PROGRESS_EVENT, {
      notification: { summary: 'Progress of a Phils Checks run, for its window', params: [] },
    });
    if (progressEmitter && progressEmitter.dispose) context.registrations.add(() => progressEmitter.dispose());
  } catch (e) {
    logger.warn(`Phils Checks: no progress events (${e})`);
  }
  registerChecksWhenReady(context);
  await MarkerSpaces.activate(context);
  logger.info(`Phils Checks is finished activating (${PC.checks.size} checks + Marker Spaces)`);
}

async function deactivate() {
  await MarkerSpaces.deactivate();
  return true;
}

exports.activate = activate;
exports.deactivate = deactivate;
